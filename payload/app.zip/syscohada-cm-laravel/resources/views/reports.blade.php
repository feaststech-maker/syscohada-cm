@extends('layout')
@section('title', 'Livres & rapports')
@section('breadcrumb', 'Livres & rapports')
@section('content')
@php
$base='/companies/'.$company->id.'/years/'.$year->id;
$titles=['balance'=>'Balance générale','ledger'=>'Grand-livre des comptes','cash'=>'Livre de trésorerie'];
$kind=in_array($kind ?? 'balance', ['balance','ledger','cash'], true) ? ($kind ?? 'balance') : 'balance';
$report=$report ?? [];
@endphp
<div class="page-heading"><div><div class="eyebrow">DES CHIFFRES QUI SE RAPPROCHENT</div><h1>{{ $titles[$kind] }}</h1><p>{{ $company->name }} <span class="separator">·</span> Du {{ \Illuminate\Support\Carbon::parse($year->starts_on)->format('d/m/Y') }} au {{ \Illuminate\Support\Carbon::parse($year->ends_on)->format('d/m/Y') }}</p></div><button type="button" class="button secondary" data-print>Imprimer <span aria-hidden="true">↗</span></button></div>
<nav class="tabs" aria-label="Types de rapport">@foreach($titles as $key=>$label)<a class="{{ $kind===$key?'active':'' }}" href="{{ url($base.'/reports?kind='.$key) }}" @if($kind===$key) aria-current="page" @endif>{{ $label }}</a>@endforeach</nav>
<div class="notice subtle"><strong>Écritures comptabilisées uniquement.</strong> Les brouillons sont exclus. Aucun solde d’ouverture ni comparatif N−1 absent n’est inventé ; les écritures d’ouverture réelles doivent être enregistrées pour obtenir une vue complète.</div>
@if($kind==='balance')
<div class="stat-grid three"><article class="stat"><span>Total des mouvements débiteurs</span><strong class="amount">{{ $report['total_debit'] ?? '0.000000' }} <small>XAF</small></strong></article><article class="stat"><span>Total des mouvements créditeurs</span><strong class="amount">{{ $report['total_credit'] ?? '0.000000' }} <small>XAF</small></strong></article><article class="stat"><span>Contrôle des mouvements</span><strong class="stat-label">{{ ($report['balanced'] ?? false) ? 'Équilibrés' : 'À vérifier' }}</strong><small>Ce contrôle ne valide pas à lui seul une DSF.</small></article></div>
@elseif($kind==='cash')
<div class="stat-grid three"><article class="stat"><span>Entrées de trésorerie corrigées</span><strong class="amount">{{ $report['inflows'] ?? '0.000000' }} <small>XAF</small></strong></article><article class="stat"><span>Sorties de trésorerie corrigées</span><strong class="amount">{{ $report['outflows'] ?? '0.000000' }} <small>XAF</small></strong></article><article class="stat"><span>Variation issue des écritures</span><strong class="amount">{{ $report['net'] ?? '0.000000' }} <small>XAF</small></strong></article></div>
@endif
<section class="card mt"><div class="card-head"><div><h2>{{ $titles[$kind] }}</h2><p>Montants en XAF. Les corrections en négatif conservent la trace des écritures d’origine.</p></div><span class="badge neutral">{{ count($report['rows'] ?? []) }} lignes</span></div>
<div class="table-scroll"><table><thead>
@if($kind==='balance')<tr><th>Compte</th><th>Intitulé</th><th class="number">Mouvements débit</th><th class="number">Mouvements crédit</th><th class="number">Solde débiteur</th><th class="number">Solde créditeur</th></tr>
@elseif($kind==='ledger')<tr><th>Date</th><th>Numéro / référence</th><th>Compte</th><th>Libellé</th><th class="number">Débit</th><th class="number">Crédit</th><th class="number">Solde du compte</th></tr>
@else<tr><th>Date</th><th>Numéro</th><th>Opération</th><th class="number">Entrée</th><th class="number">Sortie</th><th class="number">Variation cumulée</th></tr>@endif
</thead><tbody>
@forelse(($report['rows'] ?? []) as $row)
@if($kind==='balance')<tr><td class="account-code">{{ $row['code'] }}</td><td>{{ $row['name'] }}</td><td class="number">{{ $row['debit'] }}</td><td class="number">{{ $row['credit'] }}</td><td class="number">{{ $row['closing_debit'] }}</td><td class="number">{{ $row['closing_credit'] }}</td></tr>
@elseif($kind==='ledger')<tr><td class="nowrap">{{ \Illuminate\Support\Carbon::parse($row['entry_date'])->format('d/m/Y') }}</td><td><strong>{{ $row['number'] }}</strong><small>{{ $row['reference'] ?? '' }}</small></td><td class="account-code">{{ $row['code'] }}<small>{{ $row['name'] }}</small></td><td>{{ $row['description'] }}</td><td class="number">{{ $row['debit'] }}</td><td class="number">{{ $row['credit'] }}</td><td class="number">{{ $row['running_balance'] }}</td></tr>
@else<tr><td class="nowrap">{{ \Illuminate\Support\Carbon::parse($row['entry_date'])->format('d/m/Y') }}</td><td>{{ $row['number'] }}</td><td>{{ $row['description'] }}@if($row['correction'] ?? false)<small>Correction négative du mouvement initial</small>@endif
@if($row['internal_transfer'] ?? false)<small>Transfert interne · variation globale nulle</small>@endif</td><td class="number">{{ $row['inflow'] }}</td><td class="number">{{ $row['outflow'] }}</td><td class="number">{{ $row['running_balance'] }}</td></tr>@endif
@empty<tr><td colspan="7"><div class="empty compact"><h3>Aucun mouvement comptabilisé.</h3><p>Les écritures apparaîtront après leur validation.</p></div></td></tr>@endforelse
</tbody></table></div>
</section>
<div class="actions between mt"><a class="button secondary" href="{{ url($base.'/accounting') }}">← Revenir aux opérations</a>
@if($kind === 'balance')
<div class="inline-actions"><a class="button secondary" href="{{ url($base.'/balance.csv') }}">Télécharger la balance CSV <span aria-hidden="true">↓</span></a>
@if(in_array(auth()->user()->role, ['TENANT_ADMIN', 'ACCOUNTANT', 'PLATFORM_ADMIN'], true))
<form method="post" action="{{ url($base.'/import/from-ledger') }}">@csrf<button class="button primary" type="submit">Préparer ma DSF avec cette balance <span aria-hidden="true">→</span></button></form>
@endif
</div>
@endif
</div>
@if($kind === 'balance')<p class="muted small mt">La préparation DSF reprend les soldes de la balance comptabilisée. Elle ne remplace pas les données complémentaires, la revue fiscale ou la qualification du canevas officiel.</p>@endif
@endsection
