@extends('layout')
@section('title', 'Vue d’ensemble')
@section('content')
<div class="page-heading"><div><div class="eyebrow">VOTRE DÉPARTEMENT COMPTABLE VIRTUEL</div><h1>Bonjour, {{ auth()->user()->name }}.</h1><p>Vos entreprises, leurs opérations et leur préparation fiscale, au même endroit.</p></div><span class="badge soft">XAF · Cameroun</span></div>
<div class="stat-grid three"><article class="stat"><span>Entreprises de votre espace</span><strong>{{ count($companies) }}</strong><small>Dossiers accessibles à votre compte</small></article><article class="stat"><span>Systèmes comptables</span><strong class="stat-label">Normal & SMT</strong><small>Distincts du régime fiscal de l’entreprise</small></article><article class="stat"><span>Votre prochain repère</span><strong class="stat-label">Une opération</strong><small>Saisir, vérifier, puis comptabiliser</small></article></div>
<div class="section-title"><h2>Vos entreprises</h2><span class="muted">Un espace de travail par dossier</span></div>
<div class="company-grid">
@forelse($companies as $item)
<a class="card company-card" href="{{ url('/companies/'.$item->id) }}"><div class="company-card-top"><span class="company-symbol">{{ mb_substr($item->name, 0, 1) }}</span><span class="badge {{ $item->virtual_accounting_enabled ? 'soft' : 'neutral' }}">{{ $item->virtual_accounting_enabled ? 'Comptabilité activée' : 'DSF' }}</span></div><h3>{{ $item->name }}</h3><p>{{ $item->niu ?: 'NIU à compléter' }}</p><div class="company-card-bottom"><span>{{ $item->accounting_system === 'SMT' ? 'Système minimal de trésorerie' : 'Système normal' }}</span><span aria-hidden="true">↗</span></div></a>
@empty
<div class="card empty"><span class="empty-icon" aria-hidden="true">▤</span><h3>Votre premier dossier commence ici.</h3><p>Créez une entreprise pour préparer sa balance ou activer sa comptabilité virtuelle.</p></div>
@endforelse
</div>
@if(in_array(auth()->user()->role, ['TENANT_ADMIN', 'PLATFORM_ADMIN'], true))
<section class="card mt" aria-labelledby="new-company"><div class="card-head"><div><h2 id="new-company">Ajouter une entreprise</h2><p>Le système comptable et le régime fiscal se renseignent séparément.</p></div><span class="badge neutral">Nouveau dossier</span></div>
<form action="{{ url('/companies') }}" method="post" class="form-stack">@csrf
<div class="form-grid"><label>Raison sociale<input name="name" value="{{ old('name') }}" maxlength="240" required></label><label>NIU<input name="niu" value="{{ old('niu') }}" maxlength="30"></label><label>Système comptable<select name="accounting_system"><option value="SMT" @selected(old('accounting_system')==='SMT')>Système minimal de trésorerie (SMT)</option><option value="NORMAL" @selected(old('accounting_system')==='NORMAL')>Système normal</option></select></label><label>Régime fiscal<input name="fiscal_regime" value="{{ old('fiscal_regime') }}" maxlength="40" placeholder="À confirmer selon votre situation"></label></div>
<label class="check-line"><input type="checkbox" name="virtual_accounting_enabled" value="1" @checked(old('virtual_accounting_enabled'))><span><strong>Activer la comptabilité virtuelle</strong><small>Ajouter les écritures, journaux, livres et opérations guidées. Vous pourrez modifier cette option plus tard.</small></span></label>
<div class="actions end"><button class="button primary" type="submit">Créer l’entreprise <span aria-hidden="true">→</span></button></div>
</form></section>
@endif
@endsection
