<!doctype html>
<html lang="fr">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Votre espace comptable') · SYSCOHADA CM</title>
    <link rel="stylesheet" href="{{ asset('assets/app.css') }}">
    <script src="{{ asset('assets/app.js') }}" defer></script>
</head>
<body>
<a class="skip-link" href="#main">Aller au contenu</a>
<div class="shell">
    <aside class="sidebar" aria-label="Navigation principale">
        <a class="brand" href="{{ auth()->check() ? url('/dashboard') : url('/login') }}"><span class="brand-mark">SC<span>•</span></span><span>SYSCOHADA <small>CM</small><em>LA CLARTÉ COMPTABLE.</em></span></a>
        <div class="workspace"><span class="workspace-avatar">{{ auth()->check() ? mb_substr(auth()->user()->name, 0, 1) : 'S' }}</span><div>{{ $company->name ?? 'Votre espace entreprise' }}<small>{{ auth()->check() ? 'Comptabilité & déclaration' : 'Connexion sécurisée' }}</small></div></div>
        @auth
        <p class="nav-label">VOTRE ESPACE</p>
        <nav>
            <a class="nav-item {{ request()->is('dashboard') ? 'active' : '' }}" href="{{ url('/dashboard') }}"><span aria-hidden="true">▦</span> Vue d’ensemble</a>
            @isset($company)
            <a class="nav-item {{ request()->is('companies/'.$company->id) ? 'active' : '' }}" href="{{ url('/companies/'.$company->id) }}"><span aria-hidden="true">▤</span> Entreprise & exercices</a>
            @endisset
            @if(isset($company, $year))
            <a class="nav-item {{ request()->is('*/accounting') ? 'active' : '' }}" href="{{ url('/companies/'.$company->id.'/years/'.$year->id.'/accounting') }}"><span aria-hidden="true">◈</span> Comptabilité virtuelle</a>
            <a class="nav-item {{ request()->is('*/import*') ? 'active' : '' }}" href="{{ url('/companies/'.$company->id.'/years/'.$year->id.'/import') }}"><span aria-hidden="true">⇥</span> Importer une balance</a>
            <a class="nav-item {{ request()->is('*/reports') ? 'active' : '' }}" href="{{ url('/companies/'.$company->id.'/years/'.$year->id.'/reports?kind=balance') }}"><span aria-hidden="true">≡</span> Livres & rapports</a>
            @endif
            @if(in_array(auth()->user()->role, ['TENANT_ADMIN', 'PLATFORM_ADMIN'], true))
            <a class="nav-item {{ request()->is('admin*') ? 'active' : '' }}" href="{{ url('/admin') }}"><span aria-hidden="true">⚙</span> Administration</a>
            @endif
        </nav>
        <div class="sidebar-note"><strong>Un chiffre, une trace.</strong><p>Les brouillons restent à vérifier. Une écriture comptabilisée se corrige par une nouvelle écriture.</p></div>
        <div class="identity"><span class="identity-avatar">{{ mb_substr(auth()->user()->name, 0, 1) }}</span><div>{{ auth()->user()->name }}<small>{{ str_replace('_', ' ', auth()->user()->role) }}</small></div></div>
        <form method="post" action="{{ url('/logout') }}">@csrf<button class="logout" type="submit">Se déconnecter <span aria-hidden="true">↗</span></button></form>
        @else
        <div class="sidebar-note"><strong>Votre comptabilité, au même endroit.</strong><p>De l’opération quotidienne à la balance, gardez la maîtrise de vos chiffres.</p></div>
        @endauth
    </aside>
    <div class="body-wrap">
        <header class="topbar"><div>Espace entreprise <span>/</span> @yield('breadcrumb', 'Tableau de bord')</div><span class="badge neutral">PHP 8.4 · Laravel 12</span></header>
        <main id="main" tabindex="-1">
            @if(session('success'))<div class="notice success" role="status">{{ session('success') }}</div>@endif
            @if(session('status'))<div class="notice success" role="status">{{ session('status') }}</div>@endif
            @if($errors->any())<div class="notice danger" role="alert"><strong>Quelques informations sont à vérifier.</strong><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
            @yield('content')
        </main>
        <footer>SYSCOHADA CM <span>·</span> Comptabilité & préparation fiscale <small>Chaque opération reste sous votre contrôle.</small></footer>
    </div>
</div>
@stack('scripts')
</body>
</html>
