@extends('layout')
@section('title', 'Connexion')
@section('breadcrumb', 'Connexion')
@section('content')
<div class="login-wrap">
    <div class="eyebrow">BIENVENUE DANS VOTRE ESPACE</div>
    <h1>La comptabilité,<br>en toute clarté.</h1>
    <p class="lead">Connectez-vous pour retrouver vos entreprises, vos écritures et votre préparation DSF.</p>
    <section class="card login-card" aria-labelledby="login-title"><div class="card-head"><h2 id="login-title">Se connecter</h2><span class="badge neutral">Accès privé</span></div>
        <form method="post" action="{{ url('/login') }}" class="form-stack">@csrf
            <label>Adresse email<input name="email" type="email" value="{{ old('email') }}" autocomplete="username" required autofocus></label>
            <label>Mot de passe<input name="password" type="password" autocomplete="current-password" required></label>
            <button class="button primary full" type="submit">Ouvrir mon espace <span aria-hidden="true">→</span></button>
        </form>
        <p class="muted small">Votre accès est créé par l’administrateur de votre organisation.</p>
    </section>
</div>
@endsection
