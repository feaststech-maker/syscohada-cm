@extends('layout')
@section('title', $company->name)
@section('breadcrumb', 'Entreprise & exercices')
@section('content')
<div class="page-heading"><div><div class="eyebrow">VOTRE DOSSIER ENTREPRISE</div><h1>{{ $company->name }}</h1><p>{{ $company->niu ?: 'NIU à compléter' }} <span class="separator">·</span> {{ $company->accounting_system === 'SMT' ? 'Système minimal de trésorerie' : 'Système normal' }}</p></div><span class="badge {{ $company->virtual_accounting_enabled ? 'soft' : 'neutral' }}">{{ $company->virtual_accounting_enabled ? 'Comptabilité virtuelle activée' : 'Préparation DSF' }}</span></div>
<div class="split-grid"><section class="card"><div class="card-head"><div><h2>Exercices comptables</h2><p>Choisissez la période sur laquelle travailler.</p></div></div>
@forelse($years as $fy)
<div class="list-row"><div><strong>{{ \Illuminate\Support\Carbon::parse($fy->starts_on)->format('d/m/Y') }} — {{ \Illuminate\Support\Carbon::parse($fy->ends_on)->format('d/m/Y') }}</strong><small>{{ $fy->status === 'OPEN' ? 'Exercice ouvert' : 'Exercice clôturé' }}</small></div><div class="inline-actions"><a class="button secondary small" href="{{ url('/companies/'.$company->id.'/years/'.$fy->id.'/import') }}">Importer</a><a class="button primary small" href="{{ url('/companies/'.$company->id.'/years/'.$fy->id.'/accounting') }}">Ouvrir <span aria-hidden="true">→</span></a></div></div>
@if($fy->status === 'OPEN' && in_array(auth()->user()->role, ['TENANT_ADMIN', 'PLATFORM_ADMIN'], true))
<details class="year-close"><summary>Clôturer cet exercice</summary><p class="muted small">La clôture bloque toute nouvelle écriture ou correction sur cette période. Les brouillons doivent être traités avant la clôture ; le serveur vérifie leur absence.</p><form method="post" action="{{ url('/companies/'.$company->id.'/years/'.$fy->id.'/close') }}" class="form-stack">@csrf<label>Pour confirmer, saisissez CLOTURER<input name="confirmation" type="text" pattern="CLOTURER" autocomplete="off" placeholder="CLOTURER" required></label><button class="button secondary" type="submit">Confirmer la clôture</button></form></details>
@endif
@empty<div class="empty compact"><h3>Aucun exercice pour le moment.</h3><p>Ajoutez une période pour commencer.</p></div>@endforelse
</section>
<section class="card"><div class="card-head"><div><h2>Comptabilité virtuelle</h2><p>Un module optionnel pour les opérations du quotidien.</p></div><span class="badge {{ $company->virtual_accounting_enabled ? 'soft' : 'neutral' }}">{{ $company->virtual_accounting_enabled ? 'Activée' : 'Désactivée' }}</span></div><p>Ventes encaissées, dépenses payées, règlements clients et fournisseurs, transferts de trésorerie et saisie en partie double.</p><p class="muted">Le SMT ne dispense pas des informations de fin d’exercice : stocks, créances, dettes et autres éléments applicables restent à documenter.</p>
@if(in_array(auth()->user()->role, ['TENANT_ADMIN', 'PLATFORM_ADMIN'], true))
<form method="post" action="{{ url('/companies/'.$company->id.'/settings') }}" class="form-stack">@csrf<input type="hidden" name="virtual_accounting_enabled" value="0"><label class="check-line"><input type="checkbox" name="virtual_accounting_enabled" value="1" @checked($company->virtual_accounting_enabled)><span><strong>Activer le département comptable virtuel</strong><small>Désactiver la saisie conserve les écritures déjà enregistrées.</small></span></label><button type="submit" class="button secondary">Enregistrer l’option</button></form>
@endif
</section></div>
@if(in_array(auth()->user()->role, ['TENANT_ADMIN', 'ACCOUNTANT', 'PLATFORM_ADMIN'], true))
<section class="card mt"><div class="card-head"><div><h2>Ajouter un exercice</h2><p>Les dates doivent correspondre à la période comptable de l’entreprise.</p></div></div><form class="form-stack" method="post" action="{{ url('/companies/'.$company->id.'/years') }}">@csrf<div class="form-grid"><label>Date d’ouverture<input name="starts_on" type="date" value="{{ old('starts_on') }}" required></label><label>Date de clôture<input name="ends_on" type="date" value="{{ old('ends_on') }}" required></label></div><div class="actions end"><button class="button primary">Créer l’exercice</button></div></form></section>
@endif
@endsection
