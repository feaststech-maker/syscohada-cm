# SYSCOHADA CM Laravel — version 0.2.0

Application **PHP 8.4+ / Laravel 12** : import de balance DSF et module optionnel de comptabilité virtuelle pour les micro-entreprises. L’interface Blade est reliée aux contrôleurs et aux services Laravel ; elle ne dépend plus du backend Java. La démo publiée séparément permet d’explorer le parcours dans le navigateur, avec des données fictives en mémoire.

## Fonctions livrées

| Fonction | État |
| --- | --- |
| Comptabilité virtuelle par entreprise | Option désactivée par défaut, activable par l’administrateur |
| Saisie guidée | Vente encaissée, dépense payée, règlement client, paiement fournisseur, transfert banque/caisse et apport |
| Saisie détaillée | Écriture à plusieurs lignes, comptes et journaux propres à l’entreprise |
| Brouillons | Préparation, contrôle, suppression si non comptabilisé et sans pièce ; service de modification disponible |
| Comptabilisation | Débit=crédit, au moins deux lignes, pièce/référence, numéro atomique et exercice ouvert |
| Corrections | Nouvelle écriture exactement négative dans le même exercice ouvert ; original conservé |
| Livres | Journal, grand-livre, balance et trésorerie calculés sur les écritures comptabilisées |
| Balance → DSF | CSV exact et prévisualisation directement depuis la balance calculée, sans ressaisie |
| Pièces justificatives | PDF/JPEG/PNG privés, chiffrés avec contrôle de téléchargement par locataire |
| Import CSV/XLSX | Mapping intelligent et manuel, erreurs par ligne, convention explicite et montants exacts |
| Export Excel | Moteur d’injection physique sous approbation serveur ; aucun canevas actif livré |
| Administration | Activation de l’option, brouillons de paramètres/tarifs/règles, vérificateur de package signé côté serveur |
| Sécurité | Sessions, CSRF, limitation de connexion, scopes et PostgreSQL FORCE RLS, audit avant/après |

Le module apporte une tenue comptable assistée. Il ne crée pas automatiquement des prestations d’un expert-comptable, des déclarations déposées, des taux de TVA ou un plan de comptes exhaustif. Les opérations avec TVA, immobilisations, financement ou ventilation complexe utilisent la saisie détaillée et doivent être revues.

## Prérequis

- PHP 8.4 ou compatible ultérieur, testé avec **8.4.27**.
- Laravel **12.72.0**, PhpSpreadsheet **5.11.0**, Brick Math **0.14.8**, versions figées dans `composer.lock`.
- Extensions PHP requises par Composer : notamment PDO PostgreSQL, BCMath, Mbstring, DOM/XML, ZIP, GD, Fileinfo, OpenSSL et Sodium.
- PostgreSQL 17 pour la production ; SQLite local/test conserve les décimaux comme texte mais n’offre pas RLS.
- Serveur HTTPS dont le document root est **`public/`**, stockage privé et sauvegardes chiffrées.

Le paquet distribué peut inclure `vendor/` de production. Si absent, ou pour installer les outils de test :

```bash
composer install
```

Pour une installation de production depuis le fichier lock :

```bash
composer install --no-dev --prefer-dist --optimize-autoloader
composer check-platform-reqs --no-dev
```

## Essai local avec données fictives

Copier `.env.example` en `.env`, puis définir pour cet essai uniquement :

```dotenv
APP_ENV=local
APP_DEBUG=false
APP_URL=http://127.0.0.1:8000
DB_CONNECTION=sqlite
DB_DATABASE=/CHEMIN_ABSOLU/syscohada-cm-laravel/database/local.sqlite
SESSION_SECURE_COOKIE=false
```

Créer le fichier SQLite vide à l’emplacement indiqué. Conserver une clé d’application propre à cette installation :

```bash
php artisan key:generate
php artisan migrate
php artisan syscohada:tenant "Entreprise de test" admin@example.com --virtual-accounting
php artisan serve --host=127.0.0.1 --port=8000
```

Le mot de passe est demandé dans le terminal. Aucun compte par défaut n’est inclus. L’option `--virtual-accounting` active le module de la première entreprise ; sans cette option il reste désactivé. Le système SMT et le petit plan de départ sont des choix initiaux à confirmer selon l’éligibilité et l’activité, sans assimilations automatiques au régime fiscal.

Ouvrir `/login`, puis l’entreprise et l’exercice. Créer une opération guidée avec une référence de pièce, vérifier le brouillon et cliquer **Vérifier & comptabiliser**. Les livres se mettent à jour à partir des seules écritures comptabilisées. Depuis la balance, **Préparer ma DSF avec cette balance** transmet les soldes au contrôle d’import.

Pour un collaborateur supplémentaire :

```bash
php artisan syscohada:user TENANT_UUID comptable@example.com --role=ACCOUNTANT
```

Rôles disponibles : `TENANT_ADMIN`, `ACCOUNTANT`, `REVIEWER`, `READ_ONLY`. Le provisionnement s’exécute sous une identité de maintenance habilitée ; les droits de création d’utilisateurs ne sont pas accordés au compte financier web.

## Production et Hostinger

Suivre `docs/HOSTINGER-LARAVEL.md` et `docs/SECURITE.md`. Cette architecture PostgreSQL/RLS se déploie sur un **VPS Hostinger** ; la prise en charge du langage PHP sur un hébergement Web ne suffit pas à fournir PostgreSQL/RLS.

- Rôle de migration distinct, puis login web non propriétaire, non superutilisateur, sans `BYPASSRLS`.
- Le middleware refuse SQLite et un rôle PostgreSQL trop privilégié en production.
- Configuration finale : `APP_ENV=production`, `APP_DEBUG=false`, cookies Secure/HttpOnly, PostgreSQL TLS `verify-full` avec CA correcte.
- Seul `public/` est exposé. `.env`, `vendor/`, `storage/`, les clés et pièces ne sont pas publiés.
- `upload_tmp_dir`, `TMPDIR` et les temporaires Nginx doivent être sur mémoire privée ou stockage chiffré.
- Le chiffrement de fichier utilise Laravel AES-256-GCM et une enveloppe liée au tenant, société, écriture et hash. Protéger et sauvegarder `APP_KEY` ; la rotation exige de conserver les clés nécessaires aux anciens fichiers.
- Le rehachage de mot de passe à la connexion est désactivé afin que le runtime financier ne puisse écrire les mots de passe. Les évolutions de politique passent par la maintenance d’authentification habilitée.

Après configuration et migrations, exécuter `php artisan optimize` avec la configuration du runtime, jamais celle du rôle de migration.

## Décimaux et périodes

Les montants comptables restent en chaînes exactes jusqu’à six décimales et `numeric(28,6)` sur PostgreSQL. Les règles légales d’arrondi de déclaration interviennent ensuite, sans arrondi anticipé. Les cellules numériques Excel sont limitées par leur propre précision : au-delà, l’import exige du texte et l’export bloque une perte de précision.

La balance calculée ne devine pas une ouverture ou N−1. Il faut enregistrer les ouvertures réelles pour disposer des soldes complets. Les corrections de périodes antérieures nécessitent un traitement spécifique de report à nouveau : elles ne rouvrent pas silencieusement un exercice fermé. Dans la trésorerie, les corrections négatives diminuent le flux initial au lieu de créer un faux encaissement/décaissement opposé.

## DSF et modules restant à qualifier

L’import et le moteur d’injection sont portés en PHP. Le Bilan, le Compte de résultat, le TFT, toutes les notes et les tableaux fiscaux ne sont pas encore générés exhaustivement. Les fichiers DGI publics conservés dans `reference/` sont datés de 2021 et non qualifiés pour une nouvelle campagne. L’export officiel exige le canevas et nom canonique de campagne, le mapping complet, les données extra-comptables, les contrôles et une validation professionnelle avec recette autorisée.

Le noyau fiscal ne sélectionne pas automatiquement un profil légal. Le vérificateur de package signé contrôle Ed25519, hashes, versions, chemins et limites ZIP sans rien extraire ni exécuter. Les abonnements Mobile Money, le KMS externe, l’analyse antivirus, la MFA, le rapprochement bancaire automatique et l’orchestrateur de déploiement de packages signés restent à raccorder. L’administration enregistre des brouillons ; elle n’exécute jamais du code téléversé et n’active aucune règle fiscale sur simple saisie.

Les données de l’ancienne version Java ne sont pas automatiquement migrées en production : prévoir une reprise contrôlée et un rapprochement des soldes avant de basculer une installation existante.

## Tests et documentation

```bash
php artisan test
php tests/Database/migration-and-guards.php sqlite
```

Les essais PostgreSQL reproductibles et leur garde « base jetable » figurent dans `tests/Database/README.md`. Voir également `docs/TESTS.md`, `docs/MODULE-COMPTABILITE.md`, `docs/SECURITE.md`, `docs/SOURCES-FISCALES.md` et le contrat `app/Domain/Export/README.md`.
