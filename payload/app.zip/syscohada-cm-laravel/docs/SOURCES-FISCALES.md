# Sources fiscales et comptables — SYSCOHADA CM

Recherche effectuée le 11 novembre 2026. Ce mémo distingue les textes consultés, les classeurs réellement inspectés et les validations qui restent nécessaires avant un dépôt DGI.

## Références primaires

| Référence | Source et version | Utilité |
|---|---|---|
| DGI-DSF | https://impots.cm/fr/declarations-statistiques-et-fiscalesdsf | La DGI confirme Normal et SMT, informations générales, états financiers, notes et tableaux fiscaux. |
| DGI-FORMATS | https://impots.cm/fr/actualites/formats-de-la-dsf-en-ligne | Liens de téléchargement réels Normal, SMT, tiers et fournisseurs. |
| DGI-GUIDE2025 | https://impots.cm/sites/default/files/documents/GUIDE%20UTILISATEUR%20DSF%202025%20DU%2003-03-2025.pdf | Guide officiel de télédéclaration. Campagne 2025 = exercice 2024 dans ses exemples. |
| DGI-CGI2026 | https://www.impots.cm/index.php/fr/publication/code-general-des-impots-mis-jour-au-1er-janvier-2026 | Page de publication officielle du CGI au 1er janvier 2026. |
| DGI-CGI2026-PDF | https://www.impots.cm/sites/default/files/publications/CODE%20GENERAL%20DES%20IMPOTS%202026%20%20VERSION%20FRANCAISE.pdf | PDF téléchargé et lu localement. Les pages citées ci-dessous sont celles imprimées dans l'ouvrage. |
| OHADA-AUDCIF | https://www.ohada.org/acte-uniforme-relatif-au-droit-comptable-et-a-linformation-financiere-audcif/ | Adoption 26/01/2017 ; entrée en vigueur comptes personnels 01/01/2018. |
| OHADA-TEXTE | https://justice.sec.gouv.sn/wp-content/uploads/textes-reglements/OHADA/Acte-uniforme-relatif-droit-comptable-information-financiere-JAN-2017-JO.pdf | Reproduction officielle au ministère de la Justice du Sénégal ; article 13 et régime SMT. |

## Classeurs physiques téléchargés et inspectés

1. Normal : https://www.impots.cm/sites/default/files/2021-03/DSF_Normal_VEROUILLE-09-03-2021.xlsx
   - 2 464 348 octets ; 74 feuilles.
   - SHA-256 : `62ab79a85e4e8fc0681c0be3a3b20dbb31304e8eeb28dd2b6e2eae43a26e220a`.
2. SMT : https://www.impots.cm/sites/default/files/2021-03/DSF_SMT_VEROUILLE-09-03-2021.xlsx
   - 160 960 octets ; 28 feuilles.
   - SHA-256 : `ae9715e11e629ba3212f3a9215a8875d51d64488f4457bd7e06a44e085ba8204`.

Les fichiers sont dans `research/`. Les JSON adjacents donnent leurs feuilles et quelques libellés. Ils sont publiquement proposés par la DGI, mais leur nom est daté de 2021 : cela ne constitue pas une preuve d'acceptation pour la campagne 2026 ou 2027. Le modèle exact téléchargé depuis l'espace de télédéclaration de la campagne cible, puis un essai d'intégration, restent nécessaires.

Le guide 2025, pages 9-10, décrit le téléchargement du format Excel depuis la déclaration. Sa page 22 précise que le nom standard du modèle doit être respecté lorsqu'un message « nom du fichier erroné » apparaît. Le nom canonique est donc une métadonnée versionnée à obtenir pour chaque campagne, et pas simplement le nom du fichier public.

## Normal, SMT et notes

L'article 13 AUDCIF réserve le SMT, sauf option pour le Normal, aux petites entités dont le CA annuel HT est strictement inférieur à 60 millions FCFA pour le négoce, 40 millions pour l'artisanat et assimilés et 30 millions pour les services. Ce système ne supprime pas tous les travaux de fin d'exercice. Ne pas confondre éligibilité comptable OHADA et régime fiscal camerounais.

Le classeur Normal contient le Bilan paysage, le Compte de résultat, le Tableau des flux de trésorerie et un catalogue comprenant les notes 1 à 35, avec des sous-notes et tableaux de continuation (3A à 3F, 15A/B, 16A/B/Bbis/C, 27A/B, etc.). Il est incorrect de limiter la base à exactement 33 feuilles ou 33 formulaires. Les 33 notes demandées peuvent être couvertes par un catalogue extensible ; les notes supplémentaires du canevas ne doivent pas être supprimées. Le SMT public comporte six notes.

La balance de clôture seule ne suffit pas au TFT et à toutes les annexes. Il faut notamment les soldes d'ouverture et comparatifs N-1, mouvements d'immobilisations, amortissements, cessions et règlements, échéanciers, engagements et informations narratives. Une variation de solde ne constitue pas nécessairement un flux de trésorerie.

## Fiscalité 2026 : paramètres confirmés et périmètres

| Règle | Vérification dans le CGI 2026 | Implémentation recommandée |
|---|---|---|
| IS principal | Art. 17, p.23 : 30 %. | Règle de droit commun, hors régimes spéciaux. |
| IS selon CA | Art.17 bis, p.23 : 25 % pour CA au plus 3 milliards FCFA. | Critère de CA séparé du taux, versionné ; ne pas appliquer à tous les cas spéciaux. |
| Arrondi assiette IS | Art.17(3), p.23 : fractions de bénéfice imposable inférieures à 1 000 FCFA négligées. | BigDecimal ; arrondi d'assiette explicite au millier inférieur. |
| Minimum de perception | Art.22(2), p.34 : 2 % ou 14 % ; CAC de 10 %. Mention de 5 % pour le simplifié subsiste. | Profil sectoriel et régime fiscal obligatoires ; ne pas choisir 2 % universellement. |
| Base MP | Art.23, p.34 : CA global HT exercice précédent et arrondi millier inférieur ; marge brute, gratifications et commissions pour activités à marge administrée. | Stocker séparément exercice de référence et base ; interdire la substitution automatique par le seul CA courant. |
| Frais de siège | Art.7 A1d, p.9-10 : 2,5 % du bénéfice avant frais ; dernier exercice bénéficiaire non prescrit en cas de déficit ; situations de déficit continu/nouveau : base CA à 1 %, et base charges si aucun CA ; TP 1 % CA ; bureaux d'études réglementés 5 % CA ; exclusion des services comptables/fiscaux rémunérés hors CEMAC. | Arbre de décision avec pièces justificatives ; montant réintégré = charge comptabilisée moins déduction admissible ; pas de constante isolée 2,5 %. |
| Retenues | Art.22(3), p.34 : attestation de retenue à la source issue du SI fiscal obligatoire. | Crédits et acomptes distincts des réintégrations ; justificatif et absence de double imputation. |

Un moteur générique peut calculer `résultat fiscal = résultat comptable + réintégrations - déductions` et comparer IS et MP. Le point de départ avant/après impôt doit être explicite : le CF1 du classeur public est un passage du résultat comptable AVANT impôt au résultat fiscal. Ne pas ajouter à nouveau l'IS si le résultat fourni est déjà avant impôt.

Les déficits reportables, amortissements réputés différés, crédits et régimes dérogatoires exigent des sous-registres de suivi et des règles propres ; ce mémo ne prétend pas homologuer leur calcul complet.

## Changement de régime fiscal à prendre en compte

Le CGI 2026, article 93 ter, p.57, liste notamment l'Impôt général synthétique (IGS) et le réel. L'article 93 quater fixe des seuils de 50 millions pour les activités commerciales/industrielles/artisanales/agropastorales, et 30 millions pour les professions libérales, avec exceptions sectorielles et de démarrage. L'article C39, p.287, décrit également l'IGS. Le libellé de frontière n'est pas identique entre 93 quater (« inférieur ») et C39 (« n'excède pas »), d'où une revue particulière au montant exact du seuil.

Conséquence : ne pas présenter « Normal = réel / SMT = simplifié » comme règle universelle de 2026 sur la seule base de la page DGI relative au décret 2019. Conserver deux dimensions : `accounting_system` (NORMAL/SMT) et `tax_regime` (REAL/IGS/legacy/SPECIAL), datées et approuvées. L'IGS ne doit pas recevoir mécaniquement le calcul IS/MP de droit commun ; les personnes physiques peuvent relever d'une autre déclaration annuelle.

## API DGI : existence confirmée, implémentation non inventée

Le guide 2025, pages 7-8, confirme une API officielle pour systèmes web : activation dans le profil, mot de passe API, jeton temporaire et documentation via l'onglet Aide. Il énumère huit opérations générales, dont gestion des déclarations, pages et soumission. Les URL, schémas JSON exacts et conditions d'accès ne sont pas publics dans ce guide. Prévoir un adaptateur, mais ne pas créer de faux endpoints ni prétendre qu'aucune API n'existe. L'export Excel demeure le canal initial demandé.

## Conditions bloquantes avant export fiscal officiel

- Canevas exact de la campagne, empreinte, nom de fichier canonique et provenance validés.
- Mapping cellule/feuille approuvé ; espaces de fin des noms de feuilles conservés à l'identique.
- Aucun remplacement de formule, aucune nouvelle ligne/colonne/feuille, aucune suppression d'annexe.
- Jeu fiscal applicable approuvé et figé avec l'exercice ; exercices clos reproductibles.
- Informations N-1, annexes et données extra-comptables complètes.
- Contrôles de balance, actif/passif, résultat et variation de trésorerie réussis ; exceptions documentées.
- Comparaison de structure et tests de non-régression du classeur exporté.
- Validation professionnelle et essai de téléversement dans l'environnement DGI autorisé.

Ces éléments sont des conditions de livraison d'un export fiable, pas une garantie absolue d'acceptation par un portail externe.
