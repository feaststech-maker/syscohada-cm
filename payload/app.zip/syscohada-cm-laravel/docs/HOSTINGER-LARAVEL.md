# Déployer SYSCOHADA CM Laravel sur Hostinger

Procédure pour la version PHP 8.4+ / Laravel 12, avec PostgreSQL 17 en production. Les étapes Java de la première version ne s’appliquent plus : le serveur exécute PHP-FPM et sert le répertoire Laravel `public/`.

## Choix de l’offre

Hostinger permet l’hébergement Laravel sur certaines offres Web/Cloud et propose PHP 8.4 dans sa configuration PHP. Cela ne rend pas toute architecture Laravel compatible avec toutes ces offres. **Cette version de SYSCOHADA CM utilise PostgreSQL et ses politiques RLS ; le déploiement retenu demande donc un VPS**, sauf fourniture séparée d’une base et d’une infrastructure répondant aux mêmes exigences.

Hostinger indique que PostgreSQL est pris en charge sur VPS, et non sur ses offres Web/Cloud. Ne pas remplacer PostgreSQL par MySQL ou SQLite en production en conservant la promesse d’isolation RLS : ce changement demanderait une autre conception et une recette spécifique. SQLite sert au développement et à certains tests applicatifs ; il ne valide pas les protections PostgreSQL.

Un VPS existant doit être conservé et configuré sans réinstaller son système. Pour un nouveau VPS, choisir une distribution maintenue fournissant PHP 8.4, ou installer PHP 8.4 depuis une source de paquets validée. Vérifier à la fois la version PHP en ligne de commande et celle du processus PHP-FPM ; elles peuvent différer.

## 1. Domaine et accès

Dans hPanel, ouvrir le VPS puis relever son IP et les informations SSH. Créer, dans la zone DNS autoritaire du domaine, un enregistrement A pour un sous-domaine tel que `dsf.votredomaine.com`, pointant sur le VPS. Ne modifier que les enregistrements conflictuels de ce nom afin de préserver le site principal et les emails.

Utiliser un compte de déploiement et des clés SSH. Le processus PHP-FPM n’utilise pas le compte root. Dans le pare-feu, limiter SSH aux accès administratifs nécessaires, exposer HTTPS et les ports de validation de certificat requis, et ne pas publier PostgreSQL.

## 2. Vérifier les dépendances

```bash
php -v
php -m
composer --version
```

Le projet fixe PHP 8.4+ dans `composer.json`. Les extensions utiles comprennent PDO et `pdo_pgsql`, mbstring, OpenSSL, sodium, DOM/XML, ZIP, GD, cURL, Fileinfo et BCMath. La résolution Composer et `composer check-platform-reqs` constituent le contrôle final des extensions requises par les versions verrouillées. Installer aussi Nginx et PHP-FPM 8.4 ; l’installation exacte dépend de la distribution du VPS.

## 3. Déployer les sources hors de la racine publique

Décompresser le paquet dans un répertoire applicatif tel que `/var/www/syscohada`, puis utiliser cette racine pour les commandes Artisan. Ne pas téléverser seulement le contenu de `app/` et ne pas exposer `.env`, `vendor/`, `storage/` ou les fichiers de configuration au public.

```bash
cd /var/www/syscohada
composer install --no-dev --prefer-dist --optimize-autoloader
composer check-platform-reqs --no-dev
```

Ne pas lancer `composer update` lors de chaque mise en ligne : le fichier `composer.lock` livré fixe le jeu de dépendances à installer. Ne pas utiliser `--ignore-platform-reqs` pour faire démarrer un serveur incompatible. Les paquets de test ne sont pas installés dans le runtime de production.

La distribution utilise les assets fournis avec l’interface Blade. Si une version future introduit un build Vite, ce build doit être exécuté dans la chaîne de livraison ; ne pas laisser un serveur de développement Vite exposé sur Internet.

## 4. Configurer l’application

Créer `.env` à partir du fichier `.env.example` livré et renseigner les paramètres réellement supportés par `config/`. Les valeurs suivantes sont indispensables :

| Paramètre | Valeur de production attendue |
| --- | --- |
| `APP_ENV` | `production` |
| `APP_DEBUG` | `false` |
| `APP_URL` | URL HTTPS finale |
| `APP_KEY` | Clé propre à l’installation, sauvegardée de manière sécurisée |
| Connexion DB | PostgreSQL, nom et identifiants du compte runtime limité |
| Sessions | Cookie Secure/HttpOnly et stockage non public, conforme à la configuration livrée |
| Pièces privées | Stockage hors webroot, clés protégées et sauvegardes chiffrées |

Pour une **nouvelle installation seulement**, générer la clé après préparation du fichier :

```bash
php artisan key:generate --force
```

Ne jamais régénérer aveuglément `APP_KEY` lors d’une mise à jour : les pièces et autres valeurs chiffrées peuvent dépendre de cette clé. Une rotation exige une stratégie conservant les anciennes clés nécessaires et une recette de déchiffrement.

Les secrets ne vont ni dans Git, ni dans un fichier téléchargeable, ni dans un message d’erreur. Le compte de service doit lire la configuration nécessaire, sans disposer de droits d’écriture sur le code source. Seuls les répertoires de cache et de stockage prévus doivent être inscriptibles ; ne pas appliquer `chmod 777` au projet.

## 5. Préparer PostgreSQL avec deux niveaux de privilèges

Créer la base et un rôle de migration distinct. Exécuter les migrations dans un job de déploiement protégé, avec les identifiants de ce rôle :

```bash
php artisan migrate --force
```

Le compte du serveur web est ensuite un **runtime non propriétaire, non superutilisateur et sans `BYPASSRLS`**. Il n’est pas membre du rôle propriétaire. Appliquer les privilèges et politiques décrits dans `SECURITE.md` ; un démarrage réussi sous le compte propriétaire ne démontre pas l’isolation des entreprises.

Le contexte de locataire et d’acteur est établi à partir de la session authentifiée, dans la transaction du serveur. Il ne provient pas d’un en-tête ou d’un champ modifiable par le navigateur. Tester l’accès à deux entreprises et deux locataires avec le vrai login runtime.

PostgreSQL reste sur une interface privée/locale, avec une connexion TLS vérifiée et le certificat d’autorité approprié lorsqu’une connexion TCP est utilisée. Employer les variables de connexion définies dans le `.env.example` et la configuration PostgreSQL livrés ; ne pas ajouter une variable de certificat que le code ne lirait pas.

Créer le premier locataire et l’administrateur par la commande de provisionnement :

```bash
php artisan syscohada:tenant "Entreprise" admin@example.com --virtual-accounting
```

Le mot de passe est demandé dans le terminal ; il n’est pas passé en argument. Pour créer ensuite un utilisateur dans un locataire existant :

```bash
php artisan syscohada:user TENANT_UUID comptable@example.com --role=ACCOUNTANT
```

Remplacer les exemples d’adresse et l’UUID par les valeurs de l’installation. Les commandes doivent être exécutées sous le rôle et le contexte de provisionnement décrits dans le README. Le formulaire de connexion n’accorde pas le statut administrateur et ne crée pas automatiquement une entreprise. Aucun mot de passe par défaut partagé ne doit être actif.

## 6. Configurer Nginx vers `public/index.php`

Exemple à adapter au domaine, au chemin et au socket PHP-FPM de votre VPS. Activer HTTPS avant toute utilisation avec des données réelles.

```nginx
server {
    listen 80;
    server_name dsf.votredomaine.com;
    root /var/www/syscohada/public;
    index index.php;
    charset utf-8;
    client_max_body_size 9m;

    add_header X-Content-Type-Options nosniff always;
    add_header X-Frame-Options SAMEORIGIN always;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ ^/index\.php(/|$) {
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        fastcgi_param DOCUMENT_ROOT $realpath_root;
        fastcgi_pass unix:/run/php/php8.4-fpm.sock;
        fastcgi_hide_header X-Powered-By;
    }

    location ~ \.php$ { return 404; }
    location ~ /\.(?!well-known).* { deny all; }
}
```

Le socket ci-dessus doit exister sur votre installation ; il n’est pas universel. Tester avec `nginx -t` avant rechargement. Installer ensuite un certificat HTTPS et son renouvellement selon la méthode de votre VPS, puis vérifier la redirection HTTP vers HTTPS. Ne pas déplacer `index.php` à la racine du projet pour contourner un mauvais document root.

Pour les factures et balances, configurer **les deux couches temporaires** : `upload_tmp_dir` de PHP-FPM et le répertoire temporaire des corps de requêtes Nginx doivent se trouver sur un montage mémoire privé ou un stockage chiffré. Le chiffrement final de la pièce ne supprime pas les copies temporaires produites par PHP ou Nginx. Contrôler les limites d’import PHP (`upload_max_filesize`, `post_max_size`) et Nginx ; garder une limite cohérente avec celle du contrôleur.

## 7. Mettre en cache et redémarrer les services

Une fois les identifiants runtime et la configuration finale en place :

```bash
php artisan optimize
```

Recharger PHP-FPM selon le gestionnaire du VPS. Si des workers sont activés, les redémarrer après déploiement avec le gestionnaire de processus prévu. Ajouter `schedule:run` par cron uniquement pour les tâches réellement configurées ; cette commande ne crée pas à elle seule des rappels ou des déclarations automatiques.

La configuration mise en cache doit correspondre au rôle DB runtime, pas au rôle de migration. Un changement de `.env` demande une reconstruction appropriée du cache avant de vérifier le comportement final.

## 8. Recette avant ouverture

- Vérifier connexion/déconnexion, expiration de session et protection CSRF.
- Créer deux locataires de test ; refuser lecture, écriture et téléchargement de pièce du voisin.
- Activer puis désactiver la comptabilité virtuelle d’une entreprise ; contrôler les droits côté serveur.
- Créer une écriture équilibrée et une déséquilibrée ; la seconde ne peut pas être comptabilisée.
- Vérifier que la seconde validation du même brouillon ne crée pas une seconde écriture ni un second numéro.
- Vérifier l’immuabilité après comptabilisation, la correction en négatif et le blocage d’exercice fermé.
- Rapprocher les livres avec les écritures de test et contrôler les montants décimaux.
- Importer un CSV et un XLSX fictifs, puis essayer une formule et une colonne ambiguë.
- Contrôler que les canevas DGI non qualifiés restent bloqués pour l’export officiel.
- Tester une sauvegarde et une restauration de la base, des pièces et des clés avant l’ouverture commerciale.

Cette procédure héberge la version Laravel et son interface serveur. Les fonctionnalités non raccordées ou non qualifiées dans le README ne deviennent pas disponibles par le seul déploiement. Le code Laravel 12 demandé doit continuer à recevoir ses correctifs de sécurité ; la politique officielle annonce une fin des correctifs de sécurité de cette branche le 24 février 2027, à prendre en compte pour la maintenance.

## Références officielles consultées le 11 novembre 2026

- [Hostinger — PHP et choix de version](https://www.hostinger.com/support/1575755-how-to-change-the-php-version-of-your-hostinger-hosting-plan/).
- [Hostinger — technologies et Laravel](https://www.hostinger.com/support/which-programming-languages-and-frameworks-are-supported-at-hostinger/).
- [Hostinger — bases de données et PostgreSQL](https://www.hostinger.com/support/which-databases-and-data-tools-are-supported-at-hostinger/).
- [Laravel 12 — déploiement](https://laravel.com/framework/docs/12.x/deployment) et [source officielle de la branche 12.x](https://github.com/laravel/docs/blob/12.x/deployment.md).
- [Laravel — politique de support](https://laravel.com/framework/docs/12.x/releases).
- [Composer — options d’installation](https://getcomposer.org/doc/03-cli.md).
