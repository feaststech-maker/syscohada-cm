# Sécurité du socle Laravel 12 / PHP 8.4

Cette version ajoute une comptabilité virtuelle facultative à la préparation de DSF. Elle ne doit pas transformer une suggestion automatique en écriture définitive sans contrôle. L’administrateur d’entreprise active le module ; sa désactivation conserve les écritures et l’historique. Les journaux, pièces et soldes ne constituent pas à eux seuls une validation fiscale ou une acceptation DGI.

## Frontières d’identité et de locataire

L’authentification Laravel utilise une session serveur, le hachage de mot de passe fourni par le framework, la régénération de session à la connexion et les protections CSRF sur les mutations. L’identifiant du locataire provient de l’utilisateur authentifié et activé. Un champ `tenant_id` transmis par navigateur n’établit jamais l’autorisation. Chaque requête comptable doit contrôler le rôle puis la société et l’exercice dans ce locataire.

`users` est un répertoire d’authentification global pour permettre la recherche d’email avant connexion ; il est délibérément hors RLS. Il ne doit avoir aucun endpoint de listing global destiné aux clients. L’email est unique globalement dans ce socle. Un administrateur SaaS ne doit pas recevoir automatiquement des droits de modification sur les écritures d’une entreprise ; l’intervention doit passer par un mécanisme d’assistance explicite, audité et à développer si requis.

En production : HTTPS, cookies `Secure` et `HttpOnly`, `SameSite` adapté, limitation des tentatives de connexion, arrêt des utilisateurs désactivés, `APP_DEBUG=false` et secrets hors dépôt. Le serveur web pointe exclusivement sur `public/`, jamais sur la racine contenant `.env`, `vendor/` et `storage/`. Ne pas désactiver CSRF pour contourner un problème de connexion. L’activation de règles fiscales et de versions logicielles doit obtenir un contrôle renforcé d’identité et un second approbateur.

## PostgreSQL : RLS comme deuxième barrière

La migration active et force la sécurité par ligne sur toutes les tables métier. La politique exige `tenant_id = public.dsf_current_tenant()` ; pour `tenants`, elle compare `id`. Sans contexte, aucune donnée métier n’est visible. Les clés étrangères des données comptables comprennent le locataire et la société : une ligne ne peut pas prendre un compte ou un exercice appartenant à une autre société par simple substitution d’UUID.

Le middleware financier ouvre une transaction, puis utilise des paramètres SQL et une portée locale :

```sql
SELECT set_config('app.tenant_id', :authenticated_tenant, true);
SELECT set_config('app.actor_id', :authenticated_actor, true);
SELECT set_config('app.request_id', :server_request_uuid, true);
```

Le troisième paramètre `true` est essentiel : le contexte disparaît à la fin de transaction et ne contamine pas un autre utilisateur sur une connexion du pool. Les workers et commandes qui manipulent plusieurs entreprises doivent également ouvrir un contexte distinct par tâche, contrôler l’adhésion et le rôle, puis le fermer. Une requête globale « administrateur » ne doit pas utiliser un contournement RLS implicite.

### Séparer migration et exploitation

Le rôle de migration est propriétaire du schéma. Le rôle web est un login distinct **non propriétaire, non superutilisateur, sans `BYPASSRLS` ni droits de création**. PostgreSQL permet au superutilisateur et aux rôles `BYPASSRLS` de contourner RLS : leur utilisation comme connexion Laravel annulerait cette deuxième barrière. L’isolation n’est donc pas une promesse absolue indépendante de la configuration du serveur.

La migration ne crée aucun rôle de production ni mot de passe. Un exploitant habilité provisionne ces rôles et attribue les droits séparément. Exemple de plafond de droits pour le processus web ; les services applicatifs doivent encore vérifier les permissions métier :

```sql
CREATE ROLE syscohada_runtime NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS;
-- Créer le login API séparément et fournir son secret depuis un coffre.
GRANT syscohada_runtime TO syscohada_api;
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
GRANT USAGE ON SCHEMA public TO syscohada_runtime;
GRANT SELECT ON tenants, users, companies, fiscal_years, accounts, journals,
  entries, entry_lines, tax_adjustments, rule_sets, dgi_templates,
  financial_statements, attachments, audit_events, admin_settings TO syscohada_runtime;
GRANT INSERT, UPDATE ON companies, fiscal_years, accounts, journals, entries,
  entry_lines, tax_adjustments, financial_statements, attachments TO syscohada_runtime;
GRANT DELETE ON entry_lines, entries TO syscohada_runtime;
GRANT INSERT ON admin_settings TO syscohada_runtime; -- DRAFT-only constraint, no rule activation
GRANT UPDATE (remember_token, updated_at) ON users TO syscohada_runtime;
GRANT EXECUTE ON FUNCTION public.dsf_current_tenant(), public.dsf_current_actor() TO syscohada_runtime;
```

Le changement ou rehachage d’un mot de passe appartient à un service d’authentification dédié avec droits contrôlés ; le rôle financier ci-dessus ne peut modifier ni mot de passe, ni rôle, ni locataire d’un utilisateur. Le rehachage automatique à la connexion est désactivé dans `config/hashing.php` ; il doit être effectué par la maintenance habilitée après changement du coût de hachage : cette évolution exige de raccorder le service d’authentification et ne justifie pas un droit global de modification des utilisateurs.

Le rôle web ne reçoit ni `TRUNCATE`, ni modification de l’audit, ni insertion manuelle d’audit PostgreSQL, ni modification des rôles, règles actives ou abonnements. L’administration des utilisateurs et le provisionnement utilisent un service ou une commande séparés avec une identité dédiée. Le premier provisionnement doit installer un contexte de locataire/acteur audité avant de créer les données métier. Ne pas exécuter `migrate:fresh` sur une base utile ; les migrations destructives servent uniquement une base de développement ou de test jetable.

La connexion PostgreSQL distante utilise TLS avec vérification du certificat et du nom (`sslmode=verify-full` et autorité de confiance). Les ports de base de données restent privés. Un backup chiffré, restaurable et régulièrement testé est indispensable.

## Écritures : publication irréversible et corrections explicites

Le modèle distingue `DRAFT` et `POSTED`. Un brouillon peut être préparé en plusieurs étapes. La publication attribue un numéro journal/exercice, un auteur et une date, et s’effectue dans une transaction avec verrou pour éviter les numéros doublés et la publication concurrente.

Le service utilise des décimaux exacts. Les triggers PostgreSQL ajoutent une défense indépendante du contrôleur web :

- au moins deux lignes, chacune avec un seul côté non nul ;
- total débit égal au total crédit, sans tolérance flottante ;
- exercice ouvert et date située dans ses bornes ;
- module de comptabilité virtuelle activé pour la société ;
- référence documentaire non vide ou pièce justificative liée à l’écriture (ou à son original pour une correction) ;
- comptes actifs, auteur appartenant au locataire et auteur de publication habilité ;
- interdiction de modifier ou supprimer une écriture publiée, ou ses lignes ;
- exercice fermé immuable et bornes d’exercice non modifiables après publication.

Une correction de l’exercice courant référence l’original publié, dans le même journal et le même exercice, et inscrit exactement les montants négatifs sur les mêmes comptes et côtés. Elle ne remplace ni ne supprime l’original. La contrainte unique sur `reversal_of` interdit une seconde correction automatique du même original. Les corrections d’exercices antérieurs, les ajustements de report à nouveau et leur information en notes exigent un workflow spécifique et ne doivent pas être simulés par la réouverture d’un exercice fermé.

Les contrôles s’appuient sur l’AUDCIF, notamment les articles 17, 19, 20 et 22. L’activation du SMT n’exonère pas de tenir les informations et travaux complémentaires applicables. Les profils de comptes proposés sont des aides de saisie à qualifier ; leur paramétrage ne remplace pas la revue du comptable.

## Montants et SQLite de développement

PostgreSQL conserve `numeric(28,6)`. L’application ne passe aucun montant par `float` pour totaliser, comparer ou comptabiliser. Les APIs rendent les décimaux comme chaînes et appliquent des règles explicites d’échelle et d’arrondi.

Pour SQLite local et les tests, les montants sont des **chaînes TEXT**, car une colonne SQLite `NUMERIC` peut convertir une chaîne décimale en `REAL` et perdre de la précision. Les agrégats SQLite sont calculés dans le domaine décimal PHP. SQLite n’offre pas RLS : les scopes et contrôles applicatifs assurent seuls la séparation dans ce mode. Cette configuration facilite l’essai local ; elle n’établit pas les garanties PostgreSQL de production.

## Audit, fichiers et secrets

Les triggers PostgreSQL capturent chaque mutation métier avec UUID, locataire, acteur, table, action, identifiant, valeurs avant/après, identifiant de requête et date. L’acteur et le contexte tenant sont obligatoires. Le runtime ne peut pas modifier ou vider l’audit. L’exploitant système reste capable de modifier la base : une conservation externe immuable, un export signé ou un stockage WORM constitue une couche supplémentaire à raccorder pour les exigences fortes de preuve.

Les valeurs d’audit sont elles-mêmes des données financières sensibles. Chiffrer les volumes PostgreSQL et sauvegardes, limiter les droits de lecture et ne jamais recopier les corps des écritures ou jetons dans les logs opérationnels. Les durées de conservation et procédures d’effacement doivent être validées selon les obligations applicables avant mise en production.

Les pièces justificatives restent hors webroot, sous chemin généré côté serveur et lié au locataire/société. Le téléchargement doit refaire l’autorisation, ne jamais renvoyer une URL publique permanente et servir un fichier comme pièce jointe avec un type sûr. Contrôler extension, MIME réel, taille, nom et contenu hostile ; ne pas charger une macro ou une formule comme programme. Chiffrer le contenu au repos avec gestion de clés séparée et prévoir la rotation. Un hash SHA-256 prouve l’intégrité des octets, pas l’authenticité fiscale d’une facture.

Les packages de mise à jour téléversés ne sont jamais exécutés directement par PHP. Validation de signature, anti-retour, scan, construction isolée, test de migration, sauvegarde/restauration, staging et activation par un service distinct restent nécessaires. Un bouton frontend ne doit pas donner au serveur web un accès administrateur au VPS.

## Références primaires

- Laravel 12, authentification et déploiement : https://laravel.com/docs/12.x/authentication et https://laravel.com/docs/12.x/deployment
- PostgreSQL 17, sécurité par ligne : https://www.postgresql.org/docs/17/ddl-rowsecurity.html
- PostgreSQL, variables de configuration locales : https://www.postgresql.org/docs/17/sql-set.html
- OHADA, AUDCIF : https://www.ohada.org/acte-uniforme-relatif-au-droit-comptable-et-a-linformation-financiere-audcif/

Les vérifications exécutées sur le livrable sont consignées dans le rapport de tests de la version ; ce document ne revendique pas un audit de sécurité complet ni une homologation de l’export DGI.
