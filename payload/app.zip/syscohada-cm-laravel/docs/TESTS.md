# Vérifications de la version Laravel 0.2.0

Environnement réellement utilisé : PHP 8.4.27, Laravel 12.72.0, PostgreSQL 17.11. Les dépendances sont installées et figées par Composer ; il ne s’agit pas de classes isolées présentées comme un framework complet.

## Suite PHP

**56 tests et 178 assertions réussis, aucun échec ni erreur.** Le résultat final de la suite se trouve dans `TEST-RESULTATS.txt` à la racine du paquet.

- Parsing FR/EN, grande précision décimale, CSV multiligne et XLSX numérique brut.
- Mapping automatique, ambiguïtés, formats inconnus et contrôles de balance.
- Refus des formules importées, macros, relations externes, entités XML et archives excessives.
- Injection d’un modèle physique de test, empreinte, coordonnées, statut d’approbation, formules et précision Excel.
- Réconciliation fiscale paramétrable, période et approbation des règles.
- Option comptable, périodes, rôles et séparation tenant/entreprise.
- Publication équilibrée, numérotation/idempotence, pièces et écritures définitives.
- Corrections exactement négatives et annulation du flux initial sans inventer un flux opposé.
- Agrégats dépassant la capacité d’une seule ligne, sans passage par un flottant.
- Parcours HTTP réel : pages Blade, opération guidée, publication, CSV de balance et préparation DSF.
- Connexion/déconnexion, identifiants refusés et rejet CSRF hors contournement des tests.
- Vérification des mises à jour signées Ed25519, contenu altéré, chemins, symlinks et expansion ZIP.
- Pièce chiffrée privée et téléchargement inter-locataires refusé.

## PostgreSQL réel

Migration et tests de garde exécutés sur une base jetable : RLS lecture/écriture/insertion, contraintes composites, publication, pièces/références, immutabilité des écritures/lignes, correction négative, audit et clôture. Un essai des services Laravel a également utilisé un login non propriétaire et sans BYPASSRLS : numéro de publication, somme `9999999999999999.123456`, correction puis solde zéro et contexte effacé à la fin de transaction.

Les scripts reproductibles sont dans `tests/Database/`. Ils exigent une base de test vide et un consentement d’exécution explicite par variable ; ils ne doivent pas cibler une base de clients.

Le middleware HTTP de production a aussi été exécuté sur PostgreSQL avec le rôle runtime limité : `/dashboard` retourne 200, les politiques de la migration 002 sont actives et le contexte est effacé après requête. Les commandes réelles `syscohada:tenant` et `syscohada:user` ont créé et vérifié un administrateur, un comptable, une société, un exercice et les comptes/journaux de départ dans une base jetable.

## Interface

Vues Blade compilées et huit pages/parcours principaux rendus dans les tests HTTP. Démo statique : syntaxe JavaScript et 27 assertions réussies pour l’import et la comptabilité ; essai navigateur de l’activation, du dossier fictif, de la comptabilisation et des livres.

La démo publiée reste en mémoire dans l’onglet. Le serveur Laravel et ses pièces privées s’installent sur votre hébergement ; le site de démonstration n’héberge pas PHP.

## Limites

Ces tests ne constituent ni une homologation DGI, ni un audit complet, ni un test de charge. Pas de données réelles de contribuables, de paiement Mobile Money ou de dépôt fiscal. La génération exhaustive du Normal/SMT, les annexes et la qualification des canevas de campagne restent à terminer. Aucun package téléversé n’est installé par l’application web.
