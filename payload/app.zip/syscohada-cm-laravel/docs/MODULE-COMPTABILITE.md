# Comptabilité virtuelle des micro-entreprises

Document de conception et d’utilisation du module optionnel de SYSCOHADA CM, version Laravel 12 / PHP 8.4+. Le module fournit un espace de tenue comptable et de contrôle. Il ne crée pas un cabinet d’expertise comptable et ne produit pas automatiquement un visa professionnel.

## Activer l’option entreprise par entreprise

Le champ `companies.virtual_accounting_enabled` est désactivé par défaut. L’administrateur de l’entreprise peut l’activer pour l’espace concerné. Les droits d’abonnement peuvent ensuite conditionner cette activation côté serveur ; une case cochée dans le navigateur n’accorde aucun droit commercial à elle seule.

La désactivation bloque la création, la comptabilisation et la correction d’écritures dans ce module. Les livres existants restent consultables : la désactivation n’efface ni l’historique ni les justificatifs. La sélection SMT/Normal et le régime fiscal sont deux paramètres indépendants ; activer la comptabilité virtuelle ne choisit pas un régime fiscal.

## Parcours proposé

1. L’administrateur crée l’entreprise, son exercice, les comptes et les journaux utiles.
2. L’utilisateur choisit une opération guidée ou saisit une écriture en partie double.
3. Le système prépare un brouillon, avec date, libellé, référence et lignes de débit/crédit.
4. L’utilisateur vérifie les comptes, la pièce justificative et l’équilibre. Une pièce ne constitue pas à elle seule une affectation comptable correcte.
5. Un utilisateur habilité comptabilise. La numérotation est attribuée dans une transaction verrouillée ; le même brouillon ne peut être comptabilisé deux fois.
6. Les écritures comptabilisées alimentent les journaux, le grand-livre, la balance et le livre de trésorerie.
7. L’exercice est revu puis clôturé. Une écriture nouvelle ou une correction directe est refusée dans un exercice fermé.

Un brouillon peut être incomplet ou déséquilibré pendant la préparation. La comptabilisation exige au moins deux lignes valides et l’égalité exacte entre débit et crédit. Les comptes, le journal et l’exercice doivent appartenir à la même entreprise et au même locataire. La date doit être comprise dans l’exercice ouvert.

## Opérations guidées

Les comptes ne sont pas déduits de façon définitive à partir d’un simple texte. L’utilisateur sélectionne les comptes disponibles et valide leur pertinence. Aucun taux de TVA, de retenue ou d’impôt n’est appliqué implicitement.

| Opération | Débit à confirmer | Crédit à confirmer | Point de contrôle |
| --- | --- | --- | --- |
| Vente encaissée | Compte de trésorerie | Compte de produit choisi | Encaissement réellement reçu ; pièce de vente |
| Dépense payée | Compte de charge ou d’actif approprié | Compte de trésorerie | Distinguer charge, immobilisation, stock et avance |
| Encaissement d’un client | Trésorerie | Compte client | Ne pas enregistrer une seconde fois le produit déjà comptabilisé |
| Paiement d’un fournisseur | Compte fournisseur | Trésorerie | Ne pas doubler une charge déjà enregistrée à la facture |
| Transfert banque/caisse | Trésorerie destinataire | Trésorerie d’origine | Aucun produit ou charge créé par le transfert interne |
| Apport de l’exploitant | Trésorerie | Capital, compte de l’exploitant ou dette appropriée | Le compte dépend de la nature juridique de l’apport ; ce n’est pas une vente |

Les factures non encaissées, acomptes, emprunts, remboursements de capital, dépenses personnelles, opérations avec TVA et éléments d’inventaire demandent un traitement adapté. Le mode manuel reste disponible pour une écriture validée par une personne compétente. Le module ne classe pas automatiquement toutes ces opérations dans les charges ou les recettes.

## Livres et indicateurs

| Vue | Données utilisées | Limite à garder visible |
| --- | --- | --- |
| Journal | Écritures comptabilisées du journal et de l’exercice | Les brouillons sont exclus des totaux comptables |
| Grand-livre | Mouvements comptabilisés compte par compte | Le solde historique nécessite la reprise d’ouverture réelle |
| Balance générale | Total débit, crédit et solde par compte | Une balance équilibrée n’atteste pas l’exhaustivité ni la bonne imputation |
| Livre de trésorerie | Lignes de comptes signalés comme trésorerie | Un transfert interne ne doit pas gonfler les recettes/dépenses agrégées ; une correction en négatif réduit la catégorie du flux d’origine, sans créer un flux opposé |
| Tableau de bord | Statuts, totaux et opérations à traiter | Trésorerie et bénéfice sont des notions différentes |

Les montants sont transmis sous forme de chaînes décimales, puis traités avec un calcul décimal exact. Le serveur décide des totaux et des droits. Les calculs flottants JavaScript ne sont pas une source comptable. Les soldes d’ouverture, comparatifs et inventaires manquants ne deviennent jamais des zéros inventés.

## Écritures définitives et corrections

Après comptabilisation, l’écriture et ses lignes sont immuables. Un utilisateur ne modifie pas discrètement un montant, une date ou un compte comptabilisé, même s’il possède un rôle d’administration. Un essai de suppression ou de mutation est rejeté.

Pour une erreur commise et découverte dans l’exercice ouvert, le parcours de correction conserve l’original et prépare une inscription en négatif des lignes erronées, dans les mêmes comptes et du même côté. L’enregistrement exact est ensuite saisi dans une nouvelle écriture. La correction porte un motif et un lien vers l’écriture d’origine ; une même écriture ne peut recevoir deux annulations intégrales concurrentes. Cette logique répond au mécanisme de correction de l’article 20 AUDCIF, sans transformer le brouillon en écriture effaçable après validation.

Les erreurs d’exercices antérieurs, notamment significatives, ne sont pas corrigées en rouvrant silencieusement les livres. Elles exigent un traitement de report à nouveau et, selon le cas, une information en notes annexes. Ce workflow spécialisé doit être revu avant d’être automatisé ; le parcours simple de correction ne l’invente pas.

## Justificatifs et traçabilité

Les pièces sont conservées hors du répertoire web public, avec contrôle de type, taille, nom de stockage opaque et empreinte. Le stockage chiffré ne remplace pas le contrôle d’accès : chaque téléchargement doit retrouver le locataire et l’entreprise autorisés. Un lien de stockage brut ne doit jamais suffire pour récupérer une facture.

Les actions comptables alimentent une piste d’audit : acteur authentifié, entreprise, objet, action, date, requête et valeurs avant/après. Les valeurs de l’audit sont elles-mêmes financières ; volumes et sauvegardes doivent être chiffrés, et les journaux techniques ne doivent pas recopier les pièces ni les corps des formulaires.

## Séparation des rôles

| Rôle | Usage prévu |
| --- | --- |
| Administrateur de l’entreprise | Paramétrage de son entreprise, option, exercice et habilitations autorisées |
| Comptable | Préparation et comptabilisation dans les exercices auxquels il a accès |
| Réviseur | Consultation, contrôle et revue dans son périmètre ; les pouvoirs d’écriture doivent être explicitement accordés |
| Lecture seule | Consultation et téléchargements autorisés ; aucune écriture comptable |
| Administrateur SaaS | Configuration de plateforme ; ce rôle ne doit pas devenir un accès implicite et permanent aux livres de tous les clients |

Les contrôles serveur et PostgreSQL doivent être testés avec les rôles réellement provisionnés. Les listes visibles dans l’interface ne constituent pas une protection d’accès.

## Relation avec la DSF

Le module facilite la constitution d’une balance source. Il ne suffit pas, à lui seul, à produire une DSF complète : immobilisations, amortissements, stocks, créances/dettes, flux d’ouverture/clôture, engagements et informations narratives restent à compléter selon le référentiel applicable.

Le SMT s’appuie sur les encaissements et décaissements réels et les ajustements requis par son référentiel. Le Normal exige le jeu d’états complet et ses annexes. Les règles fiscales camerounaises, les exemptions et les seuils ne sont pas dérivés automatiquement du bouton « micro-entreprise ».

Les règles et canevas DGI non qualifiés restent bloqués pour l’export officiel. Les déclarations ne sont pas téléversées à la DGI par une simple comptabilisation d’écriture. Les notifications, OCR, rapprochement bancaire automatique, paie, déclarations automatisées et intervention d’un cabinet partenaire sont des extensions distinctes, pas des capacités implicites de cette version.

## Références

- AUDCIF/SYSCOHADA révisé, articles 13, 17, 19 à 22 : [présentation OHADA](https://www.ohada.org/acte-uniforme-relatif-au-droit-comptable-et-a-linformation-financiere-audcif/) et [texte publié par le ministère de la Justice du Sénégal](https://justice.sec.gouv.sn/wp-content/uploads/textes-reglements/OHADA/Acte-uniforme-relatif-droit-comptable-information-financiere-JAN-2017-JO.pdf).
- Sources camerounaises, canevas DGI et points de qualification : document fiscal conservé dans le dossier de sources du projet.

Les références légales servent à cadrer les contrôles ; une recette comptable et fiscale des cas réels reste nécessaire avant une exploitation déclarative.
