'use strict';
(() => {
    document.querySelectorAll('[data-print]').forEach(button => button.addEventListener('click', () => window.print()));
    const labels = {
        CASH_SALE: ['Compte qui reçoit le paiement', 'Compte de vente'],
        CASH_EXPENSE: ['Compte qui paie la dépense', 'Compte de charge'],
        CUSTOMER_RECEIPT: ['Compte qui reçoit le paiement', 'Compte client à solder'],
        SUPPLIER_PAYMENT: ['Compte qui règle le fournisseur', 'Compte fournisseur à solder'],
        BANK_TRANSFER: ['Caisse / banque de départ', 'Caisse / banque d’arrivée'],
        OWNER_CONTRIBUTION: ['Compte qui reçoit l’apport', 'Compte de capital / apport à confirmer']
    };
    document.querySelectorAll('[data-guided-entry]').forEach(form => {
        const select = form.querySelector('[name="type"]');
        const refresh = () => {
            const chosen = labels[select.value] || ['Compte de trésorerie', 'Contrepartie'];
            form.querySelector('[data-cash-label]').textContent = chosen[0];
            form.querySelector('[data-other-label]').textContent = chosen[1];
        };
        select.addEventListener('change', refresh); refresh();
    });
    document.querySelectorAll('[data-manual-entry]').forEach(form => {
        const body = form.querySelector('[data-entry-lines]');
        const renumber = () => {
            [...body.rows].forEach((row, index) => {
                row.querySelectorAll('[name]').forEach(input => {
                    input.name = input.name.replace(/lines\[\d+\]/, `lines[${index}]`);
                    const key = input.name.match(/\[([^\]]+)\]$/)?.[1] || '';
                    const label = {account_id: 'Compte', label: 'Libellé', debit: 'Débit', credit: 'Crédit'}[key] || 'Champ';
                    input.setAttribute('aria-label', `${label} ligne ${index + 1}`);
                });
                row.querySelector('[data-remove-line]').disabled = body.rows.length <= 2;
            });
        };
        form.querySelector('[data-add-line]').addEventListener('click', () => {
            if (body.rows.length >= 100) return;
            const row = body.rows[0].cloneNode(true);
            row.querySelectorAll('input').forEach(input => {input.value = /\[(debit|credit)\]$/.test(input.name) ? '0' : '';});
            row.querySelectorAll('select').forEach(input => {input.value = '';});
            body.append(row); renumber(); row.querySelector('select')?.focus();
        });
        body.addEventListener('click', event => {
            const remove = event.target.closest('[data-remove-line]');
            if (remove && body.rows.length > 2) {remove.closest('tr').remove(); renumber();}
        });
        renumber();
    });
    document.querySelectorAll('[data-file-label]').forEach(input => {
        const wrapper = input.closest('[data-upload-label]');
        const output = wrapper?.querySelector('[data-selected-file]');
        const show = () => {
            const file = input.files?.[0];
            if (output) output.textContent = file ? file.name : 'Aucun fichier sélectionné';
        };
        input.addEventListener('change', show);
        wrapper?.addEventListener('dragover', event => {event.preventDefault(); wrapper.classList.add('drag-over');});
        wrapper?.addEventListener('dragleave', () => wrapper.classList.remove('drag-over'));
        wrapper?.addEventListener('drop', event => {
            event.preventDefault(); wrapper.classList.remove('drag-over');
            if (event.dataTransfer?.files?.length === 1) {
                const transfer = new DataTransfer(); transfer.items.add(event.dataTransfer.files[0]);
                input.files = transfer.files; show();
            }
        });
    });
    document.querySelectorAll('[data-release-file]').forEach(input => {
        input.addEventListener('change', async () => {
            const output = document.querySelector('[data-release-result]');
            const file = input.files?.[0];
            if (!file) {output.textContent = 'Choisissez un fichier pour calculer son empreinte.'; return;}
            if (!file.name.toLowerCase().endsWith('.zip') || file.size > 20 * 1024 * 1024) {
                output.textContent = 'Précontrôle refusé : archive ZIP de 20 Mio maximum attendue.'; return;
            }
            if (!window.crypto?.subtle) {output.textContent = 'Le calcul d’empreinte nécessite un navigateur compatible et une connexion HTTPS.'; return;}
            output.textContent = 'Calcul de l’empreinte…';
            try {
                const digest = await crypto.subtle.digest('SHA-256', await file.arrayBuffer());
                const hash = [...new Uint8Array(digest)].map(value => value.toString(16).padStart(2, '0')).join('');
                output.textContent = `SHA-256 : ${hash}. Cette empreinte ne prouve ni la signature du paquet, ni sa sécurité.`;
            } catch {output.textContent = 'Le fichier n’a pas pu être lu. Aucun paquet n’a été transmis.';}
        });
    });
})();
