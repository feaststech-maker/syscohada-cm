<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\{DB,Schema};
return new class extends Migration {
    public function up(): void {
        Schema::create('admin_settings',function(Blueprint $t) {
            $t->uuid('id')->primary();$t->uuid('tenant_id');$t->string('type',20);$t->string('key',100);$t->text('value');$t->string('status',10)->default('DRAFT');$t->timestamps();
            $t->foreign('tenant_id')->references('id')->on('tenants')->restrictOnDelete();
        });
        if(DB::getDriverName()==='pgsql') DB::unprepared(<<<'SQL'
ALTER TABLE admin_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_settings FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON admin_settings USING (tenant_id=public.dsf_current_tenant()) WITH CHECK (tenant_id=public.dsf_current_tenant());
ALTER TABLE admin_settings ADD CONSTRAINT admin_drafts_only CHECK (status='DRAFT' AND type IN ('rule','pricing','setting'));
CREATE TRIGGER audit_change AFTER INSERT OR UPDATE OR DELETE ON admin_settings FOR EACH ROW EXECUTE FUNCTION public.dsf_capture_change();
SQL);
    }
    public function down(): void { Schema::dropIfExists('admin_settings'); }
};
