<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tenants', function (Blueprint $t) {
            $t->uuid('id')->primary(); $t->string('name', 200); $t->timestamps();
        });
        // This is an authentication directory, intentionally outside business RLS.
        // Email lookup is necessary before the authenticated tenant is known.
        Schema::create('users', function (Blueprint $t) {
            $t->uuid('id')->primary(); $t->uuid('tenant_id')->nullable();
            $t->string('name', 200); $t->string('email')->unique(); $t->string('password');
            $t->string('role', 30)->default('READ_ONLY'); $t->boolean('enabled')->default(true);
            $t->timestamp('email_verified_at')->nullable(); $t->rememberToken(); $t->timestamps();
            $t->foreign('tenant_id')->references('id')->on('tenants')->restrictOnDelete();
        });
        Schema::create('password_reset_tokens', function (Blueprint $t) {
            $t->string('email')->primary(); $t->string('token'); $t->timestamp('created_at')->nullable();
        });
        Schema::create('companies', function (Blueprint $t) {
            $this->identity($t); $t->string('name', 240); $t->string('niu', 30)->nullable();
            $t->string('accounting_system', 10)->default('SMT'); $t->string('fiscal_regime', 40)->nullable();
            $t->boolean('virtual_accounting_enabled')->default(false); $t->timestamps();
            $t->unique(['tenant_id', 'niu']);
            $t->unique(['tenant_id', 'id']);
            $t->foreign('tenant_id')->references('id')->on('tenants')->restrictOnDelete();
        });
        Schema::create('fiscal_years', function (Blueprint $t) {
            $this->companyIdentity($t); $t->date('starts_on'); $t->date('ends_on');
            $t->string('status', 10)->default('OPEN'); $t->timestamps();
            $t->unique(['tenant_id','company_id','starts_on','ends_on'], 'fy_period_unique');
        });
        Schema::create('accounts', function (Blueprint $t) {
            $this->companyIdentity($t); $t->string('code', 20); $t->string('name', 200);
            $t->boolean('is_cash')->default(false); $t->boolean('active')->default(true); $t->timestamps();
            $t->unique(['tenant_id','company_id','code'], 'account_code_unique');
        });
        Schema::create('journals', function (Blueprint $t) {
            $this->companyIdentity($t); $t->string('code', 20); $t->string('name', 200);
            $t->string('kind', 15); $t->unsignedBigInteger('next_number')->default(1); $t->timestamps();
            $t->unique(['tenant_id','company_id','code'], 'journal_code_unique');
        });
        Schema::create('entries', function (Blueprint $t) {
            $this->companyIdentity($t); $t->uuid('fiscal_year_id'); $t->uuid('journal_id');
            $t->date('entry_date'); $t->string('description', 500); $t->string('reference', 200)->nullable();
            $t->string('status', 10)->default('DRAFT'); $t->string('number', 80)->nullable();
            $t->uuid('created_by'); $t->uuid('posted_by')->nullable(); $t->timestamp('posted_at')->nullable();
            $t->string('idempotency_key', 64)->nullable(); $t->uuid('reversal_of')->nullable()->unique(); $t->timestamps();
            $t->foreign(['tenant_id','company_id','fiscal_year_id'])->references(['tenant_id','company_id','id'])->on('fiscal_years')->restrictOnDelete();
            $t->foreign(['tenant_id','company_id','journal_id'])->references(['tenant_id','company_id','id'])->on('journals')->restrictOnDelete();
            $t->foreign('created_by')->references('id')->on('users')->restrictOnDelete();
            $t->foreign('posted_by')->references('id')->on('users')->restrictOnDelete();
            $t->foreign(['tenant_id','company_id','reversal_of'])->references(['tenant_id','company_id','id'])->on('entries')->restrictOnDelete();
            $t->unique(['tenant_id','company_id','fiscal_year_id','journal_id','number'], 'entry_number_unique');
            $t->unique(['tenant_id','company_id','idempotency_key'], 'entry_idempotency_unique');
            $t->index(['tenant_id','company_id','fiscal_year_id','entry_date'], 'entries_year_date_idx');
        });
        Schema::create('entry_lines', function (Blueprint $t) {
            $this->companyIdentity($t); $t->uuid('entry_id'); $t->uuid('account_id');
            $t->unsignedInteger('sort_order'); $t->string('label', 500)->nullable();
            // Signed values support the exact negative corrections required by AUDCIF art.20.
            $this->amount($t, 'debit', true); $this->amount($t, 'credit', true); $t->timestamps();
            $t->foreign(['tenant_id','company_id','entry_id'])->references(['tenant_id','company_id','id'])->on('entries')->restrictOnDelete();
            $t->foreign(['tenant_id','company_id','account_id'])->references(['tenant_id','company_id','id'])->on('accounts')->restrictOnDelete();
            $t->unique(['tenant_id','company_id','entry_id','sort_order'], 'entry_line_order_unique');
        });
        Schema::create('tax_adjustments', function (Blueprint $t) {
            $this->companyIdentity($t); $t->uuid('fiscal_year_id'); $t->string('direction', 15);
            $this->amount($t, 'amount'); $t->text('justification'); $t->timestamps();
            $t->foreign(['tenant_id','company_id','fiscal_year_id'])->references(['tenant_id','company_id','id'])->on('fiscal_years')->restrictOnDelete();
        });
        Schema::create('rule_sets', function (Blueprint $t) {
            $this->identity($t); $t->string('version', 80); $t->string('status', 10)->default('DRAFT');
            $t->date('effective_from'); $t->date('effective_to')->nullable(); $t->json('rules_json');
            $t->text('source_uri')->nullable(); $t->uuid('reviewed_by')->nullable(); $t->uuid('approved_by')->nullable(); $t->timestamps();
            $t->foreign('tenant_id')->references('id')->on('tenants')->restrictOnDelete();
            $t->foreign('reviewed_by')->references('id')->on('users')->restrictOnDelete();
            $t->foreign('approved_by')->references('id')->on('users')->restrictOnDelete();
            $t->unique(['tenant_id','version']);
        });
        Schema::create('dgi_templates', function (Blueprint $t) {
            $this->identity($t); $t->unsignedSmallInteger('year'); $t->string('system', 10);
            $t->string('status', 25)->default('UNVERIFIED'); $t->char('sha256', 64);
            $t->text('path'); $t->json('mapping_json'); $t->timestamps();
            $t->foreign('tenant_id')->references('id')->on('tenants')->restrictOnDelete();
        });
        Schema::create('financial_statements', function (Blueprint $t) {
            $this->companyIdentity($t); $t->uuid('fiscal_year_id'); $t->string('kind', 40);
            $t->json('payload_json'); $t->char('source_hash', 64); $t->timestamps();
            $t->foreign(['tenant_id','company_id','fiscal_year_id'])->references(['tenant_id','company_id','id'])->on('fiscal_years')->restrictOnDelete();
        });
        Schema::create('attachments', function (Blueprint $t) {
            $this->companyIdentity($t); $t->uuid('entry_id')->nullable(); $t->text('path');
            $t->string('original_name', 255); $t->string('mime', 120); $t->unsignedBigInteger('size');
            $t->char('sha256', 64); $t->timestamps();
            $t->foreign(['tenant_id','company_id','entry_id'])->references(['tenant_id','company_id','id'])->on('entries')->restrictOnDelete();
        });
        Schema::create('audit_events', function (Blueprint $t) {
            $t->uuid('id')->primary(); $t->uuid('tenant_id'); $t->uuid('actor_id')->nullable();
            $t->string('table_name', 80); $t->string('action', 15); $t->string('record_id', 80)->nullable();
            $t->json('old_values')->nullable(); $t->json('new_values')->nullable();
            $t->string('request_id', 100)->nullable(); $t->timestamp('created_at')->useCurrent();
            $t->index(['tenant_id','created_at'], 'audit_tenant_time_idx');
        });

        if (DB::getDriverName() === 'pgsql') {
            DB::unprepared($this->postgresqlGuards());
        }
    }

    private function identity(Blueprint $t): void
    {
        $t->uuid('id')->primary(); $t->uuid('tenant_id');
    }

    private function companyIdentity(Blueprint $t): void
    {
        $this->identity($t); $t->uuid('company_id');
        $t->unique(['tenant_id','company_id','id'], $t->getTable().'_scope_unique');
        $t->foreign(['tenant_id','company_id'])->references(['tenant_id','id'])->on('companies')->restrictOnDelete();
    }

    private function amount(Blueprint $t, string $name, bool $defaultZero = false): void
    {
        // SQLite NUMERIC can coerce decimal text to REAL; keep exact strings instead.
        $column = DB::getDriverName() === 'sqlite' ? $t->string($name, 40) : $t->decimal($name, 28, 6);
        if ($defaultZero) { $column->default('0'); }
    }

    private function postgresqlGuards(): string
    {
        return <<<'SQL'
CREATE FUNCTION public.dsf_current_tenant() RETURNS uuid LANGUAGE sql STABLE
SET search_path=pg_catalog AS $$ SELECT NULLIF(current_setting('app.tenant_id',true),'')::uuid $$;
CREATE FUNCTION public.dsf_current_actor() RETURNS uuid LANGUAGE sql STABLE
SET search_path=pg_catalog AS $$ SELECT NULLIF(current_setting('app.actor_id',true),'')::uuid $$;

ALTER TABLE users ADD CONSTRAINT users_role_valid CHECK (role IN ('TENANT_ADMIN','ACCOUNTANT','REVIEWER','READ_ONLY','PLATFORM_ADMIN'));
ALTER TABLE users ADD CONSTRAINT users_tenant_required CHECK (tenant_id IS NOT NULL OR role='PLATFORM_ADMIN');
ALTER TABLE companies ADD CONSTRAINT companies_system_valid CHECK (accounting_system IN ('NORMAL','SMT'));
ALTER TABLE fiscal_years ADD CONSTRAINT fiscal_year_valid CHECK (ends_on>=starts_on AND status IN ('OPEN','CLOSED'));
ALTER TABLE journals ADD CONSTRAINT journal_kind_valid CHECK (kind IN ('SALES','PURCHASES','CASH','BANK','GENERAL') AND next_number>0);
ALTER TABLE entries ADD CONSTRAINT entry_status_valid CHECK (status IN ('DRAFT','POSTED'));
ALTER TABLE entry_lines ADD CONSTRAINT entry_line_one_side CHECK ((debit=0)<>(credit=0));
ALTER TABLE tax_adjustments ADD CONSTRAINT tax_adjustment_valid CHECK (amount>=0 AND direction IN ('ADD_BACK','DEDUCTION','TAX_CREDIT'));
ALTER TABLE rule_sets ADD CONSTRAINT rules_activation_valid CHECK (status IN ('DRAFT','ACTIVE') AND (effective_to IS NULL OR effective_to>=effective_from) AND (status<>'ACTIVE' OR (reviewed_by IS NOT NULL AND approved_by IS NOT NULL AND reviewed_by<>approved_by AND source_uri IS NOT NULL)));

DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['companies','fiscal_years','accounts','journals','entries','entry_lines','tax_adjustments','rule_sets','dgi_templates','financial_statements','attachments','audit_events'] LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY',t);
    EXECUTE format('ALTER TABLE public.%I FORCE ROW LEVEL SECURITY',t);
    EXECUTE format('CREATE POLICY tenant_isolation ON public.%I USING (tenant_id=public.dsf_current_tenant()) WITH CHECK (tenant_id=public.dsf_current_tenant())',t);
  END LOOP;
END $$;
ALTER TABLE tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE tenants FORCE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON tenants USING (id=public.dsf_current_tenant()) WITH CHECK (id=public.dsf_current_tenant());

CREATE FUNCTION public.dsf_guard_entry() RETURNS trigger LANGUAGE plpgsql
SET search_path=pg_catalog,public AS $$
DECLARE fy record; parent record; n bigint; d numeric; c numeric; bad bigint;
BEGIN
  IF TG_OP<>'INSERT' AND OLD.status='POSTED' THEN
    RAISE EXCEPTION 'Posted journal entries are immutable; use a negative correction' USING ERRCODE='23514';
  END IF;
  IF TG_OP='DELETE' THEN
    IF EXISTS(SELECT 1 FROM fiscal_years WHERE id=OLD.fiscal_year_id AND tenant_id=OLD.tenant_id AND status='CLOSED') THEN
      RAISE EXCEPTION 'Closed accounting period' USING ERRCODE='23514';
    END IF;
    RETURN OLD;
  END IF;
  SELECT * INTO fy FROM fiscal_years WHERE id=NEW.fiscal_year_id AND tenant_id=NEW.tenant_id AND company_id=NEW.company_id FOR SHARE;
  IF NOT FOUND OR fy.status<>'OPEN' OR NEW.entry_date<fy.starts_on OR NEW.entry_date>fy.ends_on THEN
    RAISE EXCEPTION 'Accounting period unavailable, closed or date outside period' USING ERRCODE='23514';
  END IF;
  IF NOT EXISTS(SELECT 1 FROM users WHERE id=NEW.created_by AND tenant_id=NEW.tenant_id AND enabled) THEN
    RAISE EXCEPTION 'Invalid tenant entry author' USING ERRCODE='42501';
  END IF;
  IF NEW.status='POSTED' THEN
    IF NEW.posted_by IS DISTINCT FROM public.dsf_current_actor() OR NOT EXISTS(SELECT 1 FROM users WHERE id=NEW.posted_by AND tenant_id=NEW.tenant_id AND enabled AND role IN ('TENANT_ADMIN','ACCOUNTANT')) THEN
      RAISE EXCEPTION 'Authorized posting actor required' USING ERRCODE='42501';
    END IF;
    IF NEW.number IS NULL OR NEW.posted_at IS NULL OR NEW.posted_by IS NULL THEN
      RAISE EXCEPTION 'Publication number, author and timestamp required' USING ERRCODE='23514';
    END IF;
    IF NULLIF(btrim(NEW.reference),'') IS NULL AND NOT EXISTS(SELECT 1 FROM attachments WHERE tenant_id=NEW.tenant_id AND company_id=NEW.company_id AND (entry_id=NEW.id OR entry_id=NEW.reversal_of)) THEN
      RAISE EXCEPTION 'A documentary reference or attached supporting document is required' USING ERRCODE='23514';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM companies WHERE id=NEW.company_id AND tenant_id=NEW.tenant_id AND virtual_accounting_enabled) THEN
      RAISE EXCEPTION 'Virtual accounting module is disabled' USING ERRCODE='23514';
    END IF;
    SELECT count(*),COALESCE(sum(debit),0),COALESCE(sum(credit),0) INTO n,d,c FROM entry_lines
      WHERE entry_id=NEW.id AND tenant_id=NEW.tenant_id AND company_id=NEW.company_id;
    IF n<2 OR d<>c OR (d=0 AND NEW.reversal_of IS NULL) THEN
      RAISE EXCEPTION 'At least two nonzero balanced lines required' USING ERRCODE='23514';
    END IF;
    IF EXISTS (SELECT 1 FROM entry_lines l JOIN accounts a ON a.id=l.account_id AND a.tenant_id=l.tenant_id AND a.company_id=l.company_id
        WHERE l.entry_id=NEW.id AND l.tenant_id=NEW.tenant_id AND NOT a.active) THEN
      RAISE EXCEPTION 'Inactive account in journal entry' USING ERRCODE='23514';
    END IF;
    IF NEW.reversal_of IS NULL THEN
      IF EXISTS(SELECT 1 FROM entry_lines WHERE entry_id=NEW.id AND tenant_id=NEW.tenant_id AND (debit<0 OR credit<0)) THEN
        RAISE EXCEPTION 'Ordinary entries cannot contain negative values' USING ERRCODE='23514';
      END IF;
    ELSE
      SELECT * INTO parent FROM entries WHERE id=NEW.reversal_of AND tenant_id=NEW.tenant_id AND company_id=NEW.company_id FOR SHARE;
      IF NOT FOUND OR parent.status<>'POSTED' OR parent.reversal_of IS NOT NULL OR parent.fiscal_year_id<>NEW.fiscal_year_id OR parent.journal_id<>NEW.journal_id THEN
        RAISE EXCEPTION 'Correction must reference a posted original entry in the same year and journal' USING ERRCODE='23514';
      END IF;
      SELECT count(*) INTO bad FROM (
        (SELECT account_id,sort_order,debit,credit FROM entry_lines WHERE tenant_id=NEW.tenant_id AND entry_id=NEW.id
          EXCEPT ALL SELECT account_id,sort_order,-debit,-credit FROM entry_lines WHERE tenant_id=NEW.tenant_id AND entry_id=NEW.reversal_of)
        UNION ALL
        (SELECT account_id,sort_order,-debit,-credit FROM entry_lines WHERE tenant_id=NEW.tenant_id AND entry_id=NEW.reversal_of
          EXCEPT ALL SELECT account_id,sort_order,debit,credit FROM entry_lines WHERE tenant_id=NEW.tenant_id AND entry_id=NEW.id)
      ) mismatch;
      IF bad<>0 THEN RAISE EXCEPTION 'Correction lines must exactly negate the original entry' USING ERRCODE='23514'; END IF;
    END IF;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER guard_entry BEFORE INSERT OR UPDATE OR DELETE ON entries FOR EACH ROW EXECUTE FUNCTION public.dsf_guard_entry();

CREATE FUNCTION public.dsf_guard_entry_line() RETURNS trigger LANGUAGE plpgsql
SET search_path=pg_catalog,public AS $$
DECLARE e record; row_tenant uuid; row_company uuid; row_entry uuid;
BEGIN
  IF TG_OP<>'INSERT' THEN
    SELECT * INTO e FROM entries WHERE id=OLD.entry_id AND tenant_id=OLD.tenant_id AND company_id=OLD.company_id FOR SHARE;
    IF NOT FOUND OR e.status='POSTED' THEN RAISE EXCEPTION 'Posted or inaccessible journal entry lines are immutable' USING ERRCODE='23514'; END IF;
  END IF;
  IF TG_OP='DELETE' THEN
    IF NOT EXISTS(SELECT 1 FROM fiscal_years WHERE id=e.fiscal_year_id AND tenant_id=e.tenant_id AND status='OPEN') THEN
      RAISE EXCEPTION 'Closed accounting period' USING ERRCODE='23514';
    END IF;
    RETURN OLD;
  END IF;
  SELECT * INTO e FROM entries WHERE id=NEW.entry_id AND tenant_id=NEW.tenant_id AND company_id=NEW.company_id FOR SHARE;
  IF NOT FOUND OR e.status='POSTED' THEN RAISE EXCEPTION 'Cannot add/change lines of a posted or inaccessible entry' USING ERRCODE='23514'; END IF;
  IF NOT EXISTS(SELECT 1 FROM fiscal_years WHERE id=e.fiscal_year_id AND tenant_id=e.tenant_id AND status='OPEN') THEN
    RAISE EXCEPTION 'Closed accounting period' USING ERRCODE='23514';
  END IF;
  IF NEW.debit=0 AND NEW.credit=0 OR NEW.debit<>0 AND NEW.credit<>0 THEN
    RAISE EXCEPTION 'A journal line has exactly one nonzero side' USING ERRCODE='23514';
  END IF;
  IF e.reversal_of IS NULL AND (NEW.debit<0 OR NEW.credit<0) THEN
    RAISE EXCEPTION 'Negative values are restricted to exact corrections' USING ERRCODE='23514';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER guard_entry_line BEFORE INSERT OR UPDATE OR DELETE ON entry_lines FOR EACH ROW EXECUTE FUNCTION public.dsf_guard_entry_line();

CREATE FUNCTION public.dsf_guard_fiscal_year() RETURNS trigger LANGUAGE plpgsql
SET search_path=pg_catalog,public AS $$
BEGIN
  IF OLD.status='CLOSED' THEN RAISE EXCEPTION 'Closed accounting periods are immutable' USING ERRCODE='23514'; END IF;
  IF TG_OP='UPDATE' AND (NEW.tenant_id IS DISTINCT FROM OLD.tenant_id OR NEW.company_id IS DISTINCT FROM OLD.company_id OR NEW.starts_on IS DISTINCT FROM OLD.starts_on OR NEW.ends_on IS DISTINCT FROM OLD.ends_on)
     AND EXISTS(SELECT 1 FROM entries WHERE fiscal_year_id=OLD.id AND tenant_id=OLD.tenant_id AND status='POSTED') THEN
    RAISE EXCEPTION 'Period boundaries and ownership cannot change after publication' USING ERRCODE='23514';
  END IF;
  RETURN COALESCE(NEW,OLD);
END $$;
CREATE TRIGGER guard_fiscal_year BEFORE UPDATE OR DELETE ON fiscal_years FOR EACH ROW EXECUTE FUNCTION public.dsf_guard_fiscal_year();

CREATE FUNCTION public.dsf_capture_change() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER
SET search_path=pg_catalog,public AS $$
DECLARE old_doc jsonb; new_doc jsonb; doc jsonb; tenant uuid; actor uuid;
BEGIN
  actor:=public.dsf_current_actor();
  IF actor IS NULL THEN RAISE EXCEPTION 'Authenticated audit actor required' USING ERRCODE='42501'; END IF;
  IF TG_OP<>'INSERT' THEN old_doc:=to_jsonb(OLD); END IF;
  IF TG_OP<>'DELETE' THEN new_doc:=to_jsonb(NEW); END IF;
  doc:=COALESCE(new_doc,old_doc);
  tenant:=CASE WHEN TG_TABLE_NAME='tenants' THEN (doc->>'id')::uuid ELSE (doc->>'tenant_id')::uuid END;
  IF tenant IS DISTINCT FROM public.dsf_current_tenant() OR
     (TG_OP='UPDATE' AND old_doc->>'tenant_id' IS DISTINCT FROM new_doc->>'tenant_id') THEN
    RAISE EXCEPTION 'Tenant context mismatch' USING ERRCODE='42501';
  END IF;
  INSERT INTO public.audit_events(id,tenant_id,actor_id,table_name,action,record_id,old_values,new_values,request_id,created_at)
  VALUES(gen_random_uuid(),tenant,actor,TG_TABLE_NAME,TG_OP,doc->>'id',old_doc,new_doc,NULLIF(current_setting('app.request_id',true),''),clock_timestamp());
  RETURN COALESCE(NEW,OLD);
END $$;
REVOKE ALL ON FUNCTION public.dsf_capture_change() FROM PUBLIC;
DO $$ DECLARE t text; BEGIN
  FOREACH t IN ARRAY ARRAY['tenants','companies','fiscal_years','accounts','journals','entries','entry_lines','tax_adjustments','rule_sets','dgi_templates','financial_statements','attachments'] LOOP
    EXECUTE format('CREATE TRIGGER audit_change AFTER INSERT OR UPDATE OR DELETE ON public.%I FOR EACH ROW EXECUTE FUNCTION public.dsf_capture_change()',t);
  END LOOP;
END $$;
CREATE FUNCTION public.dsf_reject_audit_mutation() RETURNS trigger LANGUAGE plpgsql
SET search_path=pg_catalog AS $$ BEGIN RAISE EXCEPTION 'Audit events are append-only' USING ERRCODE='42501'; END $$;
CREATE TRIGGER audit_append_only BEFORE UPDATE OR DELETE OR TRUNCATE ON audit_events FOR EACH STATEMENT EXECUTE FUNCTION public.dsf_reject_audit_mutation();
REVOKE ALL ON FUNCTION public.dsf_reject_audit_mutation() FROM PUBLIC;
SQL;
    }

    public function down(): void
    {
        if (DB::getDriverName() === 'pgsql') {
            DB::unprepared('DROP FUNCTION IF EXISTS public.dsf_guard_fiscal_year() CASCADE; DROP FUNCTION IF EXISTS public.dsf_guard_entry() CASCADE; DROP FUNCTION IF EXISTS public.dsf_guard_entry_line() CASCADE; DROP FUNCTION IF EXISTS public.dsf_capture_change() CASCADE; DROP FUNCTION IF EXISTS public.dsf_reject_audit_mutation() CASCADE;');
        }
        foreach (['audit_events','attachments','financial_statements','dgi_templates','rule_sets','tax_adjustments','entry_lines','entries','journals','accounts','fiscal_years','companies','password_reset_tokens','users','tenants'] as $table) {
            Schema::dropIfExists($table);
        }
        if (DB::getDriverName() === 'pgsql') {
            DB::unprepared('DROP FUNCTION IF EXISTS public.dsf_current_tenant(); DROP FUNCTION IF EXISTS public.dsf_current_actor();');
        }
    }
};
