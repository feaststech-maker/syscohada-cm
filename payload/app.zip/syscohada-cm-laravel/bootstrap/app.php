<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias(['tenant' => \App\Http\Middleware\TenantMiddleware::class]);
        $middleware->append(\App\Http\Middleware\SecurityHeaders::class);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->report(function (\Illuminate\Database\QueryException $e) {
            \Illuminate\Support\Facades\Log::error('Database operation failed', ['sqlstate'=>$e->errorInfo[0] ?? 'unknown','request_id'=>app(\App\Support\TenantContext::class)->requestId]);
            return false; // Never log financial SQL bindings or the exception payload.
        });
        $exceptions->dontReport([\App\Domain\Accounting\AccountingException::class]);
        $exceptions->dontFlash(['password','password_confirmation','current_password','file','lines','amount','description','reference','options','value']);
        $exceptions->render(function (\App\Domain\Accounting\AccountingException $e, \Illuminate\Http\Request $request) {
            if ($request->expectsJson()) return response()->json(['code'=>$e->errorCode,'message'=>$e->getMessage()],$e->status);
            if (in_array($e->status,[403,404],true)) abort($e->status);
            return back()->withErrors(['operation'=>$e->getMessage()]);
        });
        $exceptions->render(function (\InvalidArgumentException $e, \Illuminate\Http\Request $request) {
            if ($request->expectsJson()) return response()->json(['message'=>$e->getMessage()],422);
            return back()->withErrors(['operation'=>$e->getMessage()]);
        });
    })->create();
