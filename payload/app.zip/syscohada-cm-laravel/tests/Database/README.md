# Vérifications de migration et de garde PostgreSQL

Ces scripts sont indépendants de PHPUnit. Ils vérifient directement la migration V1 et les contraintes de base ; ils ne remplacent pas les tests HTTP et métier Laravel.

## SQLite en mémoire

Après `composer install`, depuis la racine :

```bash
php tests/Database/migration-and-guards.php sqlite
```

La commande crée 15 tables dans une base en mémoire, vérifie la conservation exacte de `9999999999999999999999.123456` comme texte, puis exécute la migration descendante. Elle ne touche pas à `database/database.sqlite` ni à la configuration `.env` de l’application.

## PostgreSQL sur une base jetable uniquement

Créer une **base vide, dédiée aux tests**, sur une instance PostgreSQL de test. L’identité de test doit pouvoir créer les tables/fonctions et le rôle sans connexion `dsf_test_runtime`, puis exécuter `SET ROLE` vers ce rôle. Utiliser par exemple l’administrateur d’un cluster de test isolé ; ne pas réutiliser ce compte comme connexion de l’application web.

Le script refuse PostgreSQL sans `DSF_ALLOW_PG_TESTS=1`, un nom de base contenant `test` et un schéma vide. Les identifiants proviennent de variables externes, indépendantes du `.env` Laravel :

```bash
export DSF_ALLOW_PG_TESTS=1
export DSF_TEST_DATABASE=syscohada_migration_test
export DSF_TEST_HOST=127.0.0.1
export DSF_TEST_PORT=5432
export DSF_TEST_USER=postgres
# Fournir DSF_TEST_PASSWORD par votre environnement de test si requis.
# DSF_TEST_SSLMODE vaut verify-full par défaut.

php tests/Database/migration-and-guards.php pgsql
```

Pour un cluster jetable local sans TLS uniquement, le test peut recevoir explicitement `DSF_TEST_SSLMODE=disable`. La configuration de production conserve la vérification TLS. Le script ne démarre pas et n’arrête pas le serveur PostgreSQL : son cycle de vie appartient à l’environnement de test.

Le fichier `postgresql-guards.sql` utilise seulement des identités et opérations fictives. Il vérifie :

- lecture, modification et insertion entre locataires refusées ;
- publication d’une écriture équilibrée avec référence documentaire ;
- modification/suppression des écritures et lignes publiées refusées ;
- correction exactement négative, conservant l’original ;
- audit avant/après présent et non modifiable par le rôle runtime ;
- clôture d’exercice non réversible par une mise à jour ordinaire ;
- absence de contexte tenant fermée.

Le script laisse les tables de test en place pour inspection et termine par `PASS`. Après inspection, supprimer seulement cette base jetable et arrêter l’instance si elle a été démarrée pour l’essai. Pour une nouvelle exécution, fournir une nouvelle base vide. Le rôle global `dsf_test_runtime` ne contient aucun mot de passe ni droit de connexion ; il peut être supprimé par l’administrateur du cluster de test lorsque plus aucune base de test ne le référence.

## Résultat observé pour cette version

Migration SQLite UP/DOWN et décimal exact : réussis sur PHP 8.4.27. Migration et gardes PostgreSQL : réussies sur PostgreSQL 17.11 avec un rôle runtime distinct du propriétaire. Le cluster jetable utilisé pendant le développement a été arrêté après les vérifications.
