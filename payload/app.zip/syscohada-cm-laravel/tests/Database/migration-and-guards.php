<?php
$base = dirname(__DIR__, 2);
require $base.'/vendor/autoload.php';
use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Container\Container;
use Illuminate\Events\Dispatcher;
use Illuminate\Support\Facades\Facade;
$c=new Container();$db=new Capsule($c);
$driver=$argv[1]??'sqlite';
if (!in_array($driver,['sqlite','pgsql'],true)) { throw new RuntimeException('Driver must be sqlite or pgsql'); }
if ($driver==='pgsql') {
    $dbName=getenv('DSF_TEST_DATABASE') ?: '';
    if (getenv('DSF_ALLOW_PG_TESTS')!=='1' || !preg_match('/^[a-z0-9_]*test[a-z0-9_]*$/',$dbName)) {
        throw new RuntimeException('Explicit DSF_ALLOW_PG_TESTS=1 and disposable DSF_TEST_DATABASE containing test required');
    }
}
$db->addConnection($driver==='sqlite'?['driver'=>'sqlite','database'=>':memory:','foreign_key_constraints'=>true]:['driver'=>'pgsql','host'=>getenv('DSF_TEST_HOST') ?: '127.0.0.1','port'=>getenv('DSF_TEST_PORT') ?: '5432','database'=>$dbName,'username'=>getenv('DSF_TEST_USER') ?: 'postgres','password'=>getenv('DSF_TEST_PASSWORD') ?: '', 'sslmode'=>getenv('DSF_TEST_SSLMODE') ?: 'verify-full']);
$db->setEventDispatcher(new Dispatcher($c));$db->setAsGlobal();$db->bootEloquent();
$c->instance('db',$db->getDatabaseManager());$c->bind('db.schema',fn()=>$db->schema());Facade::setFacadeApplication($c);
if ($driver==='pgsql' && count($db->schema()->getTables())!==0) { throw new RuntimeException('Refusing nonempty test schema'); }
$m=require $base.'/database/migrations/2026_11_11_000001_create_syscohada_schema.php';
$m->up();
echo $driver.' migration UP PASS; tables='.count($db->getConnection()->getSchemaBuilder()->getTables()).PHP_EOL;
if($driver==='sqlite'){
 $tenant='11111111-1111-4111-8111-111111111111';$company='22222222-2222-4222-8222-222222222222';$account='33333333-3333-4333-8333-333333333333';$entry='44444444-4444-4444-8444-444444444444';$user='55555555-5555-4555-8555-555555555555';$year='66666666-6666-4666-8666-666666666666';$journal='77777777-7777-4777-8777-777777777777';
 $db->table('tenants')->insert(['id'=>$tenant,'name'=>'test']);$db->table('users')->insert(['id'=>$user,'tenant_id'=>$tenant,'name'=>'test','email'=>'test@example.invalid','password'=>'none']);
 $db->table('companies')->insert(['id'=>$company,'tenant_id'=>$tenant,'name'=>'test']);
 $db->table('fiscal_years')->insert(['id'=>$year,'tenant_id'=>$tenant,'company_id'=>$company,'starts_on'=>'2026-01-01','ends_on'=>'2026-12-31']);
 $db->table('journals')->insert(['id'=>$journal,'tenant_id'=>$tenant,'company_id'=>$company,'code'=>'OD','name'=>'test','kind'=>'GENERAL']);
 $db->table('accounts')->insert(['id'=>$account,'tenant_id'=>$tenant,'company_id'=>$company,'code'=>'571','name'=>'test']);
 $db->table('entries')->insert(['id'=>$entry,'tenant_id'=>$tenant,'company_id'=>$company,'fiscal_year_id'=>$year,'journal_id'=>$journal,'entry_date'=>'2026-11-11','description'=>'test','created_by'=>$user]);
 $db->table('entry_lines')->insert(['id'=>'88888888-8888-4888-8888-888888888888','tenant_id'=>$tenant,'company_id'=>$company,'entry_id'=>$entry,'account_id'=>$account,'sort_order'=>1,'debit'=>'9999999999999999999999.123456','credit'=>'0']);
 if($db->table('entry_lines')->value('debit')!=='9999999999999999999999.123456')throw new Exception('Decimal text precision lost');
 echo 'SQLite exact large decimal roundtrip PASS'.PHP_EOL;
 $m->down();echo 'sqlite DOWN PASS'.PHP_EOL;
}

if ($driver==='pgsql') {
    $db->getConnection()->unprepared(file_get_contents(__DIR__.'/postgresql-guards.sql'));
    echo 'PostgreSQL RLS, publication, exact correction, audit and closed period guards PASS'.PHP_EOL;
}
