<?php
declare(strict_types=1);
namespace Tests\Unit;

use App\Domain\Export\OfficialWorkbookExporter;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PHPUnit\Framework\TestCase;

final class ExportTest extends TestCase
{
    private function fixture(string $formula='=SUM(B2:B3)'):array{
        $book=new Spreadsheet();$sheet=$book->getActiveSheet();$sheet->setTitle('NON OFFICIEL');$sheet->setCellValue('A1','FIXTURE DE TEST — NON OFFICIEL');$sheet->setCellValueExplicit('B2','0',DataType::TYPE_NUMERIC);$sheet->setCellValueExplicit('B3','0',DataType::TYPE_NUMERIC);$sheet->setCellValue('B4',$formula);$sheet->getStyle('B2')->getFont()->setBold(true);$sheet->mergeCells('A6:B6');$p=tempnam(sys_get_temp_dir(),'export-test-');(new Xlsx($book))->save($p);$bytes=file_get_contents($p);unlink($p);$book->disconnectWorksheets();
        $manifest=['templateId'=>'TEST-ONLY','version'=>'0','canonicalUploadFilename'=>'NON-OFFICIEL.xlsx','fiscalYear'=>2026,'system'=>'NORMAL','status'=>'APPROVED_OFFICIAL','sha256'=>hash('sha256',$bytes),'sheets'=>['NON OFFICIEL'],'approval'=>['approvedBy'=>'test','approvedAt'=>'2026-01-01','officialSourceUrl'=>'https://www.impots.cm/test-fixture','acceptanceEvidenceReference'=>'TEST-ONLY-NOT-DGI-APPROVAL'],'bindings'=>['first'=>['sheet'=>'NON OFFICIEL','cell'=>'B2','valueKind'=>'DECIMAL','expectedTemplateType'=>'n','required'=>true,'maxTextLength'=>0],'second'=>['sheet'=>'NON OFFICIEL','cell'=>'B3','valueKind'=>'DECIMAL','expectedTemplateType'=>'n','required'=>true,'maxTextLength'=>0]]];
        $values=['first'=>['kind'=>'DECIMAL','value'=>'1000'],'second'=>['kind'=>'DECIMAL','value'=>'2000']];$readiness=['fiscalYear'=>2026,'system'=>'NORMAL','passedControls'=>OfficialWorkbookExporter::requiredControls('NORMAL'),'generationSnapshotHash'=>OfficialWorkbookExporter::snapshotHash($values)];return [$bytes,$manifest,$values,$readiness];
    }
    public function test_injects_existing_cells_preserves_formula_style_and_recalculates():void{
        $args=$this->fixture();$artifact=(new OfficialWorkbookExporter())->export(...$args);self::assertSame('NON-OFFICIEL.xlsx',$artifact['filename']);$p=tempnam(sys_get_temp_dir(),'read-export-');file_put_contents($p,$artifact['bytes']);$book=IOFactory::load($p);unlink($p);$sheet=$book->getActiveSheet();self::assertEquals(1000,$sheet->getCell('B2')->getValue());self::assertSame('=SUM(B2:B3)',$sheet->getCell('B4')->getValue());self::assertEquals(3000,$sheet->getCell('B4')->getCalculatedValue());self::assertTrue($sheet->getStyle('B2')->getFont()->getBold());self::assertContains('A6:B6',$sheet->getMergeCells());$book->disconnectWorksheets();
    }
    public function test_unverified_model_is_never_exported():void{$a=$this->fixture();$a[1]['status']='UNVERIFIED';$this->expectException(\InvalidArgumentException::class);(new OfficialWorkbookExporter())->export(...$a);}
    public function test_hash_or_snapshot_change_blocks():void{$a=$this->fixture();$a[2]['first']['value']='999';$this->expectException(\InvalidArgumentException::class);(new OfficialWorkbookExporter())->export(...$a);}
    public function test_formula_target_blocks():void{$a=$this->fixture();$a[1]['bindings']['first']['cell']='B4';$this->expectException(\InvalidArgumentException::class);(new OfficialWorkbookExporter())->export(...$a);}
    public function test_duplicate_coordinates_blocks():void{$a=$this->fixture();$a[1]['bindings']['second']['cell']='B2';$this->expectException(\InvalidArgumentException::class);(new OfficialWorkbookExporter())->export(...$a);}
    public function test_precision_blocks():void{$a=$this->fixture();$a[2]['first']['value']='1234567890123456';$a[3]['generationSnapshotHash']=OfficialWorkbookExporter::snapshotHash($a[2]);$this->expectException(\InvalidArgumentException::class);(new OfficialWorkbookExporter())->export(...$a);}
    public function test_missing_controls_blocks():void{$a=$this->fixture();$a[3]['passedControls']=[];$this->expectException(\InvalidArgumentException::class);(new OfficialWorkbookExporter())->export(...$a);}
    public function test_missing_required_value_blocks():void{$a=$this->fixture();unset($a[2]['first']);$a[3]['generationSnapshotHash']=OfficialWorkbookExporter::snapshotHash($a[2]);$this->expectException(\InvalidArgumentException::class);(new OfficialWorkbookExporter())->export(...$a);}
    public function test_unsafe_formula_is_blocked_before_evaluation():void{$a=$this->fixture('=WEBSERVICE("https://example.com")');$this->expectException(\InvalidArgumentException::class);(new OfficialWorkbookExporter())->export(...$a);}
    public function test_smt_requires_its_cash_controls():void{self::assertContains('SMT_CASH_RECONCILED',OfficialWorkbookExporter::requiredControls('SMT'));self::assertNotContains('CASH_FLOW_RECONCILED',OfficialWorkbookExporter::requiredControls('SMT'));}
}
