<?php

namespace Tests\Unit;

use App\Domain\Accounting\AccountingException;
use App\Domain\Accounting\Decimal;
use PHPUnit\Framework\TestCase;

class AccountingDecimalTest extends TestCase
{
    public function test_exact_amounts_and_large_values_never_use_binary_float(): void
    {
        $this->assertSame('0.300000', Decimal::add('0.100000', '0.200000'));
        $this->assertSame('9999999999999999999999.123456', Decimal::amount('9999999999999999999999.123456'));
        $this->assertSame('-10.500000', Decimal::negate('10.500000'));
    }

    public function test_float_input_is_rejected(): void
    {
        $this->expectException(AccountingException::class);
        Decimal::amount(0.1);
    }

    public function test_precision_is_not_silently_rounded(): void
    {
        $this->expectException(AccountingException::class);
        Decimal::amount('1.1234567');
    }
}
