<?php
declare(strict_types=1);
namespace Tests\Unit;
use App\Domain\Tax\TaxReconciliation;
use PHPUnit\Framework\TestCase;
final class TaxTest extends TestCase
{
    private function rules():array{return ['version'=>'TEST-ONLY','approved'=>true,'from'=>'2026-01-01','to'=>'2026-12-31','corporateRate'=>'0.25','minimumRate'=>'0.02','cacRate'=>'0.10','profitRoundingUnit'=>'1000'];}
    public function test_minimum_on_loss_and_credit_not_in_taxable_profit():void{$r=(new TaxReconciliation())->compute('-5000','1000000',[['kind'=>'TAX_CREDIT','amount'=>'5000','justification'=>'Approved test']],$this->rules(),'2026-12-31');self::assertSame('0',$r['taxableProfit']);self::assertSame('17000',$r['netPayable']);}
    public function test_reintegration_and_rounding():void{$r=(new TaxReconciliation())->compute('1000999','0',[['kind'=>'ADD_BACK','amount'=>'2000','justification'=>'Test'],['kind'=>'DEDUCTION','amount'=>'1000','justification'=>'Test']],$this->rules(),'2026-12-31');self::assertSame('1001000',$r['taxableProfit']);self::assertSame('250250',$r['corporatePrincipal']);}
    public function test_unapproved_rules_block():void{$r=$this->rules();$r['approved']=false;$this->expectException(\InvalidArgumentException::class);(new TaxReconciliation())->compute('0','0',[],$r,'2026-12-31');}
}
