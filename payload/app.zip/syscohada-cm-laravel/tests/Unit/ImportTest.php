<?php
declare(strict_types=1);
namespace Tests\Unit;

use App\Domain\Import\AmountParser;
use App\Domain\Import\ColumnMapper;
use App\Domain\Import\TrialBalanceImporter;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PHPUnit\Framework\TestCase;

final class ImportTest extends TestCase
{
    private function options(array $extra=[]):array{return array_replace(['headerRow'=>1,'numberStyle'=>'FR','convention'=>'CLOSING_BALANCE'], $extra);}
    private function csv():string{return "Numéro de compte;Libellé;Débit;Crédit\n101000;Capital;0;1 234,56\n521000;Banque;1 234,56;0\n";}
    private function xlsx(bool $formula=false):string{
        $book=new Spreadsheet();$sheet=$book->getActiveSheet();$sheet->setTitle('Balance');$sheet->fromArray([['Compte','Libellé','Débit','Crédit'],['101000','Capital','0','1000'],['521000','Banque','1000','0']]);
        foreach(['A2','A3'] as $cell)$sheet->setCellValueExplicit($cell,$sheet->getCell($cell)->getValue(),DataType::TYPE_STRING);
        if($formula)$sheet->setCellValue('C3','=1000');$p=tempnam(sys_get_temp_dir(),'import-test-');$w=new Xlsx($book);$w->save($p);$bytes=file_get_contents($p);unlink($p);$book->disconnectWorksheets();return $bytes;
    }
    public function test_exact_french_english_amounts_and_safe_csv():void{
        self::assertSame('123456789012345678.90',(string)AmountParser::parse('123 456 789 012 345 678,90','FR'));
        self::assertSame('1234.56',(string)AmountParser::parse('1,234.56','EN'));
        self::assertSame("'=SUM(A1)",AmountParser::safeCsvText('=SUM(A1)'));
        $this->expectException(\InvalidArgumentException::class);AmountParser::parse('1,234.56','FR');
    }
    public function test_balanced_csv_suggests_columns_and_preserves_strings():void{
        $r=(new TrialBalanceImporter())->preview($this->csv(),'balance.csv',$this->options());self::assertTrue($r['validForImport']);self::assertSame('1234.56',$r['totalDebit']);self::assertSame('101000',$r['rows'][0]['account']);self::assertSame(100,$r['suggestions']['DEBIT']['confidence']);
    }
    public function test_quoted_multiline_csv_and_bom():void{
        $csv="\xEF\xBB\xBFCompte;Libellé;Débit;Crédit\n101000;\"Capital; initial\nlibéré\";0;100\n521000;Banque;100;0\n";
        $r=(new TrialBalanceImporter())->preview($csv,'b.csv',$this->options());self::assertTrue($r['validForImport']);self::assertStringContainsString("\n",$r['rows'][0]['label']);
    }
    public function test_ambiguous_mapping_is_not_guessed():void{
        $m=ColumnMapper::suggest(['Compte','Libellé','Débit','Débit','Crédit']);self::assertNull($m['DEBIT']['column']);self::assertSame([2,3],$m['DEBIT']['candidates']);
        $r=(new TrialBalanceImporter())->preview("Compte;Libellé;Débit;Débit;Crédit\n1010;A;1;1;0",'b.csv',$this->options());self::assertFalse($r['validForImport']);self::assertContains('MAPPING_REQUIRED',array_column($r['issues'],'code'));
    }
    public function test_manual_mapping_can_resolve_unknown_headers():void{
        $r=(new TrialBalanceImporter())->preview("A;B;C;D\n1010;Capital;0;100\n5210;Banque;100;0",'b.csv',$this->options(['columns'=>['ACCOUNT'=>0,'LABEL'=>1,'DEBIT'=>2,'CREDIT'=>3]]));self::assertTrue($r['validForImport']);
    }
    public function test_convention_duplicate_and_unbalanced_errors():void{
        $r=(new TrialBalanceImporter())->preview("Compte;Libellé;Débit;Crédit\n1010;Capital;0;100\n1010;Capital2;99;0",'b.csv',$this->options(['convention'=>null]));self::assertFalse($r['validForImport']);foreach(['CONVENTION_REQUIRED','DUPLICATE_ACCOUNT','UNBALANCED'] as $code)self::assertContains($code,array_column($r['issues'],'code'));
    }
    public function test_movements_warn_and_closing_dual_sides_block():void{
        $csv="Compte;Libellé;Débit;Crédit\n1010;A;100;100";
        $r=(new TrialBalanceImporter())->preview($csv,'b.csv',$this->options());self::assertContains('DOUBLE_CLOSING_BALANCE',array_column($r['issues'],'code'));
        $r=(new TrialBalanceImporter())->preview($csv,'b.csv',$this->options(['convention'=>'PERIOD_MOVEMENTS']));self::assertTrue($r['validForImport']);self::assertContains('OPENING_REQUIRED',array_column($r['issues'],'code'));
    }
    public function test_xlsx_reads_without_float_and_refuses_formulas():void{
        $r=(new TrialBalanceImporter())->preview($this->xlsx(),'b.xlsx',$this->options());self::assertTrue($r['validForImport']);self::assertSame('1000.00',$r['totalDebit']);
        $this->expectException(\InvalidArgumentException::class);(new TrialBalanceImporter())->preview($this->xlsx(true),'b.xlsx',$this->options());
    }
    public function test_numeric_excel_precision_guard_and_negative_amounts():void{
        $r=(new TrialBalanceImporter())->preview(str_replace('1 234,56','-1',$this->csv()),'b.csv',$this->options());self::assertFalse($r['validForImport']);
        $this->expectException(\InvalidArgumentException::class);AmountParser::excel('1234567890123456');
    }
    public function test_archive_size_and_xml_entities_are_refused():void{
        try{(new TrialBalanceImporter())->preview(str_repeat('x',8*1024*1024+1),'b.csv',$this->options());self::fail('size');}catch(\InvalidArgumentException){}
        $this->expectException(\InvalidArgumentException::class);\App\Domain\Import\SafeXlsx::xml('<!DOCTYPE a [<!ENTITY x SYSTEM "file:///etc/passwd">]><a>&x;</a>');
    }
    public function test_macro_and_external_relationships_are_refused():void{
        $p=tempnam(sys_get_temp_dir(),'zip-test-');file_put_contents($p,$this->xlsx());$zip=new \ZipArchive();$zip->open($p);$zip->addFromString('xl/_rels/evil.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="r1" Target="https://example.com" TargetMode="External" Type="x"/></Relationships>');$zip->close();$bytes=file_get_contents($p);unlink($p);
        $this->expectException(\InvalidArgumentException::class);(new TrialBalanceImporter())->preview($bytes,'b.xlsx',$this->options());
    }
}
