<?php
namespace Tests\Unit;
use PHPUnit\Framework\TestCase;
use App\Domain\Import\AmountParser;
class BalancePrecisionTest extends TestCase
{
    public function test_six_decimal_ledger_values_remain_exact_when_reimported(): void {
        $value='9999999999999999999999.123456';
        $this->assertSame($value,(string)AmountParser::parse($value,'EN'));
        $this->assertSame('4500.00',(string)AmountParser::parse('4500.000000','EN'));
        $this->expectException(\InvalidArgumentException::class);
        AmountParser::parse('1.1234567','EN');
    }
}
