<?php

declare(strict_types=1);

namespace Tests\Unit;

use App\Domain\Updates\SignedReleaseVerifier;
use PHPUnit\Framework\TestCase;
use RuntimeException;
use ZipArchive;

final class UpdatesTest extends TestCase
{
    private string $publicKey;
    private string $secretKey;

    protected function setUp(): void
    {
        parent::setUp();
        $pair = sodium_crypto_sign_keypair();
        $this->publicKey = sodium_crypto_sign_publickey($pair);
        $this->secretKey = sodium_crypto_sign_secretkey($pair);
    }

    private function archive(array $files, bool $symlink = false): string
    {
        $path = tempnam(sys_get_temp_dir(), 'release-test-');
        $zip = new ZipArchive();
        $zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE);
        foreach ($files as $name => $content) {
            $zip->addFromString($name, $content);
            if ($symlink) {
                $zip->setExternalAttributesName($name, ZipArchive::OPSYS_UNIX, 0120777 << 16);
            }
        }
        $zip->close();
        try {
            return file_get_contents($path);
        } finally {
            unlink($path);
        }
    }

    private function manifest(array $files, string $version = '0.2.0', string $parent = '0.1.0'): string
    {
        return json_encode([
            'version' => $version,
            'parentVersion' => $parent,
            'databaseBackwardCompatible' => true,
            'files' => array_map(fn (string $value) => hash('sha256', $value), $files),
        ], JSON_THROW_ON_ERROR);
    }

    private function verify(string $zip, string $manifest, ?string $signature = null): array
    {
        return (new SignedReleaseVerifier($this->publicKey))->verify(
            $zip,
            $manifest,
            $signature ?? sodium_crypto_sign_detached($manifest, $this->secretKey),
            '0.1.0',
        );
    }

    public function test_valid_release_returns_integrity_metadata(): void
    {
        $files = ['app/Controller.php' => '<?php // signed test artifact'];
        $archive = $this->archive($files);
        $result = $this->verify($archive, $this->manifest($files));
        self::assertSame('0.2.0', $result['version']);
        self::assertSame(hash('sha256', $archive), $result['archiveSha256']);
        self::assertTrue($result['databaseBackwardCompatible']);
    }

    public function test_tampered_manifest_signature_is_rejected(): void
    {
        $files = ['app.php' => 'payload'];
        $manifest = $this->manifest($files);
        $signature = sodium_crypto_sign_detached($manifest, $this->secretKey);
        $this->expectExceptionMessage('RELEASE_SIGNATURE_REJECTED');
        $this->verify($this->archive($files), $manifest.' ', $signature);
    }

    public function test_tampered_payload_hash_is_rejected(): void
    {
        $this->expectExceptionMessage('RELEASE_CONTENT_HASH_REJECTED');
        $this->verify($this->archive(['app.php' => 'tampered']), $this->manifest(['app.php' => 'original']));
    }

    public function test_traversal_is_rejected_even_with_a_valid_publisher_signature(): void
    {
        $files = ['../app.php' => 'payload'];
        $this->expectExceptionMessage('RELEASE_PATH_INVALID');
        $this->verify($this->archive($files), $this->manifest($files));
    }

    public function test_signed_downgrade_is_rejected(): void
    {
        $files = ['app.php' => 'payload'];
        $this->expectExceptionMessage('RELEASE_LINEAGE_REJECTED');
        $this->verify($this->archive($files), $this->manifest($files, '0.0.9'));
    }

    public function test_wrong_parent_version_is_rejected(): void
    {
        $files = ['app.php' => 'payload'];
        $this->expectExceptionMessage('RELEASE_LINEAGE_REJECTED');
        $this->verify($this->archive($files), $this->manifest($files, '0.2.0', '0.0.8'));
    }

    public function test_unix_symlinks_are_rejected_without_extraction(): void
    {
        $files = ['app.php' => 'somewhere/else'];
        $this->expectExceptionMessage('RELEASE_SPECIAL_FILE_REJECTED');
        $this->verify($this->archive($files, true), $this->manifest($files));
    }

    public function test_unexpected_and_missing_entries_are_rejected(): void
    {
        $files = ['app.php' => 'payload'];
        try {
            $this->verify($this->archive($files + ['extra.php' => 'unexpected']), $this->manifest($files));
            self::fail('Unexpected entry accepted');
        } catch (RuntimeException $exception) {
            self::assertSame('RELEASE_UNEXPECTED_OR_DUPLICATE_ENTRY', $exception->getMessage());
        }
        $this->expectExceptionMessage('RELEASE_INCOMPLETE');
        $this->verify($this->archive($files), $this->manifest($files + ['missing.php' => 'missing']));
    }

    public function test_high_expansion_ratio_is_rejected(): void
    {
        $files = ['bomb.txt' => str_repeat('A', 1024 * 1024)];
        $this->expectExceptionMessage('RELEASE_EXPANSION_REJECTED');
        $this->verify($this->archive($files), $this->manifest($files));
    }
}
