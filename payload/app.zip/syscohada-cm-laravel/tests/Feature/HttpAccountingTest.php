<?php
namespace Tests\Feature;
use Tests\TestCase;
use App\Models\{User,Company,FiscalYear};
use App\Support\{TenantContext,CompanySetup};
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\{DB,Storage};
use Illuminate\Support\Str;
use Illuminate\Http\UploadedFile;

class HttpAccountingTest extends TestCase
{
    use RefreshDatabase;
    private function fixture(string $role='TENANT_ADMIN',bool $enabled=true): array {
        $t=(string)Str::uuid();$a=(string)Str::uuid();
        return app(TenantContext::class)->run($t,$a,function()use($t,$a,$role,$enabled){
            DB::table('tenants')->insert(['id'=>$t,'name'=>'Tenant test','created_at'=>now(),'updated_at'=>now()]);
            $u=new User(['name'=>'Utilisateur test','email'=>Str::uuid().'@example.test','password'=>'TestPassword123!']);$u->id=$a;$u->tenant_id=$t;$u->role=$role;$u->enabled=true;$u->save();
            $c=app(CompanySetup::class)->create(['name'=>'Micro Test','accounting_system'=>'SMT','virtual_accounting_enabled'=>$enabled]);
            $y=FiscalYear::create(['company_id'=>$c->id,'starts_on'=>'2026-01-01','ends_on'=>'2026-12-31','status'=>'OPEN']);
            $accounts=DB::table('accounts')->where('company_id',$c->id)->pluck('id','code');
            $journal=DB::table('journals')->where('company_id',$c->id)->where('code','CA')->value('id');
            return [$u,$c,$y,$accounts,$journal];
        });
    }
    private function base($c,$y): string {return '/companies/'.$c->id.'/years/'.$y->id;}
    private function guidedData($accounts,$journal): array {return ['type'=>'CASH_SALE','journal_id'=>$journal,'entry_date'=>'2026-11-11','description'=>'Vente de test','reference'=>'FACT-TEST-001','amount'=>'4500.00','cash_account_id'=>$accounts['571000'],'other_account_id'=>$accounts['701000']];}
    public function test_authenticated_pages_render_and_anonymous_redirects(): void {
        $this->get('/dashboard')->assertRedirect('/login');[$u,$c,$y]=$this->fixture();$this->actingAs($u);
        foreach(['/dashboard','/companies/'.$c->id,$this->base($c,$y).'/accounting',$this->base($c,$y).'/import',$this->base($c,$y).'/reports?kind=balance',$this->base($c,$y).'/reports?kind=ledger',$this->base($c,$y).'/reports?kind=cash','/admin'] as $path) $this->get($path)->assertOk();
    }
    public function test_guided_posting_balance_and_dsf_bridge_work_over_http(): void {
        [$u,$c,$y,$a,$j]=$this->fixture();$this->actingAs($u);
        $this->post($this->base($c,$y).'/guided',$this->guidedData($a,$j))->assertRedirect()->assertSessionHasNoErrors();
        $entry=DB::table('entries')->where('company_id',$c->id)->first();$this->assertSame('DRAFT',$entry->status);
        $this->post('/entries/'.$entry->id.'/post')->assertRedirect()->assertSessionHasNoErrors();
        $this->assertDatabaseHas('entries',['id'=>$entry->id,'status'=>'POSTED']);
        $this->get($this->base($c,$y).'/balance.csv')->assertOk()->assertSee('4500.000000',false);
        $this->post($this->base($c,$y).'/import/from-ledger')->assertOk()->assertSee('Contrôles d’import satisfaits');
        $this->post('/entries/'.$entry->id.'/delete')->assertSessionHasErrors();
        $this->assertDatabaseHas('entries',['id'=>$entry->id,'status'=>'POSTED']);
    }
    public function test_tenant_boundaries_and_read_only_roles_are_enforced(): void {
        [$u,$c,$y,$a,$j]=$this->fixture();[$other,$otherCompany]=$this->fixture();
        $this->actingAs($other)->get('/companies/'.$c->id)->assertNotFound();
        [$reader,$rc,$ry,$ra,$rj]=$this->fixture('READ_ONLY');
        $this->actingAs($reader)->post($this->base($rc,$ry).'/guided',$this->guidedData($ra,$rj))->assertForbidden();
        $this->actingAs($u)->post($this->base($c,$y).'/guided',$this->guidedData($a,$j)+['tenant_id'=>$other->tenant_id])->assertRedirect();
        $this->assertDatabaseHas('entries',['company_id'=>$c->id,'tenant_id'=>$u->tenant_id]);
    }
    public function test_module_disabled_blocks_write_and_toggle_is_admin_only(): void {
        [$u,$c,$y,$a,$j]=$this->fixture('ACCOUNTANT',false);$this->actingAs($u);
        $this->post($this->base($c,$y).'/guided',$this->guidedData($a,$j))->assertForbidden();
        $this->post('/companies/'.$c->id.'/settings',['virtual_accounting_enabled'=>'1'])->assertForbidden();
        $this->assertDatabaseCount('entries',0);
    }
    public function test_private_attachment_is_encrypted_and_cannot_cross_tenants(): void {
        Storage::fake('local');[$u,$c,$y,$a,$j]=$this->fixture();$this->actingAs($u);
        $this->post($this->base($c,$y).'/guided',$this->guidedData($a,$j))->assertRedirect();
        $entry=DB::table('entries')->where('company_id',$c->id)->first();
        $pdf="%PDF-1.4\nDocument fictif privé de test\n%%EOF";
        $file=UploadedFile::fake()->createWithContent('piece-test.pdf',$pdf);
        $this->post('/entries/'.$entry->id.'/attachments',['file'=>$file])->assertRedirect()->assertSessionHasNoErrors();
        $attachment=DB::table('attachments')->where('entry_id',$entry->id)->first();
        $this->assertNotNull($attachment);$this->assertStringNotContainsString('Document fictif',Storage::disk('local')->get($attachment->path));
        $this->get('/attachments/'.$attachment->id.'/download')->assertOk()->assertContent($pdf);
        [$other]=$this->fixture();$this->actingAs($other)->get('/attachments/'.$attachment->id.'/download')->assertNotFound();
    }
    public function test_closed_year_blocks_writes_and_nested_actor_switch_is_denied(): void {
        [$u,$c,$y,$a,$j]=$this->fixture();$this->actingAs($u);
        $this->post($this->base($c,$y).'/close',['confirmation'=>'CLOTURER'])->assertRedirect();
        $this->postJson($this->base($c,$y).'/guided',$this->guidedData($a,$j))->assertStatus(409);
        $this->expectException(\Symfony\Component\HttpKernel\Exception\HttpException::class);
        app(TenantContext::class)->run($u->tenant_id,(string)$u->id,fn()=>app(TenantContext::class)->run($u->tenant_id,(string)Str::uuid(),fn()=>null));
    }
    public function test_login_logout_and_invalid_credentials_are_handled(): void {
        [$u]=$this->fixture();
        $this->post('/login',['email'=>$u->email,'password'=>'wrong'])->assertSessionHasErrors('email');
        $this->assertGuest();
        $this->post('/login',['email'=>$u->email,'password'=>'TestPassword123!'])->assertRedirect('/dashboard');
        $this->assertAuthenticatedAs($u);
        $this->post('/logout')->assertRedirect('/login');$this->assertGuest();
    }
    public function test_csrf_rejects_missing_token_outside_test_bypass(): void {
        $this->app->instance('env','local');
        $this->post('/login',['email'=>'nobody@example.test','password'=>'TestPassword123!'])->assertStatus(419);
    }

}
