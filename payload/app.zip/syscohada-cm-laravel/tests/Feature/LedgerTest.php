<?php

namespace Tests\Feature;

use App\Domain\Accounting\AccountingException;
use App\Domain\Accounting\GuidedEntryService;
use App\Domain\Accounting\LedgerService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Tests\TestCase;

class LedgerTest extends TestCase
{
    use RefreshDatabase;

    private array $f;
    private LedgerService $ledger;

    protected function setUp(): void
    {
        parent::setUp();
        $this->ledger = app(LedgerService::class);
        $this->f = $this->fixture();
    }

    private function fixture(): array
    {
        $tenant = (string) Str::uuid();
        $actor = (string) Str::uuid();
        $company = (string) Str::uuid();
        $year = (string) Str::uuid();
        $journal = (string) Str::uuid();
        DB::table('tenants')->insert(['id' => $tenant, 'name' => 'Tenant test']);
        DB::table('users')->insert(['id' => $actor, 'tenant_id' => $tenant, 'name' => 'Comptable',
            'email' => Str::uuid().'@example.test', 'password' => 'unused', 'role' => 'ACCOUNTANT', 'enabled' => true]);
        DB::table('companies')->insert(['id' => $company, 'tenant_id' => $tenant, 'name' => 'Micro test',
            'accounting_system' => 'SMT', 'virtual_accounting_enabled' => true]);
        DB::table('fiscal_years')->insert(['id' => $year, 'tenant_id' => $tenant, 'company_id' => $company,
            'starts_on' => '2026-01-01', 'ends_on' => '2026-12-31', 'status' => 'OPEN']);
        DB::table('journals')->insert(['id' => $journal, 'tenant_id' => $tenant, 'company_id' => $company,
            'code' => 'CA', 'name' => 'Caisse', 'kind' => 'CASH', 'next_number' => 1]);
        $accounts = [];
        foreach (['571000' => ['Caisse', true], '521000' => ['Banque', true], '701000' => ['Ventes', false], '601000' => ['Achats', false], '411000' => ['Clients', false]] as $code => [$name, $cash]) {
            $id = (string) Str::uuid();
            DB::table('accounts')->insert(['id' => $id, 'tenant_id' => $tenant, 'company_id' => $company,
                'code' => $code, 'name' => $name, 'is_cash' => $cash, 'active' => true]);
            $accounts[$code] = $id;
        }

        return compact('tenant', 'actor', 'company', 'year', 'journal', 'accounts');
    }

    private function data(string $amount = '100.10'): array
    {
        return ['company_id' => $this->f['company'], 'fiscal_year_id' => $this->f['year'], 'journal_id' => $this->f['journal'],
            'entry_date' => '2026-02-10', 'description' => 'Vente fictive payée', 'reference' => 'PIECE-001',
            'lines' => [
                ['account_id' => $this->f['accounts']['571000'], 'debit' => $amount, 'credit' => '0'],
                ['account_id' => $this->f['accounts']['701000'], 'debit' => '0', 'credit' => $amount],
            ]];
    }

    private function assertAccountingError(string $code, callable $action): void
    {
        try {
            $action();
            $this->fail('Expected AccountingException '.$code);
        } catch (AccountingException $e) {
            $this->assertSame($code, $e->errorCode);
        }
    }

    public function test_draft_is_excluded_then_posting_is_exact_numbered_and_idempotent(): void
    {
        $entry = $this->ledger->draft($this->data('9999999999999999.123456'), $this->f['tenant'], $this->f['actor']);
        $this->assertSame([], $this->ledger->trialBalance($this->f['company'], $this->f['year'], $this->f['tenant'], $this->f['actor'])['rows']);
        $posted = $this->ledger->post($entry, $this->f['tenant'], $this->f['actor']);
        $this->assertSame('CA/2026/000001', $posted['number']);
        $this->assertSame($posted, $this->ledger->post($entry, $this->f['tenant'], $this->f['actor']));
        $this->assertSame(2, (int) DB::table('journals')->where('id', $this->f['journal'])->value('next_number'));
        $balance = $this->ledger->trialBalance($this->f['company'], $this->f['year'], $this->f['tenant'], $this->f['actor']);
        $this->assertTrue($balance['balanced']);
        $this->assertSame('9999999999999999.123456', $balance['total_debit']);
        $this->assertSame('9999999999999999.123456', $balance['total_credit']);
        $this->assertAccountingError('IMMUTABLE_ENTRY', fn () => $this->ledger->updateDraft($entry, $this->data('1'), $this->f['tenant'], $this->f['actor']));
        $this->assertAccountingError('IMMUTABLE_ENTRY', fn () => $this->ledger->deleteDraft($entry, $this->f['tenant'], $this->f['actor']));
    }

    public function test_unbalanced_draft_can_be_fixed_but_never_posted(): void
    {
        $data = $this->data();
        $data['lines'][1]['credit'] = '100.09';
        $entry = $this->ledger->draft($data, $this->f['tenant'], $this->f['actor']);
        $this->assertAccountingError('UNBALANCED', fn () => $this->ledger->post($entry, $this->f['tenant'], $this->f['actor']));
        $this->assertSame(1, (int) DB::table('journals')->where('id', $this->f['journal'])->value('next_number'));
        $this->ledger->updateDraft($entry, $this->data(), $this->f['tenant'], $this->f['actor']);
        $this->assertSame('POSTED', $this->ledger->post($entry, $this->f['tenant'], $this->f['actor'])['status']);
    }

    public function test_float_wrong_company_and_other_tenant_are_rejected(): void
    {
        $data = $this->data();
        $data['lines'][0]['debit'] = 0.1;
        $this->assertAccountingError('DECIMAL_REQUIRED', fn () => $this->ledger->draft($data, $this->f['tenant'], $this->f['actor']));
        $other = $this->fixture();
        $data = $this->data();
        $data['lines'][0]['account_id'] = $other['accounts']['571000'];
        $this->assertAccountingError('ACCOUNT_SCOPE', fn () => $this->ledger->draft($data, $this->f['tenant'], $this->f['actor']));
        $entry = $this->ledger->draft($this->data(), $this->f['tenant'], $this->f['actor']);
        $this->assertAccountingError('ENTRY_NOT_FOUND', fn () => $this->ledger->post($entry, $other['tenant'], $other['actor']));
        $this->assertAccountingError('UNAUTHORISED', fn () => $this->ledger->post($entry, $this->f['tenant'], $other['actor']));
    }

    public function test_same_tenant_other_company_accounts_are_rejected(): void
    {
        $otherCompany = (string) Str::uuid();
        $otherAccount = (string) Str::uuid();
        DB::table('companies')->insert(['id' => $otherCompany, 'tenant_id' => $this->f['tenant'], 'name' => 'Deuxième société', 'virtual_accounting_enabled' => true]);
        DB::table('accounts')->insert(['id' => $otherAccount, 'tenant_id' => $this->f['tenant'], 'company_id' => $otherCompany,
            'code' => '571000', 'name' => 'Autre caisse', 'active' => true, 'is_cash' => true]);
        $data = $this->data();
        $data['lines'][0]['account_id'] = $otherAccount;
        $this->assertAccountingError('ACCOUNT_SCOPE', fn () => $this->ledger->draft($data, $this->f['tenant'], $this->f['actor']));
    }

    public function test_closed_year_and_disabled_optional_module_block_writes(): void
    {
        $entry = $this->ledger->draft($this->data(), $this->f['tenant'], $this->f['actor']);
        DB::table('fiscal_years')->where('id', $this->f['year'])->update(['status' => 'CLOSED']);
        $this->assertAccountingError('YEAR_CLOSED', fn () => $this->ledger->post($entry, $this->f['tenant'], $this->f['actor']));
        DB::table('fiscal_years')->where('id', $this->f['year'])->update(['status' => 'OPEN']);
        DB::table('companies')->where('id', $this->f['company'])->update(['virtual_accounting_enabled' => false]);
        $this->assertAccountingError('MODULE_DISABLED', fn () => $this->ledger->draft($this->data(), $this->f['tenant'], $this->f['actor']));
        $this->assertAccountingError('MODULE_DISABLED', fn () => $this->ledger->post($entry, $this->f['tenant'], $this->f['actor']));
    }

    public function test_negative_correction_requires_review_and_leaves_original_immutable(): void
    {
        $entry = $this->ledger->draft($this->data(), $this->f['tenant'], $this->f['actor']);
        $this->ledger->post($entry, $this->f['tenant'], $this->f['actor']);
        $correction = $this->ledger->reverse($entry, $this->f['tenant'], $this->f['actor'], '2026-02-11', 'Pièce erronée');
        $this->assertSame('DRAFT', DB::table('entries')->where('id', $correction)->value('status'));
        $this->assertSame('-100.100000', DB::table('entry_lines')->where('entry_id', $correction)->orderBy('sort_order')->value('debit'));
        $this->assertSame('POSTED', $this->ledger->post($correction, $this->f['tenant'], $this->f['actor'])['status']);
        $balance = $this->ledger->trialBalance($this->f['company'], $this->f['year'], $this->f['tenant'], $this->f['actor']);
        $this->assertSame('0.000000', $balance['total_debit']);
        $cash = $this->ledger->cashBook($this->f['company'], $this->f['year'], $this->f['tenant'], $this->f['actor']);
        $this->assertSame('0.000000', $cash['inflows']);
        $this->assertSame('0.000000', $cash['outflows']);
        $this->assertSame('0.000000', $cash['balance']);
        $this->assertTrue($cash['rows'][1]['correction']);
        $this->assertSame('-100.100000', $cash['rows'][1]['inflow']);
        $this->assertSame('0.000000', $cash['rows'][1]['outflow']);
        $this->assertSame('POSTED', DB::table('entries')->where('id', $entry)->value('status'));
        $this->assertAccountingError('ALREADY_REVERSED', fn () => $this->ledger->reverse($entry, $this->f['tenant'], $this->f['actor'], '2026-02-12', 'Encore'));
    }

    public function test_guided_cash_and_bank_transfers_do_not_double_cash_receipts(): void
    {
        $guided = app(GuidedEntryService::class);
        $base = $this->data();
        unset($base['lines']);
        $sale = $guided->draft('CASH_SALE', $base + ['amount' => '100.10', 'cash_account_id' => $this->f['accounts']['571000'], 'other_account_id' => $this->f['accounts']['701000']], $this->f['tenant'], $this->f['actor']);
        $this->ledger->post($sale, $this->f['tenant'], $this->f['actor']);
        $transfer = $guided->draft('BANK_TRANSFER', $base + ['amount' => '20', 'cash_account_id' => $this->f['accounts']['571000'], 'other_account_id' => $this->f['accounts']['521000']], $this->f['tenant'], $this->f['actor']);
        $this->ledger->post($transfer, $this->f['tenant'], $this->f['actor']);
        $cash = $this->ledger->cashBook($this->f['company'], $this->f['year'], $this->f['tenant'], $this->f['actor']);
        $this->assertSame('100.100000', $cash['inflows']);
        $this->assertSame('0.000000', $cash['outflows']);
        $this->assertSame('100.100000', $cash['balance']);
        $this->assertTrue($cash['rows'][1]['internal_transfer']);
        $ledger = $this->ledger->generalLedger($this->f['company'], $this->f['year'], $this->f['tenant'], $this->f['actor'], $this->f['accounts']['571000']);
        $this->assertCount(2, $ledger['rows']);
        $this->assertSame('80.100000', $ledger['rows'][1]['running_balance']);
    }

    public function test_idempotency_conflict_read_only_and_audit_are_enforced(): void
    {
        $data = $this->data() + ['idempotency_key' => 'operation-123'];
        $id = $this->ledger->draft($data, $this->f['tenant'], $this->f['actor']);
        $this->assertSame($id, $this->ledger->draft($data, $this->f['tenant'], $this->f['actor']));
        $changed = $data;
        $changed['description'] = 'Autre opération';
        $this->assertAccountingError('IDEMPOTENCY_CONFLICT', fn () => $this->ledger->draft($changed, $this->f['tenant'], $this->f['actor']));
        $this->ledger->post($id, $this->f['tenant'], $this->f['actor']);
        $audit = DB::table('audit_events')->where('table_name', 'entries')->where('record_id', $id)->where('action', 'UPDATE')->first();
        $this->assertSame('DRAFT', json_decode($audit->old_values, true)['status']);
        $this->assertSame('POSTED', json_decode($audit->new_values, true)['status']);
        $this->assertSame($this->f['actor'], $audit->actor_id);
        DB::table('users')->where('id', $this->f['actor'])->update(['role' => 'READ_ONLY']);
        $this->assertAccountingError('UNAUTHORISED', fn () => $this->ledger->draft($this->data(), $this->f['tenant'], $this->f['actor']));
        $this->assertTrue($this->ledger->trialBalance($this->f['company'], $this->f['year'], $this->f['tenant'], $this->f['actor'])['balanced']);
    }

    public function test_posting_requires_a_piece_reference_or_an_attached_document(): void
    {
        $data = $this->data();
        $data['reference'] = null;
        $entry = $this->ledger->draft($data, $this->f['tenant'], $this->f['actor']);
        $this->assertAccountingError('SUPPORTING_DOCUMENT_REQUIRED', fn () => $this->ledger->post($entry, $this->f['tenant'], $this->f['actor']));
        DB::table('attachments')->insert(['id' => (string) Str::uuid(), 'tenant_id' => $this->f['tenant'], 'company_id' => $this->f['company'],
            'entry_id' => $entry, 'path' => 'private/encrypted-document', 'original_name' => 'piece-test.pdf', 'mime' => 'application/pdf',
            'size' => 100, 'sha256' => str_repeat('a', 64)]);
        $this->assertSame('POSTED', $this->ledger->post($entry, $this->f['tenant'], $this->f['actor'])['status']);
    }

    public function test_account_totals_can_exceed_the_capacity_of_one_line_without_losing_precision(): void
    {
        foreach (range(1, 2) as $n) {
            $data = $this->data('6000000000000000000000.000001');
            $data['reference'] = 'PIECE-'.$n;
            $entry = $this->ledger->draft($data, $this->f['tenant'], $this->f['actor']);
            $this->ledger->post($entry, $this->f['tenant'], $this->f['actor']);
        }
        $balance = $this->ledger->trialBalance($this->f['company'], $this->f['year'], $this->f['tenant'], $this->f['actor']);
        $this->assertSame('12000000000000000000000.000002', $balance['total_debit']);
        $this->assertSame('12000000000000000000000.000002', $balance['total_credit']);
    }

    public function test_correcting_a_cash_expense_cancels_outflow_instead_of_inventing_an_inflow(): void
    {
        $data = $this->data();
        unset($data['lines']);
        $entry = app(GuidedEntryService::class)->draft('CASH_EXPENSE', $data + [
            'amount' => '40.25', 'cash_account_id' => $this->f['accounts']['571000'],
            'other_account_id' => $this->f['accounts']['601000'],
        ], $this->f['tenant'], $this->f['actor']);
        $this->ledger->post($entry, $this->f['tenant'], $this->f['actor']);
        $correction = $this->ledger->reverse($entry, $this->f['tenant'], $this->f['actor'], '2026-02-11', 'Annulation de la pièce erronée');
        $this->ledger->post($correction, $this->f['tenant'], $this->f['actor']);
        $cash = $this->ledger->cashBook($this->f['company'], $this->f['year'], $this->f['tenant'], $this->f['actor']);
        $this->assertSame('0.000000', $cash['inflows']);
        $this->assertSame('0.000000', $cash['outflows']);
        $this->assertSame('0.000000', $cash['balance']);
        $this->assertSame('40.250000', $cash['rows'][0]['outflow']);
        $this->assertTrue($cash['rows'][1]['correction']);
        $this->assertSame('0.000000', $cash['rows'][1]['inflow']);
        $this->assertSame('-40.250000', $cash['rows'][1]['outflow']);
    }
}
