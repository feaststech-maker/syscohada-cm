<?php
namespace App\Support;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

final class TenantContext
{
    public ?string $tenantId = null;
    public ?string $actorId = null;
    public ?string $requestId = null;

    public function run(string $tenant, string $actor, callable $work): mixed
    {
        abort_unless(Str::isUuid($tenant) && Str::isUuid($actor), 403);
        abort_if($this->tenantId !== null && ($this->tenantId !== $tenant || $this->actorId !== $actor), 403);
        $old = [$this->tenantId, $this->actorId, $this->requestId];
        $this->tenantId = $tenant; $this->actorId = $actor; $this->requestId ??= (string) Str::uuid();
        try {
            return DB::transaction(function () use ($work, $tenant, $actor) {
                if (DB::getDriverName() === 'pgsql') {
                    DB::select("select set_config('app.tenant_id', ?, true), set_config('app.actor_id', ?, true), set_config('app.request_id', ?, true)", [$tenant, $actor, $this->requestId]);
                }
                return $work();
            });
        } finally {
            [$this->tenantId, $this->actorId, $this->requestId] = $old;
        }
    }
}
