<?php
namespace App\Support;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

final class Audit
{
    /** PostgreSQL audits in database triggers. SQLite is a local/test adapter only. */
    public static function local(string $table, string $id, string $action, ?array $old, ?array $new): void
    {
        if (DB::getDriverName() === 'pgsql') return;
        $ctx = app(TenantContext::class);
        if (!$ctx->tenantId || !$ctx->actorId) throw new \LogicException('Contexte d’audit obligatoire.');
        DB::table('audit_events')->insert([
            'id'=>(string) Str::uuid(), 'tenant_id'=>$ctx->tenantId, 'actor_id'=>$ctx->actorId,
            'table_name'=>$table, 'action'=>$action, 'record_id'=>$id,
            'old_values'=>$old === null ? null : json_encode($old, JSON_THROW_ON_ERROR),
            'new_values'=>$new === null ? null : json_encode($new, JSON_THROW_ON_ERROR),
            'request_id'=>$ctx->requestId, 'created_at'=>now(),
        ]);
    }
}
