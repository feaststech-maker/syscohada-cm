<?php
namespace App\Support;
use App\Models\{Company, Account, Journal};
final class CompanySetup
{
    public function create(array $data): Company {
        $company=Company::create($data);
        // Starting accounts only; this is not a complete or approved SYSCOHADA chart.
        foreach([
            ['101000','Capital social',false],['401000','Fournisseurs',false],['411000','Clients',false],
            ['521000','Banque locale',true],['571000','Caisse',true],['601000','Achats de marchandises',false],['701000','Ventes de marchandises',false],
        ] as [$code,$name,$cash]) Account::create(['company_id'=>$company->id,'code'=>$code,'name'=>$name,'is_cash'=>$cash,'active'=>true]);
        foreach([['CA','Caisse','CASH'],['BQ','Banque','BANK'],['VE','Ventes','SALES'],['AC','Achats','PURCHASES'],['OD','Opérations diverses','GENERAL']] as [$code,$name,$kind])
            Journal::create(['company_id'=>$company->id,'code'=>$code,'name'=>$name,'kind'=>$kind,'next_number'=>1]);
        return $company;
    }
}
