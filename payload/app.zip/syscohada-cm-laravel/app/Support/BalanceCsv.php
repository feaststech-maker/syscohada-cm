<?php
namespace App\Support;
final class BalanceCsv
{
    public static function fromReport(array $report): string {
        abort_if(count($report['rows'])>25000,413,'La balance dépasse le plafond de cette version.');
        $stream=fopen('php://memory','r+');
        fputcsv($stream,['Compte','Libellé','Débit','Crédit'],';','"','');
        foreach($report['rows'] as $row) {
            $label=$row['name'];
            if(preg_match('/^[\s]*[=+\-@]/u',$label)) $label="'".$label;
            fputcsv($stream,[$row['code'],$label,$row['closing_debit'],$row['closing_credit']],';','"','');
        }
        rewind($stream);$bytes=stream_get_contents($stream);fclose($stream);
        abort_if(strlen($bytes)>8*1024*1024,413,'La balance dépasse le plafond d’import.');
        return $bytes;
    }
}
