<?php
namespace App\Providers;
use App\Support\TenantContext;
use App\Observers\BusinessObserver;
use Illuminate\Support\ServiceProvider;
class AppServiceProvider extends ServiceProvider {
 public function register(): void { $this->app->scoped(TenantContext::class,fn()=>new TenantContext()); }
 public function boot(): void {
  foreach ([\App\Models\Company::class,\App\Models\FiscalYear::class,\App\Models\Account::class,\App\Models\Journal::class,\App\Models\Attachment::class,\App\Models\TaxAdjustment::class,\App\Models\AdminSetting::class] as $model) $model::observe(BusinessObserver::class);
 }
}
