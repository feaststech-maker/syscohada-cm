<?php
namespace App\Http\Middleware;
use App\Support\TenantContext;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;
final class TenantMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();
        abort_unless($user && $user->enabled && $user->tenant_id, 403, 'Adhésion active à une entreprise requise.');
        if (app()->environment('production')) {
            abort_unless(DB::getDriverName() === 'pgsql', 503, 'PostgreSQL requis en production.');
            $role = DB::selectOne("select r.rolsuper, r.rolbypassrls, exists(select 1 from pg_class c where c.relname='entries' and c.relnamespace='public'::regnamespace and c.relowner=r.oid) as owns_data, exists(select 1 from pg_class c where c.relname='entries' and c.relnamespace='public'::regnamespace and c.relrowsecurity and c.relforcerowsecurity) as guards_ready from pg_roles r where rolname=current_user");
            $flag=fn($v)=>in_array($v,[true,1,'1','t','true'],true);
            abort_if(!$role || $flag($role->rolsuper) || $flag($role->rolbypassrls) || $flag($role->owns_data) || !$flag($role->guards_ready), 503, 'Compte de base non conforme.');
        }
        return app(TenantContext::class)->run($user->tenant_id, (string)$user->id, fn()=>$next($request));
    }
}
