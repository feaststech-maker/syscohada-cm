<?php
namespace App\Http\Controllers;
use App\Models\{Entry,Attachment};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\{Crypt,Storage};
use Illuminate\Support\Str;
class AttachmentController extends Controller
{
    public function store(Request $request,string $entry) {
        $this->writers($request);$entry=Entry::findOrFail($entry);$company=$this->company($entry->company_id);
        abort_unless($company->virtual_accounting_enabled,403);
        $request->validate(['file'=>'required|file|max:8192|mimetypes:application/pdf,image/jpeg,image/png']);
        $file=$request->file('file');$bytes=$file->get();$sha=hash('sha256',$bytes);
        $path='financial-private/'.$request->user()->tenant_id.'/'.$company->id.'/'.Str::uuid().'.enc';
        $payload=json_encode(['version'=>1,'tenant'=>$request->user()->tenant_id,'company'=>(string)$company->id,'entry'=>(string)$entry->id,'sha256'=>$sha,'body'=>base64_encode($bytes)],JSON_THROW_ON_ERROR);
        $ciphertext=Crypt::encryptString($payload);
        if(!Storage::disk('local')->put($path,$ciphertext)) abort(503,'Archivage indisponible.');
        try {
            Attachment::create(['company_id'=>$company->id,'entry_id'=>$entry->id,'path'=>$path,'original_name'=>Str::limit(basename(str_replace('\\','/',$file->getClientOriginalName())),200,''),'mime'=>$file->getMimeType(),'size'=>strlen($bytes),'sha256'=>$sha]);
        } catch(\Throwable $error) { Storage::disk('local')->delete($path);throw $error; }
        return back()->with('success','Pièce justificative archivée et chiffrée.');
    }
    public function download(Request $request,string $attachment) {
        $attachment=Attachment::findOrFail($attachment);
        $expected='financial-private/'.$request->user()->tenant_id.'/'.$attachment->company_id.'/';
        abort_unless(str_starts_with($attachment->path,$expected) && preg_match('/^[a-f0-9-]+\.enc$/',substr($attachment->path,strlen($expected))),403);
        try {
            $data=json_decode(Crypt::decryptString(Storage::disk('local')->get($attachment->path)),true,flags:JSON_THROW_ON_ERROR);
            $bytes=base64_decode($data['body'],true);
        } catch(\Throwable) { abort(503,'Pièce indisponible ou intégrité non vérifiable.'); }
        abort_unless($data['tenant']===$request->user()->tenant_id && $data['company']===$attachment->company_id && $data['entry']===$attachment->entry_id && is_string($bytes) && hash_equals($attachment->sha256,hash('sha256',$bytes)),403);
        $name=preg_replace('/[^A-Za-z0-9._-]/','_', $attachment->original_name) ?: 'piece';
        return response($bytes,200,['Content-Type'=>$attachment->mime,'Content-Disposition'=>'attachment; filename="'.$name.'"','X-Content-Type-Options'=>'nosniff','Cache-Control'=>'private, no-store']);
    }
}
