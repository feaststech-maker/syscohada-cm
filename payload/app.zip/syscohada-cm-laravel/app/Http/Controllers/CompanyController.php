<?php
namespace App\Http\Controllers;
use App\Models\{Company,FiscalYear,Account,Journal,Entry};
use App\Support\CompanySetup;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
class CompanyController extends Controller
{
    public function dashboard() { return view('dashboard',['companies'=>Company::query()->orderBy('name')->get()]); }
    public function store(Request $request,CompanySetup $setup) {
        $this->administrators($request);
        $data=$request->validate(['name'=>'required|string|max:240','niu'=>'nullable|string|max:30','accounting_system'=>['required',Rule::in(['NORMAL','SMT'])],'fiscal_regime'=>'nullable|string|max:40','virtual_accounting_enabled'=>'sometimes|boolean']);
        $data['virtual_accounting_enabled']=$request->boolean('virtual_accounting_enabled');
        $company=$setup->create($data);return redirect('/companies/'.$company->id)->with('success','Entreprise créée. Vérifiez et adaptez le plan de comptes de départ.');
    }
    public function show(string $company) { $company=$this->company($company);return view('company',['company'=>$company,'years'=>FiscalYear::where('company_id',$company->id)->orderByDesc('starts_on')->get(),'accounts'=>Account::where('company_id',$company->id)->orderBy('code')->get(),'journals'=>Journal::where('company_id',$company->id)->get()]); }
    public function settings(Request $request,string $company) {
        $this->administrators($request);$company=$this->company($company);
        $request->validate(['virtual_accounting_enabled'=>'sometimes|boolean']);
        $company->update(['virtual_accounting_enabled'=>$request->boolean('virtual_accounting_enabled')]);
        return back()->with('success','Option comptabilité virtuelle mise à jour. Les écritures existantes sont conservées.');
    }
    public function yearStore(Request $request,string $company) {
        $this->writers($request);$company=$this->company($company);
        $data=$request->validate(['starts_on'=>'required|date_format:Y-m-d','ends_on'=>'required|date_format:Y-m-d|after_or_equal:starts_on']);
        Company::whereKey($company->id)->lockForUpdate()->firstOrFail();
        abort_if(FiscalYear::where('company_id',$company->id)->where('starts_on','<=',$data['ends_on'])->where('ends_on','>=',$data['starts_on'])->exists(),422,'Périodes comptables superposées.');
        $year=FiscalYear::create($data+['company_id'=>$company->id,'status'=>'OPEN']);
        return redirect('/companies/'.$company->id.'/years/'.$year->id.'/accounting');
    }
    public function accountStore(Request $request,string $company) {
        $this->writers($request);$company=$this->company($company);
        $data=$request->validate(['code'=>'required|regex:/^[1-8][0-9]{1,19}$/','name'=>'required|string|max:200','is_cash'=>'sometimes|boolean']);
        abort_if(Account::where('company_id',$company->id)->where('code',$data['code'])->exists(),422,'Ce compte existe déjà.');
        if($request->boolean('is_cash') && !str_starts_with($data['code'],'5')) abort(422,'Un compte de trésorerie doit appartenir à la classe 5.');
        Account::create($data+['company_id'=>$company->id,'active'=>true]);return back()->with('success','Compte ajouté.');
    }
    public function journalStore(Request $request,string $company) {
        $this->writers($request);$company=$this->company($company);
        $data=$request->validate(['code'=>'required|regex:/^[A-Z0-9]{1,12}$/','name'=>'required|string|max:200','kind'=>['required',Rule::in(['SALES','PURCHASES','CASH','BANK','GENERAL'])]]);
        abort_if(Journal::where('company_id',$company->id)->where('code',$data['code'])->exists(),422,'Ce journal existe déjà.');
        Journal::create($data+['company_id'=>$company->id,'next_number'=>1]);return back()->with('success','Journal ajouté.');
    }
    public function closeYear(Request $request,string $company,string $year) {
        $this->administrators($request);$company=$this->company($company);$year=$this->year($company,$year);
        $request->validate(['confirmation'=>'required|in:CLOTURER']);
        $year=FiscalYear::whereKey($year->id)->lockForUpdate()->firstOrFail();
        abort_if(Entry::where('fiscal_year_id',$year->id)->where('status','DRAFT')->exists(),422,'Traitez les brouillons avant la clôture.');
        $year->update(['status'=>'CLOSED']);return back()->with('success','Exercice clôturé : aucune nouvelle écriture ne peut y être comptabilisée.');
    }
}
