<?php
namespace App\Http\Controllers;
use App\Domain\Accounting\LedgerService;
use App\Domain\Import\TrialBalanceImporter;
use App\Support\BalanceCsv;
use Illuminate\Http\Request;
class LedgerBridgeController extends Controller
{
    public function csv(Request $request,string $company,string $year,LedgerService $ledger) {
        $company=$this->company($company);$year=$this->year($company,$year);
        $report=$ledger->trialBalance($company->id,$year->id,$request->user()->tenant_id,(string)$request->user()->id);
        return response(BalanceCsv::fromReport($report),200,['Content-Type'=>'text/csv; charset=UTF-8','Content-Disposition'=>'attachment; filename="balance-comptabilisee.csv"','Cache-Control'=>'private, no-store']);
    }
    public function preview(Request $request,string $company,string $year,LedgerService $ledger,TrialBalanceImporter $importer) {
        $this->writers($request);$company=$this->company($company);$year=$this->year($company,$year);
        $report=$ledger->trialBalance($company->id,$year->id,$request->user()->tenant_id,(string)$request->user()->id);
        $options=['headerRow'=>1,'numberStyle'=>'EN','delimiter'=>';','convention'=>'CLOSING_BALANCE','columns'=>['ACCOUNT'=>0,'LABEL'=>1,'DEBIT'=>2,'CREDIT'=>3]];
        $preview=$importer->preview(BalanceCsv::fromReport($report),'balance-comptabilisee.csv',$options);
        return view('import',compact('company','year','preview','options'));
    }
}
