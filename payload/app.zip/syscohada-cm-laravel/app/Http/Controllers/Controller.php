<?php
namespace App\Http\Controllers;
use App\Models\Company;
use App\Models\FiscalYear;
use Illuminate\Http\Request;
abstract class Controller
{
    protected function writers(Request $request): void { abort_unless(in_array($request->user()->role,['TENANT_ADMIN','ACCOUNTANT'],true),403); }
    protected function administrators(Request $request): void { abort_unless(in_array($request->user()->role,['TENANT_ADMIN','PLATFORM_ADMIN'],true),403); }
    protected function company(string $id): Company { return Company::query()->findOrFail($id); }
    protected function year(Company $company,string $id): FiscalYear { return FiscalYear::query()->where('company_id',$company->id)->findOrFail($id); }
}
