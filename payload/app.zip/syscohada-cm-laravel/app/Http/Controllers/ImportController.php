<?php
namespace App\Http\Controllers;
use App\Domain\Import\TrialBalanceImporter;
use Illuminate\Http\Request;
class ImportController extends Controller
{
    public function show(string $company,string $year) { $company=$this->company($company);$year=$this->year($company,$year);return view('import',compact('company','year')+['preview'=>null]); }
    public function preview(Request $request,string $company,string $year,TrialBalanceImporter $importer) {
        $this->writers($request);$company=$this->company($company);$year=$this->year($company,$year);
        $request->validate(['file'=>'required|file|max:8192','options'=>'required|array','options.headerRow'=>'required|integer|min:1|max:20','options.numberStyle'=>'required|in:FR,EN','options.convention'=>'required|in:CLOSING_BALANCE,PERIOD_MOVEMENTS']);
        $file=$request->file('file');$options=$request->input('options');
        if(isset($options['columns'])) $options['columns']=array_map('intval',array_filter($options['columns'],fn($v)=>$v!=='' && $v!==null));
        $preview=$importer->preview($file->get(),$file->getClientOriginalName(),$options);
        if($request->expectsJson()) return response()->json($preview);
        return view('import',compact('company','year','preview','options'));
    }
}
