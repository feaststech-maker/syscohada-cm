<?php
namespace App\Http\Controllers;
use App\Models\AdminSetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class AdminController extends Controller
{
    public function index(Request $request) {
        $this->administrators($request);
        return view('admin',['settings'=>AdminSetting::orderByDesc('created_at')->limit(100)->get(),'templates'=>DB::table('dgi_templates')->where('tenant_id',$request->user()->tenant_id)->get()]);
    }
    public function store(Request $request) {
        $this->administrators($request);
        $data=$request->validate(['type'=>'required|in:rule,pricing,setting','key'=>'required|regex:/^[a-zA-Z0-9_.-]{1,100}$/','value'=>'required|string|max:4096']);
        AdminSetting::create($data+['status'=>'DRAFT']);
        return back()->with('success','Brouillon enregistré. Aucune règle de production ni facturation n’a été activée.');
    }
}
