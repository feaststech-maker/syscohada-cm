<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Validation\ValidationException;
class AuthController extends Controller
{
    public function login() { return view('auth.login'); }
    public function authenticate(Request $request) {
        $data=$request->validate(['email'=>'required|string|email|max:255','password'=>'required|string|max:512']);
        $key='login:'.hash('sha256',strtolower($data['email']).'|'.$request->ip());
        if(RateLimiter::tooManyAttempts($key,5)) throw ValidationException::withMessages(['email'=>'Trop de tentatives. Réessayez plus tard.']);
        if(!Auth::attempt(['email'=>strtolower($data['email']),'password'=>$data['password'],'enabled'=>true],false)) {
            RateLimiter::hit($key,300);
            throw ValidationException::withMessages(['email'=>'Connexion impossible avec ces identifiants.']);
        }
        RateLimiter::clear($key);$request->session()->regenerate();
        return redirect()->intended('/dashboard');
    }
    public function logout(Request $request) { Auth::logout();$request->session()->invalidate();$request->session()->regenerateToken();return redirect('/login'); }
}
