<?php
namespace App\Http\Controllers;
use App\Models\{Account,Journal,Entry};
use App\Domain\Accounting\{LedgerService,GuidedEntryService};
use Illuminate\Http\Request;
class AccountingController extends Controller
{
    public function index(string $company,string $year) {
        $company=$this->company($company);$year=$this->year($company,$year);
        return view('accounting',['company'=>$company,'year'=>$year,'accounts'=>Account::where('company_id',$company->id)->where('active',true)->orderBy('code')->get(),'journals'=>Journal::where('company_id',$company->id)->orderBy('code')->get(),'entries'=>Entry::with(['lines.account','journal','attachments'])->where('company_id',$company->id)->where('fiscal_year_id',$year->id)->orderByDesc('created_at')->limit(100)->get()]);
    }
    public function draft(Request $request,string $company,string $year,LedgerService $ledger) {
        $this->writers($request);$company=$this->company($company);$year=$this->year($company,$year);
        $data=$request->validate(['journal_id'=>'required|uuid','entry_date'=>'required|date_format:Y-m-d','description'=>'required|string|max:500','reference'=>'nullable|string|max:200','idempotency_key'=>'nullable|uuid','lines'=>'required|array|min:1|max:100','lines.*.account_id'=>'required|uuid','lines.*.debit'=>'required|string|max:40','lines.*.credit'=>'required|string|max:40','lines.*.label'=>'nullable|string|max:500']);
        $data+=['company_id'=>$company->id,'fiscal_year_id'=>$year->id];
        $ledger->draft($data,$request->user()->tenant_id,(string)$request->user()->id);
        return back()->with('success','Brouillon enregistré : vérifiez-le avant comptabilisation.');
    }
    public function guided(Request $request,string $company,string $year,GuidedEntryService $guided) {
        $this->writers($request);$company=$this->company($company);$year=$this->year($company,$year);
        $data=$request->validate(['type'=>'required|string|max:40','journal_id'=>'required|uuid','entry_date'=>'required|date_format:Y-m-d','description'=>'required|string|max:500','reference'=>'nullable|string|max:200','idempotency_key'=>'nullable|uuid','amount'=>'required|string|max:40','cash_account_id'=>'required|uuid','other_account_id'=>'required|uuid']);
        $guided->draft($data['type'],$data+['company_id'=>$company->id,'fiscal_year_id'=>$year->id],$request->user()->tenant_id,(string)$request->user()->id);
        return back()->with('success','Opération préparée en brouillon. Aucun taux fiscal n’a été ajouté automatiquement.');
    }
    public function post(Request $request,string $entry,LedgerService $ledger) {
        $this->writers($request);$entry=Entry::findOrFail($entry);
        $ledger->post((string)$entry->id,$request->user()->tenant_id,(string)$request->user()->id);
        return back()->with('success','Écriture comptabilisée et verrouillée.');
    }
    public function delete(Request $request,string $entry,LedgerService $ledger) {
        $this->writers($request);$entry=Entry::findOrFail($entry);
        abort_if($entry->attachments()->exists(),409,'Ce brouillon possède des pièces archivées : conservez-le et demandez sa revue.');
        $ledger->deleteDraft((string)$entry->id,$request->user()->tenant_id,(string)$request->user()->id);
        return back()->with('success','Brouillon supprimé ; sa trace reste dans l’audit.');
    }
    public function reverse(Request $request,string $entry,LedgerService $ledger) {
        $this->writers($request);$entry=Entry::findOrFail($entry);
        $data=$request->validate(['entry_date'=>'required|date_format:Y-m-d','reason'=>'required|string|min:5|max:350']);
        $ledger->reverse((string)$entry->id,$request->user()->tenant_id,(string)$request->user()->id,$data['entry_date'],$data['reason']);
        return back()->with('success','Correction négative préparée en brouillon. L’écriture d’origine est conservée.');
    }
    public function reports(Request $request,string $company,string $year,LedgerService $ledger) {
        $company=$this->company($company);$year=$this->year($company,$year);
        $kind=$request->query('kind','balance');$tenant=$request->user()->tenant_id;$actor=(string)$request->user()->id;
        $report=match($kind) {'balance'=>$ledger->trialBalance($company->id,$year->id,$tenant,$actor),'ledger'=>$ledger->generalLedger($company->id,$year->id,$tenant,$actor),'cash'=>$ledger->cashBook($company->id,$year->id,$tenant,$actor),default=>abort(422)};
        return view('reports',compact('company','year','kind','report'));
    }
}
