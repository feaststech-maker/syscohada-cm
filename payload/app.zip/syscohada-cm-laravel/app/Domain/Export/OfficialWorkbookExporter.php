<?php
declare(strict_types=1);
namespace App\Domain\Export;

use App\Domain\Import\SafeXlsx;
use Brick\Math\BigDecimal;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

/** Manifest and readiness MUST be loaded server-side after authorization, never accepted from an HTTP body. */
final class OfficialWorkbookExporter
{
    public static function requiredControls(string $system): array
    {
        if(!in_array($system,['NORMAL','SMT'],true))throw new \InvalidArgumentException('Système comptable invalide.');
        return ['IMPORT_VALIDATED','CLOSING_BALANCE_BALANCED','MAPPING_COMPLETE','ASSETS_EQUAL_LIABILITIES','RESULT_RECONCILED',$system==='SMT'?'SMT_CASH_RECONCILED':'CASH_FLOW_RECONCILED','ANNEXES_REVIEWED','TAX_REVIEWED','REVIEWER_APPROVED'];
    }
    public static function snapshotHash(array $values): string
    {
        ksort($values,SORT_STRING);$canonical='';
        foreach($values as $key=>$value){if(!is_string($key)||!is_array($value)||!is_string($value['kind']??null)||!is_string($value['value']??null))throw new \InvalidArgumentException('Valeur typée requise.');$text=$value['kind'].':'.$value['value'];$canonical.=strlen($key).':'.$key.strlen($text).':'.$text."\n";}
        return hash('sha256',$canonical);
    }
    public function export(string $templateBytes,array $manifest,array $values,array $readiness): array
    {
        if(($manifest['status']??null)!=='APPROVED_OFFICIAL')throw new \InvalidArgumentException('Canevas officiel non qualifié : export bloqué.');
        $approval=$manifest['approval']??[];$url=parse_url($approval['officialSourceUrl']??'');$host=strtolower($url['host']??'');
        if(empty($approval['approvedBy'])||empty($approval['approvedAt'])||empty($approval['acceptanceEvidenceReference'])||($url['scheme']??null)!=='https'||isset($url['user'])||!($host==='impots.cm'||str_ends_with($host,'.impots.cm')))throw new \InvalidArgumentException('Preuves de qualification et source officielle DGI requises.');
        $filename=$manifest['canonicalUploadFilename']??'';
        if(!preg_match('/^[A-Za-z0-9][A-Za-z0-9_. -]{0,180}\.xlsx$/D',$filename)||str_contains($filename,'..'))throw new \InvalidArgumentException('Nom canonique du fichier DGI non qualifié.');
        if(($manifest['fiscalYear']??null)!==($readiness['fiscalYear']??null)||($manifest['system']??null)!==($readiness['system']??null))throw new \InvalidArgumentException('Canevas incompatible avec la période ou le système.');
        if(array_diff(self::requiredControls($manifest['system']),$readiness['passedControls']??[]))throw new \InvalidArgumentException('Contrôles comptables et visas incomplets.');
        if(!hash_equals(self::snapshotHash($values),(string)($readiness['generationSnapshotHash']??'')))throw new \InvalidArgumentException('Données modifiées depuis la revue.');
        if(!preg_match('/^[a-f0-9]{64}$/iD',$manifest['sha256']??'')||!hash_equals(strtolower($manifest['sha256']),hash('sha256',$templateBytes)))throw new \InvalidArgumentException('Empreinte du canevas différente du registre.');
        $bindings=$manifest['bindings']??[];
        if(!$bindings || array_diff(array_keys($values),array_keys($bindings)))throw new \InvalidArgumentException('Mapping absent ou champ inconnu.');
        SafeXlsx::inspect($templateBytes,false);
        $input=tempnam(sys_get_temp_dir(),'dsf-model-');$output=tempnam(sys_get_temp_dir(),'dsf-export-');
        if($input===false||$output===false)throw new \RuntimeException('Stockage temporaire indisponible.');
        chmod($input,0600);chmod($output,0600);file_put_contents($input,$templateBytes);$book=null;
        try {
            $reader=IOFactory::createReader('Xlsx');$reader->setReadDataOnly(false);$book=$reader->load($input);
            if($book->getSheetNames()!==($manifest['sheets']??[])||count(array_unique($manifest['sheets']))!==count($manifest['sheets']))throw new \InvalidArgumentException('Noms ou ordre des feuilles différents du modèle.');
            $targets=[];
            foreach($bindings as $key=>$binding){$sheet=$book->getSheetByName($binding['sheet']??'');$coordinate=$binding['cell']??'';
                if(!$sheet||!preg_match('/^[A-Z]{1,3}[1-9][0-9]{0,6}$/D',$coordinate))throw new \InvalidArgumentException('Coordonnée de mapping invalide.');
                [$column,$row]=Coordinate::coordinateFromString($coordinate);if(Coordinate::columnIndexFromString($column)>16384||$row>1048576)throw new \InvalidArgumentException('Coordonnée hors limites XLSX.');
                $target=$binding['sheet'].'!'.$coordinate;if(isset($targets[$target]))throw new \InvalidArgumentException('Cellule cible dupliquée.');$targets[$target]=true;
                if(!$sheet->cellExists($coordinate))throw new \InvalidArgumentException('Cellule physique absente du canevas.');$cell=$sheet->getCell($coordinate);
                if($cell->getDataType()===DataType::TYPE_FORMULA)throw new \InvalidArgumentException('Écrasement de formule interdit.');
                $expected=$binding['expectedTemplateType']??null;$expected=match($expected){'NUMERIC'=>'n','STRING'=>'s','BLANK'=>'null',default=>$expected};
                if(!is_string($expected)||$cell->getDataType()!==$expected)throw new \InvalidArgumentException('Type de cellule différent du mapping.');
                foreach($sheet->getMergeCells() as $range){if($cell->isInRange($range)&&explode(':',$range)[0]!==$coordinate)throw new \InvalidArgumentException('Cellule fusionnée secondaire interdite.');}
                if(!array_key_exists($key,$values)){if($binding['required']??false)throw new \InvalidArgumentException('Champ obligatoire absent.');continue;}
                $value=$values[$key];$kind=$binding['valueKind']??null;if(($value['kind']??null)!==$kind||!is_string($value['value']??null))throw new \InvalidArgumentException('Type de valeur incompatible.');$text=$value['value'];
                if($kind==='DECIMAL'){$decimal=BigDecimal::of($text);$canonical=$decimal->strippedOfTrailingZeros();$digits=strlen(ltrim((string)$canonical->getUnscaledValue(),'-'));if($digits>15||$digits-$canonical->getScale()>15)throw new \InvalidArgumentException('Montant dépassant la précision Excel de 15 chiffres.');$cell->setValueExplicit((string)$decimal,DataType::TYPE_NUMERIC);if(!BigDecimal::of((string)$cell->getValue())->isEqualTo($decimal))throw new \InvalidArgumentException('Conversion numérique Excel non exacte : utilisez une valeur compatible.');}
                elseif($kind==='TEXT'){if(mb_strlen($text)>($binding['maxTextLength']??500)||preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f]/',$text)||preg_match('/^[=+\-@]/u',ltrim($text)))throw new \InvalidArgumentException('Texte de cellule invalide.');$cell->setValueExplicit($text,DataType::TYPE_STRING);}
                elseif($kind==='DATE'){$date=\DateTimeImmutable::createFromFormat('!Y-m-d',$text,new \DateTimeZone('UTC'));if(!$date||$date->format('Y-m-d')!==$text||$text<'1900-01-01'||$text>'9999-12-31')throw new \InvalidArgumentException('Date invalide.');$cell->setValueExplicit(Date::PHPToExcel($date),DataType::TYPE_NUMERIC);}
                else throw new \InvalidArgumentException('Type de valeur inconnu.');
            }
            // Only a closed list of pure formula functions can run. No external IO/INDIRECT/OFFSET.
            $formulaCount=0;
            foreach($book->getDefinedNames() as $defined)$this->safeFormula($defined->getValue());
            foreach($book->getAllSheets() as $sheet)foreach($sheet->getCellCollection()->getCoordinates() as $coordinate){$cell=$sheet->getCell($coordinate);if($cell->getDataType()===DataType::TYPE_FORMULA){if(++$formulaCount>25000)throw new \InvalidArgumentException('Trop de formules.');$this->safeFormula((string)$cell->getValue());}}
            foreach($book->getAllSheets() as $sheet)foreach($sheet->getCellCollection()->getCoordinates() as $coordinate){$cell=$sheet->getCell($coordinate);if($cell->getDataType()===DataType::TYPE_FORMULA){$result=$cell->getCalculatedValue();if(is_array($result)||is_object($result)||(is_float($result)&&!is_finite($result))||(is_string($result)&&str_starts_with($result,'#')))throw new \InvalidArgumentException('Formule non prise en charge ou en erreur : export bloqué.');}}
            $writer=new Xlsx($book);$writer->setPreCalculateFormulas(true);$writer->save($output);$bytes=file_get_contents($output);
            if($bytes===false)throw new \RuntimeException('Génération Excel impossible.');
            return ['bytes'=>$bytes,'filename'=>$filename,'sha256'=>hash('sha256',$bytes),'templateId'=>$manifest['templateId']??null,'templateVersion'=>$manifest['version']??null,'sourceTemplateSha256'=>$manifest['sha256'],'generationSnapshotSha256'=>$readiness['generationSnapshotHash']];
        } finally {$book?->disconnectWorksheets();@unlink($input);@unlink($output);}
    }
    private function safeFormula(string $formula): void
    {
        if(strlen($formula)>2048||str_contains($formula,'[')||str_contains($formula,']')||preg_match('~https?://|file://|\\\\|\|~i',$formula))throw new \InvalidArgumentException('Formule non qualifiée.');
        preg_match_all('/\b([A-Z_][A-Z0-9_.]*)\s*\(/i',$formula,$matches);
        foreach($matches[1] as $fn)if(!in_array(strtoupper($fn),['SUM','IF','IFERROR','ROUND','ROUNDDOWN','ROUNDUP','MIN','MAX','ABS','AND','OR','COUNT','COUNTA','SUMIF','SUMIFS','COUNTIF','COUNTIFS','NOT'],true))throw new \InvalidArgumentException('Fonction de formule non qualifiée.');
    }
}
