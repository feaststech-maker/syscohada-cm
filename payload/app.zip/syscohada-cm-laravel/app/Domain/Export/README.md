# Import, export et fiscalité — port PHP

## Contrats d’intégration

`TrialBalanceImporter::preview(string $bytes, string $filename, array $options): array` est un aperçu sans persistance. Options : `headerRow` (1–20, index 1), `sheetName` facultatif, `delimiter` facultatif (`;`, `,`, tabulation), `numberStyle` (`FR` ou `EN`), `convention` (`CLOSING_BALANCE` ou `PERIOD_MOVEMENTS`), `columns` (ACCOUNT/LABEL/DEBIT/CREDIT, index zéro) et `allowedClasses` (chaînes, défaut 1–8). Le résultat contient les suggestions explicables, cinq lignes source, le mapping, les lignes et totaux exacts sous forme de chaînes, les anomalies par ligne et `validForImport`.

L’importeur CSV comprend les champs entre guillemets et les sauts de ligne. L’importeur XLSX inspecte les parties OOXML avec des limites avant de lire les valeurs numériques **brutes** XML ; aucune conversion en flottant n’intervient dans les soldes importés. Les cellules numériques Excel dépassant la précision fiable de 15 chiffres sont refusées, les numéros de comptes numériques sont signalés pour vérifier les zéros initiaux. Macros, formules, liens externes, entités XML, dépassements et archives excessives sont refusés. Limites : 8 Mio, 25 000 lignes de données, 128 colonnes. Les comptes dupliqués bloquent une validation silencieuse ; les mouvements exigent les ouvertures pour produire une clôture.

`OfficialWorkbookExporter::export($templateBytes, $manifest, $values, $readiness): array` reçoit exclusivement un registre et une revue chargés **côté serveur** après contrôle des droits. Aucun contrôleur ne doit accepter leurs statuts ou contrôles depuis le client. Chaque valeur est un tableau `['kind' => 'DECIMAL'|'TEXT'|'DATE', 'value' => 'chaîne']`. Le manifeste comporte notamment `status=APPROVED_OFFICIAL`, hash SHA-256 du canevas, feuilles exactes, `canonicalUploadFilename`, exercice, système, approbation avec source HTTPS DGI et preuve de recette, puis `bindings` champ→feuille/cellule/type attendu/obligation. Les types physiques PhpSpreadsheet sont `n`, `s`, `null`; les noms historiques `NUMERIC`, `STRING`, `BLANK` sont également reconnus.

La revue contient `fiscalYear`, `system`, `passedControls` et `generationSnapshotHash`. Les contrôles requis sont retournés par `requiredControls($system)` ; le SMT a son contrôle de trésorerie propre. Le hash des valeurs typées est calculé par `snapshotHash`. Une génération retourne `bytes`, `filename`, `sha256` et les versions/empreintes de provenance.

## Restrictions Excel et qualification

L’exporteur charge un **classeur physique existant** avec PhpSpreadsheet, sans créer des cellules cibles absentes ou supprimer/recréer des feuilles. Il refuse les collisions, écrasements de formules, types inattendus et cibles fusionnées secondaires. L’export numérique est limité à 15 chiffres significatifs et vérifie le passage final au format numérique de la bibliothèque. Les calculs métier demeurent décimaux exacts ; Excel et les caches de ses formules utilisent leur représentation numérique propre.

Les formules du modèle approuvé sont contrôlées avant tout calcul : liste fermée de fonctions pures, pas de WEBSERVICE/HYPERLINK/INDIRECT/OFFSET, pas de référence externe et nombre/taille limités. Les caches sont recalculés ; formule inconnue ou en erreur = blocage. Ce filtre est volontairement restrictif : un modèle contenant d’autres formules nécessite une qualification supplémentaire, jamais une désactivation silencieuse du filtre.

Une réécriture OOXML par PhpSpreadsheet peut modifier certains éléments techniques non couverts par les tests. Les tests vérifient une **fixture explicitement NON OFFICIELLE**, les formules, cellules fusionnées et styles. Ils ne prouvent pas l’acceptation DGI. Les canevas publics 2021 hérités du projet restent `UNVERIFIED` ; aucun export de campagne actif ou recette DGI n’est livré.

## Fiscalité

`TaxReconciliation::compute` est un noyau générique `BigDecimal`, avec paramètres approuvés et datés : résultat avant impôt + réintégrations − déductions, arrondi de l’assiette, comparaison IS/minimum, CAC et crédits admissibles distincts. Il ne détermine pas l’éligibilité, le régime fiscal, les reports, les plafonds sectoriels ou la base du minimum de perception. La base MP est une entrée déjà qualifiée (notamment exercice de référence, arrondi et secteur). Aucun taux de production actif n’est embarqué ; les taux utilisés dans les tests sont uniquement des fixtures.

## Stockage temporaire

ZipArchive et PhpSpreadsheet nécessitent des fichiers temporaires physiques. Ils sont créés en mode `0600`, supprimés dans un `finally`, sans extraction des chemins d’archive. Pour les fichiers comptables, **`TMPDIR` du processus doit viser un tmpfs privé ou un volume chiffré**, avec quotas et nettoyage des éventuels résidus après arrêt brutal. Cette configuration doit précéder le démarrage PHP-FPM/worker ; elle ne se déduit pas d’un succès des tests locaux.
