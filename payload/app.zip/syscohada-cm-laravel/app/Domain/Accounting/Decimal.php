<?php

declare(strict_types=1);

namespace App\Domain\Accounting;

use Brick\Math\BigDecimal;
use Brick\Math\RoundingMode;

/** Decimal strings are the boundary contract; never accept a JSON/PHP float. */
final class Decimal
{
    public const ZERO = '0.000000';

    public static function amount(mixed $value, bool $signed = false): string
    {
        if (! is_string($value) && ! is_int($value)) {
            throw new AccountingException('DECIMAL_REQUIRED', 'Le montant doit être une chaîne décimale exacte.');
        }
        $text = trim((string) $value);
        $pattern = $signed ? '/^-?\d+(?:\.\d{1,6})?$/D' : '/^\d+(?:\.\d{1,6})?$/D';
        if (! preg_match($pattern, $text) || strlen($text) > 100) {
            throw new AccountingException('DECIMAL_INVALID', 'Montant décimal invalide : six décimales au maximum, sans séparateur de milliers.');
        }
        $number = BigDecimal::of($text)->toScale(6, RoundingMode::UNNECESSARY);
        if ($number->abs()->isGreaterThan('9999999999999999999999.999999')) {
            throw new AccountingException('DECIMAL_LIMIT', 'Montant hors capacité comptable.');
        }

        return (string) $number;
    }

    public static function add(string $a, string $b): string
    {
        return (string) BigDecimal::of($a)->plus($b)->toScale(6, RoundingMode::UNNECESSARY);
    }

    public static function sub(string $a, string $b): string
    {
        return (string) BigDecimal::of($a)->minus($b)->toScale(6, RoundingMode::UNNECESSARY);
    }

    public static function negate(string $value): string
    {
        return (string) BigDecimal::of($value)->negated()->toScale(6, RoundingMode::UNNECESSARY);
    }

    public static function compare(string $a, string $b = self::ZERO): int
    {
        return BigDecimal::of($a)->compareTo($b);
    }
}
