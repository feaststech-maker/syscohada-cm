<?php

declare(strict_types=1);

namespace App\Domain\Accounting;

/** Paid operations only. No VAT, income-tax or official-chart assumptions are inserted. */
final class GuidedEntryService
{
    public const TYPES = ['CASH_SALE', 'CASH_EXPENSE', 'CUSTOMER_RECEIPT', 'SUPPLIER_PAYMENT', 'BANK_TRANSFER', 'OWNER_CONTRIBUTION'];

    public function __construct(private readonly LedgerService $ledger) {}

    public function draft(string $type, array $data, string $tenantId, string $actorId): string
    {
        if (! in_array($type, self::TYPES, true)) {
            throw new AccountingException('OPERATION_TYPE', 'Type d’opération guidée inconnu.');
        }
        $amount = Decimal::amount($data['amount'] ?? null);
        if (Decimal::compare($amount) <= 0) {
            throw new AccountingException('POSITIVE_AMOUNT', 'Le montant de l’opération doit être positif.');
        }
        $cash = $data['cash_account_id'] ?? '';
        $other = $data['other_account_id'] ?? '';
        if (! is_string($cash) || ! is_string($other) || $cash === $other) {
            throw new AccountingException('ACCOUNT_PAIR', 'Sélectionnez deux comptes distincts.');
        }
        $cashIn = in_array($type, ['CASH_SALE', 'CUSTOMER_RECEIPT', 'OWNER_CONTRIBUTION'], true);
        $data['lines'] = [
            ['account_id' => $cash, 'debit' => $cashIn ? $amount : Decimal::ZERO, 'credit' => $cashIn ? Decimal::ZERO : $amount],
            ['account_id' => $other, 'debit' => $cashIn ? Decimal::ZERO : $amount, 'credit' => $cashIn ? $amount : Decimal::ZERO],
        ];
        $data['guided_type'] = $type;

        return $this->ledger->draft($data, $tenantId, $actorId);
    }
}
