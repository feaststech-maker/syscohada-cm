<?php

declare(strict_types=1);

namespace App\Domain\Accounting;

use DateTimeImmutable;
use Illuminate\Database\Query\Builder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

/**
 * Application ledger boundary. Every identifier is scoped to tenant AND company.
 * PostgreSQL additionally enforces the same invariants with FORCE RLS and triggers.
 */
final class LedgerService
{
    private string $auditRequestId = '';

    public function draft(array $data, string $tenantId, string $actorId): string
    {
        return $this->transaction($tenantId, $actorId, ['TENANT_ADMIN', 'ACCOUNTANT'], function () use ($data, $tenantId, $actorId): string {
            $normal = $this->normaliseDraft($data);
            $company = $this->company($normal['company_id'], $tenantId, true);
            $this->requireEnabled($company);
            $year = $this->year($normal['fiscal_year_id'], $company->id, $tenantId, true);
            $this->requireOpenDate($year, $normal['entry_date']);
            $journal = $this->journal($normal['journal_id'], $company->id, $tenantId);
            $accounts = $this->validateAccounts($normal['lines'], $company->id, $tenantId, false);
            if (isset($data['guided_type'])) {
                $this->validateGuided($data, $accounts, $journal);
            }
            if ($normal['idempotency_key'] !== null) {
                $existing = DB::table('entries')->where('tenant_id', $tenantId)->where('company_id', $company->id)
                    ->where('idempotency_key', $normal['idempotency_key'])->lockForUpdate()->first();
                if ($existing !== null) {
                    if (! $this->sameDraft($existing, $normal, $tenantId)) {
                        throw new AccountingException('IDEMPOTENCY_CONFLICT', 'Cette clé a déjà servi pour une opération différente.', 409);
                    }

                    return $existing->id;
                }
            }

            return $this->insertDraft($normal, $tenantId, $actorId);
        });
    }

    public function updateDraft(string $entryId, array $data, string $tenantId, string $actorId): string
    {
        return $this->transaction($tenantId, $actorId, ['TENANT_ADMIN', 'ACCOUNTANT'], function () use ($entryId, $data, $tenantId, $actorId): string {
            $first = $this->entry($entryId, $tenantId);
            $company = $this->company($first->company_id, $tenantId, true);
            $this->requireEnabled($company);
            $entry = $this->entry($entryId, $tenantId, true);
            if ($entry->status !== 'DRAFT' || $entry->reversal_of !== null) {
                throw new AccountingException('IMMUTABLE_ENTRY', 'Seul un brouillon ordinaire peut être modifié.', 409);
            }
            $normal = $this->normaliseDraft($data + [
                'company_id' => $entry->company_id, 'fiscal_year_id' => $entry->fiscal_year_id,
                'journal_id' => $entry->journal_id, 'entry_date' => $entry->entry_date,
                'description' => $entry->description, 'reference' => $entry->reference,
                'idempotency_key' => $entry->idempotency_key,
            ]);
            if ($normal['company_id'] !== $entry->company_id || $normal['fiscal_year_id'] !== $entry->fiscal_year_id
                || $normal['idempotency_key'] !== $entry->idempotency_key) {
                throw new AccountingException('DRAFT_SCOPE_IMMUTABLE', 'Entreprise, exercice et clé d’opération ne peuvent pas être réaffectés.', 409);
            }
            $year = $this->year($entry->fiscal_year_id, $company->id, $tenantId, true);
            $this->requireOpenDate($year, $normal['entry_date']);
            $journal = $this->journal($normal['journal_id'], $company->id, $tenantId);
            $accounts = $this->validateAccounts($normal['lines'], $company->id, $tenantId, false);
            if (isset($data['guided_type'])) {
                $this->validateGuided($data, $accounts, $journal);
            }
            $changes = array_intersect_key($normal, array_flip(['journal_id', 'entry_date', 'description', 'reference']));
            $changes['updated_at'] = now();
            DB::table('entries')->where('tenant_id', $tenantId)->where('id', $entryId)->update($changes);
            $this->audit('entries', 'UPDATE', $entryId, (array) $entry, array_merge((array) $entry, $changes), $tenantId, $actorId);
            foreach ($this->lines($entryId, $tenantId) as $line) {
                DB::table('entry_lines')->where('tenant_id', $tenantId)->where('id', $line->id)->delete();
                $this->audit('entry_lines', 'DELETE', $line->id, (array) $line, null, $tenantId, $actorId);
            }
            $this->insertLines($entryId, $company->id, $normal['lines'], $tenantId, $actorId);

            return $entryId;
        });
    }

    /** Repeated confirmation returns the existing posting and does not consume a number. */
    public function post(string $entryId, string $tenantId, string $actorId): array
    {
        return $this->transaction($tenantId, $actorId, ['TENANT_ADMIN', 'ACCOUNTANT'], function () use ($entryId, $tenantId, $actorId): array {
            $first = $this->entry($entryId, $tenantId);
            $company = $this->company($first->company_id, $tenantId, true);
            $this->requireEnabled($company);
            $entry = $this->entry($entryId, $tenantId, true);
            if ($entry->status === 'POSTED') {
                return $this->postingResult($entry, $this->lines($entryId, $tenantId));
            }
            if ($entry->status !== 'DRAFT') {
                throw new AccountingException('ENTRY_STATUS', 'État de l’écriture incompatible avec une validation.');
            }
            $year = $this->year($entry->fiscal_year_id, $company->id, $tenantId, true);
            $this->requireOpenDate($year, $entry->entry_date);
            if (($entry->reference === null || trim($entry->reference) === '')
                && ! DB::table('attachments')->where('tenant_id', $tenantId)->where('company_id', $company->id)
                    ->whereIn('entry_id', array_filter([$entry->id, $entry->reversal_of]))->exists()) {
                throw new AccountingException('SUPPORTING_DOCUMENT_REQUIRED', 'Indiquez la référence d’une pièce justificative ou joignez la pièce avant de comptabiliser.');
            }
            $journal = $this->journal($entry->journal_id, $company->id, $tenantId, true);
            $lines = $this->lines($entryId, $tenantId, true);
            if (count($lines) < 2) {
                throw new AccountingException('TWO_LINES_REQUIRED', 'Deux lignes au minimum sont nécessaires pour comptabiliser.');
            }
            $debit = Decimal::ZERO;
            $credit = Decimal::ZERO;
            foreach ($lines as $line) {
                $d = Decimal::amount($line->debit, $entry->reversal_of !== null);
                $c = Decimal::amount($line->credit, $entry->reversal_of !== null);
                $this->requireOneSide($d, $c);
                $debit = Decimal::add($debit, $d);
                $credit = Decimal::add($credit, $c);
            }
            if (Decimal::compare($debit, $credit) !== 0 || Decimal::compare($debit) === 0) {
                throw new AccountingException('UNBALANCED', 'La comptabilisation exige une égalité débit / crédit non nulle.');
            }
            $this->validateAccounts(array_map(fn ($line) => (array) $line, $lines), $company->id, $tenantId, false);
            if ($entry->reversal_of !== null) {
                $this->requireExactCorrection($entry, $lines, $tenantId);
            }
            $next = (int) $journal->next_number;
            if ($next < 1 || $next >= PHP_INT_MAX) {
                throw new AccountingException('NUMBER_SEQUENCE', 'Séquence de journal invalide.');
            }
            $number = $journal->code.'/'.substr($year->starts_on, 0, 4).'/'.str_pad((string) $next, 6, '0', STR_PAD_LEFT);
            $journalChanges = ['next_number' => $next + 1, 'updated_at' => now()];
            DB::table('journals')->where('tenant_id', $tenantId)->where('company_id', $company->id)->where('id', $journal->id)->update($journalChanges);
            $this->audit('journals', 'UPDATE', $journal->id, (array) $journal, array_merge((array) $journal, $journalChanges), $tenantId, $actorId);
            $changes = ['status' => 'POSTED', 'number' => $number, 'posted_by' => $actorId, 'posted_at' => now(), 'updated_at' => now()];
            DB::table('entries')->where('tenant_id', $tenantId)->where('company_id', $company->id)->where('id', $entryId)->update($changes);
            $this->audit('entries', 'UPDATE', $entryId, (array) $entry, array_merge((array) $entry, $changes), $tenantId, $actorId);

            return $this->postingResult((object) array_merge((array) $entry, $changes), $lines);
        });
    }

    /** Creates a negative correction DRAFT. A separate post() confirms its final accounting entry. */
    public function reverse(string $entryId, string $tenantId, string $actorId, string $date, string $reason): string
    {
        return $this->transaction($tenantId, $actorId, ['TENANT_ADMIN', 'ACCOUNTANT'], function () use ($entryId, $tenantId, $actorId, $date, $reason): string {
            $first = $this->entry($entryId, $tenantId);
            $company = $this->company($first->company_id, $tenantId, true);
            $this->requireEnabled($company);
            $entry = $this->entry($entryId, $tenantId, true);
            if ($entry->status !== 'POSTED' || $entry->reversal_of !== null) {
                throw new AccountingException('REVERSAL_SOURCE', 'La correction exige une écriture ordinaire déjà comptabilisée.');
            }
            if (trim($reason) === '' || mb_strlen($reason) > 350) {
                throw new AccountingException('REVERSAL_REASON', 'Un motif de correction explicite est obligatoire.');
            }
            $this->requireDate($date);
            $year = $this->year($entry->fiscal_year_id, $company->id, $tenantId, true);
            $this->requireOpenDate($year, $date);
            if (DB::table('entries')->where('tenant_id', $tenantId)->where('company_id', $company->id)->where('reversal_of', $entryId)->exists()) {
                throw new AccountingException('ALREADY_REVERSED', 'Une correction existe déjà pour cette écriture.', 409);
            }
            $lines = [];
            foreach ($this->lines($entryId, $tenantId) as $line) {
                $lines[] = [
                    'account_id' => $line->account_id, 'label' => $line->label,
                    'debit' => Decimal::negate((string) $line->debit), 'credit' => Decimal::negate((string) $line->credit),
                ];
            }

            return $this->insertDraft([
                'company_id' => $company->id, 'fiscal_year_id' => $entry->fiscal_year_id, 'journal_id' => $entry->journal_id,
                'entry_date' => $date, 'description' => 'Correction '.$entry->number.' — '.trim($reason),
                'reference' => $entry->reference, 'idempotency_key' => null, 'lines' => $lines,
            ], $tenantId, $actorId, $entryId);
        });
    }

    public function deleteDraft(string $entryId, string $tenantId, string $actorId): void
    {
        $this->transaction($tenantId, $actorId, ['TENANT_ADMIN', 'ACCOUNTANT'], function () use ($entryId, $tenantId, $actorId): void {
            $first = $this->entry($entryId, $tenantId);
            $company = $this->company($first->company_id, $tenantId, true);
            $this->requireEnabled($company);
            $entry = $this->entry($entryId, $tenantId, true);
            if ($entry->status !== 'DRAFT') {
                throw new AccountingException('IMMUTABLE_ENTRY', 'Une écriture comptabilisée ne peut pas être supprimée.', 409);
            }
            if (DB::table('attachments')->where('tenant_id', $tenantId)->where('company_id', $company->id)->where('entry_id', $entryId)->exists()) {
                throw new AccountingException('ATTACHED_DOCUMENT', 'Conservez ce brouillon : une pièce archivée lui est attachée.', 409);
            }
            $year = $this->year($entry->fiscal_year_id, $company->id, $tenantId, true);
            $this->requireOpenDate($year, $entry->entry_date);
            foreach ($this->lines($entryId, $tenantId) as $line) {
                DB::table('entry_lines')->where('tenant_id', $tenantId)->where('id', $line->id)->delete();
                $this->audit('entry_lines', 'DELETE', $line->id, (array) $line, null, $tenantId, $actorId);
            }
            DB::table('entries')->where('tenant_id', $tenantId)->where('id', $entryId)->delete();
            $this->audit('entries', 'DELETE', $entryId, (array) $entry, null, $tenantId, $actorId);
        });
    }

    public function trialBalance(string $companyId, string $yearId, string $tenantId, string $actorId): array
    {
        return $this->transaction($tenantId, $actorId, $this->readRoles(), function () use ($companyId, $yearId, $tenantId): array {
            $this->company($companyId, $tenantId);
            $this->year($yearId, $companyId, $tenantId);
            $query = $this->reportQuery($companyId, $yearId, $tenantId);
            $grouped = [];
            if (DB::getDriverName() === 'pgsql') {
                $rows = $query->select('accounts.id as account_id', 'accounts.code', 'accounts.name')
                    ->selectRaw('SUM(entry_lines.debit)::text AS debit, SUM(entry_lines.credit)::text AS credit')
                    ->groupBy('accounts.id', 'accounts.code', 'accounts.name')->orderBy('accounts.code')->get();
                foreach ($rows as $row) {
                    $grouped[$row->account_id] = [
                        'account_id' => $row->account_id, 'code' => $row->code, 'name' => $row->name,
                        // An aggregate may legitimately exceed the capacity of one stored line.
                        'debit' => Decimal::add(Decimal::ZERO, (string) $row->debit), 'credit' => Decimal::add(Decimal::ZERO, (string) $row->credit),
                    ];
                }
            } else {
                // SQLite NUMERIC/SUM can lose decimal precision: migrations store TEXT and we sum strings.
                foreach ($query->select('accounts.id as account_id', 'accounts.code', 'accounts.name', 'entry_lines.debit', 'entry_lines.credit')->orderBy('accounts.code')->cursor() as $row) {
                    $grouped[$row->account_id] ??= ['account_id' => $row->account_id, 'code' => $row->code, 'name' => $row->name, 'debit' => Decimal::ZERO, 'credit' => Decimal::ZERO];
                    $grouped[$row->account_id]['debit'] = Decimal::add($grouped[$row->account_id]['debit'], (string) $row->debit);
                    $grouped[$row->account_id]['credit'] = Decimal::add($grouped[$row->account_id]['credit'], (string) $row->credit);
                }
            }
            $totalD = Decimal::ZERO;
            $totalC = Decimal::ZERO;
            foreach ($grouped as &$row) {
                $net = Decimal::sub($row['debit'], $row['credit']);
                $row['closing_debit'] = Decimal::compare($net) >= 0 ? $net : Decimal::ZERO;
                $row['closing_credit'] = Decimal::compare($net) < 0 ? Decimal::negate($net) : Decimal::ZERO;
                $totalD = Decimal::add($totalD, $row['debit']);
                $totalC = Decimal::add($totalC, $row['credit']);
            }
            unset($row);

            return ['rows' => array_values($grouped), 'total_debit' => $totalD, 'total_credit' => $totalC,
                'balanced' => Decimal::compare($totalD, $totalC) === 0, 'scope' => 'POSTED_ENTRIES_ONLY',
                'opening_notice' => 'Les ouvertures doivent être comptabilisées ; aucun solde N−1 n’est inventé.'];
        });
    }

    public function generalLedger(string $companyId, string $yearId, string $tenantId, string $actorId, ?string $accountId = null): array
    {
        return $this->transaction($tenantId, $actorId, $this->readRoles(), function () use ($companyId, $yearId, $tenantId, $accountId): array {
            $this->company($companyId, $tenantId);
            $this->year($yearId, $companyId, $tenantId);
            $query = $this->reportQuery($companyId, $yearId, $tenantId);
            if ($accountId !== null) {
                $this->validateAccounts([['account_id' => $accountId]], $companyId, $tenantId, true);
                $query->where('entry_lines.account_id', $accountId);
            }
            $rows = [];
            $running = [];
            $totalD = Decimal::ZERO;
            $totalC = Decimal::ZERO;
            foreach ($query->select('entries.id as entry_id', 'entries.entry_date', 'entries.number', 'entries.description', 'entries.reference',
                'accounts.id as account_id', 'accounts.code', 'accounts.name', 'entry_lines.debit', 'entry_lines.credit')
                ->orderBy('accounts.code')->orderBy('entries.entry_date')->orderBy('entries.number')->orderBy('entry_lines.sort_order')->cursor() as $row) {
                $d = Decimal::amount($row->debit, true);
                $c = Decimal::amount($row->credit, true);
                $running[$row->account_id] = Decimal::add($running[$row->account_id] ?? Decimal::ZERO, Decimal::sub($d, $c));
                $rows[] = array_merge((array) $row, ['debit' => $d, 'credit' => $c, 'running_balance' => $running[$row->account_id]]);
                $totalD = Decimal::add($totalD, $d);
                $totalC = Decimal::add($totalC, $c);
            }

            return ['rows' => $rows, 'total_debit' => $totalD, 'total_credit' => $totalC, 'scope' => 'POSTED_ENTRIES_ONLY'];
        });
    }

    public function cashBook(string $companyId, string $yearId, string $tenantId, string $actorId): array
    {
        return $this->transaction($tenantId, $actorId, $this->readRoles(), function () use ($companyId, $yearId, $tenantId): array {
            $this->company($companyId, $tenantId);
            $this->year($yearId, $companyId, $tenantId);
            $grouped = [];
            foreach ($this->reportQuery($companyId, $yearId, $tenantId)
                ->select('entries.id as entry_id', 'entries.entry_date', 'entries.number', 'entries.description', 'entries.reversal_of',
                    'entry_lines.account_id', 'entry_lines.debit', 'entry_lines.credit', 'accounts.is_cash')
                ->orderBy('entries.entry_date')->orderBy('entries.number')->orderBy('entry_lines.sort_order')->cursor() as $line) {
                $grouped[$line->entry_id] ??= ['entry_id' => $line->entry_id, 'entry_date' => $line->entry_date,
                    'number' => $line->number, 'description' => $line->description, 'net' => Decimal::ZERO,
                    'correction' => $line->reversal_of !== null,
                    '_cash' => [], '_noncash' => false];
                if ($this->truth($line->is_cash)) {
                    $grouped[$line->entry_id]['net'] = Decimal::add($grouped[$line->entry_id]['net'], Decimal::sub((string) $line->debit, (string) $line->credit));
                    $grouped[$line->entry_id]['_cash'][$line->account_id] = true;
                } else {
                    $grouped[$line->entry_id]['_noncash'] = true;
                }
            }
            $rows = [];
            $running = Decimal::ZERO;
            $inflows = Decimal::ZERO;
            $outflows = Decimal::ZERO;
            foreach ($grouped as $row) {
                if ($row['_cash'] === []) {
                    continue;
                }
                $row['internal_transfer'] = ! $row['_noncash'] && count($row['_cash']) > 1 && Decimal::compare($row['net']) === 0;
                if ($row['correction']) {
                    // A negative correction cancels the original category; it is not a new cash flow.
                    $row['inflow'] = Decimal::compare($row['net']) < 0 ? $row['net'] : Decimal::ZERO;
                    $row['outflow'] = Decimal::compare($row['net']) > 0 ? Decimal::negate($row['net']) : Decimal::ZERO;
                } else {
                    $row['inflow'] = Decimal::compare($row['net']) > 0 ? $row['net'] : Decimal::ZERO;
                    $row['outflow'] = Decimal::compare($row['net']) < 0 ? Decimal::negate($row['net']) : Decimal::ZERO;
                }
                $running = Decimal::add($running, $row['net']);
                $row['running_balance'] = $running;
                $inflows = Decimal::add($inflows, $row['inflow']);
                $outflows = Decimal::add($outflows, $row['outflow']);
                unset($row['_cash'], $row['_noncash']);
                $rows[] = $row;
            }

            return ['rows' => $rows, 'inflows' => $inflows, 'outflows' => $outflows,
                'net' => Decimal::sub($inflows, $outflows), 'balance' => $running,
                'scope' => 'POSTED_ENTRIES_ONLY', 'notice' => 'Journal de trésorerie ; ce rapport seul n’est pas le TFT complet.'];
        });
    }

    private function transaction(string $tenantId, string $actorId, array $roles, callable $callback): mixed
    {
        if (! Str::isUuid($tenantId) || ! Str::isUuid($actorId)) {
            throw new AccountingException('UNAUTHORISED', 'Contexte utilisateur invalide.', 403);
        }

        return DB::transaction(function () use ($tenantId, $actorId, $roles, $callback): mixed {
            $this->auditRequestId = (string) Str::uuid();
            if (DB::getDriverName() === 'pgsql') {
                DB::select("select set_config('app.tenant_id', ?, true), set_config('app.actor_id', ?, true), set_config('app.request_id', ?, true)", [$tenantId, $actorId, $this->auditRequestId]);
            }
            $actor = DB::table('users')->where('tenant_id', $tenantId)->where('id', $actorId)->first();
            if ($actor === null || ! $this->truth($actor->enabled) || ! in_array($actor->role, $roles, true)) {
                throw new AccountingException('UNAUTHORISED', 'Votre rôle ne permet pas cette opération.', 403);
            }

            return $callback();
        }, 3);
    }

    private function normaliseDraft(array $data): array
    {
        foreach (['company_id', 'fiscal_year_id', 'journal_id'] as $key) {
            if (! isset($data[$key]) || ! is_string($data[$key]) || ! Str::isUuid($data[$key])) {
                throw new AccountingException('IDENTIFIER_REQUIRED', 'Identifiant comptable obligatoire : '.$key);
            }
        }
        $date = $data['entry_date'] ?? null;
        if (! is_string($date)) {
            throw new AccountingException('DATE_REQUIRED', 'Date comptable obligatoire.');
        }
        $this->requireDate($date);
        $description = $this->text($data['description'] ?? null, 500, true);
        $reference = $this->text($data['reference'] ?? null, 200, false);
        $key = $data['idempotency_key'] ?? null;
        if ($key !== null && (! is_string($key) || ! preg_match('/^[A-Za-z0-9_-]{8,64}$/D', $key))) {
            throw new AccountingException('IDEMPOTENCY_KEY', 'Clé d’opération invalide.');
        }
        if (! isset($data['lines']) || ! is_array($data['lines']) || count($data['lines']) < 1 || count($data['lines']) > 200) {
            throw new AccountingException('LINES_REQUIRED', 'Le brouillon doit comporter entre une et 200 lignes.');
        }
        $lines = [];
        foreach (array_values($data['lines']) as $line) {
            if (! is_array($line) || ! isset($line['account_id']) || ! is_string($line['account_id']) || ! Str::isUuid($line['account_id'])) {
                throw new AccountingException('ACCOUNT_REQUIRED', 'Un compte valide est obligatoire pour chaque ligne.');
            }
            $d = Decimal::amount($line['debit'] ?? '0');
            $c = Decimal::amount($line['credit'] ?? '0');
            $this->requireOneSide($d, $c);
            $lines[] = ['account_id' => $line['account_id'], 'label' => $this->text($line['label'] ?? null, 500, false), 'debit' => $d, 'credit' => $c];
        }

        return ['company_id' => $data['company_id'], 'fiscal_year_id' => $data['fiscal_year_id'], 'journal_id' => $data['journal_id'],
            'entry_date' => $date, 'description' => $description, 'reference' => $reference, 'idempotency_key' => $key, 'lines' => $lines];
    }

    private function insertDraft(array $data, string $tenantId, string $actorId, ?string $reversalOf = null): string
    {
        $id = (string) Str::uuid();
        $row = array_intersect_key($data, array_flip(['company_id', 'fiscal_year_id', 'journal_id', 'entry_date', 'description', 'reference', 'idempotency_key']));
        $row += ['id' => $id, 'tenant_id' => $tenantId, 'status' => 'DRAFT', 'number' => null, 'created_by' => $actorId,
            'posted_by' => null, 'posted_at' => null, 'reversal_of' => $reversalOf, 'created_at' => now(), 'updated_at' => now()];
        DB::table('entries')->insert($row);
        $this->audit('entries', 'INSERT', $id, null, $row, $tenantId, $actorId);
        $this->insertLines($id, $data['company_id'], $data['lines'], $tenantId, $actorId);

        return $id;
    }

    private function insertLines(string $entryId, string $companyId, array $lines, string $tenantId, string $actorId): void
    {
        foreach (array_values($lines) as $index => $line) {
            $row = ['id' => (string) Str::uuid(), 'tenant_id' => $tenantId, 'company_id' => $companyId, 'entry_id' => $entryId,
                'account_id' => $line['account_id'], 'sort_order' => $index + 1, 'label' => $line['label'] ?? null,
                'debit' => $line['debit'], 'credit' => $line['credit'], 'created_at' => now(), 'updated_at' => now()];
            DB::table('entry_lines')->insert($row);
            $this->audit('entry_lines', 'INSERT', $row['id'], null, $row, $tenantId, $actorId);
        }
    }

    private function sameDraft(object $existing, array $normal, string $tenantId): bool
    {
        if ($existing->reversal_of !== null) {
            return false;
        }
        foreach (['company_id', 'fiscal_year_id', 'journal_id', 'entry_date', 'description', 'reference'] as $key) {
            if ($existing->{$key} !== $normal[$key]) {
                return false;
            }
        }
        $lines = $this->lines($existing->id, $tenantId);
        if (count($lines) !== count($normal['lines'])) {
            return false;
        }
        foreach ($lines as $index => $line) {
            $expected = $normal['lines'][$index];
            if ($line->account_id !== $expected['account_id'] || $line->label !== $expected['label']
                || Decimal::compare((string) $line->debit, $expected['debit']) !== 0
                || Decimal::compare((string) $line->credit, $expected['credit']) !== 0) {
                return false;
            }
        }

        return true;
    }

    private function company(string $id, string $tenantId, bool $lock = false): object
    {
        if (! Str::isUuid($id)) {
            throw new AccountingException('COMPANY_NOT_FOUND', 'Entreprise introuvable.', 404);
        }
        $query = DB::table('companies')->where('tenant_id', $tenantId)->where('id', $id);
        $row = ($lock ? $query->lockForUpdate() : $query)->first();
        if ($row === null) {
            throw new AccountingException('COMPANY_NOT_FOUND', 'Entreprise introuvable.', 404);
        }

        return $row;
    }

    private function year(string $id, string $companyId, string $tenantId, bool $lock = false): object
    {
        if (! Str::isUuid($id)) {
            throw new AccountingException('YEAR_NOT_FOUND', 'Exercice introuvable pour cette entreprise.', 404);
        }
        $query = DB::table('fiscal_years')->where('tenant_id', $tenantId)->where('company_id', $companyId)->where('id', $id);
        $row = ($lock ? $query->lockForUpdate() : $query)->first();
        if ($row === null) {
            throw new AccountingException('YEAR_NOT_FOUND', 'Exercice introuvable pour cette entreprise.', 404);
        }

        return $row;
    }

    private function journal(string $id, string $companyId, string $tenantId, bool $lock = false): object
    {
        if (! Str::isUuid($id)) {
            throw new AccountingException('JOURNAL_NOT_FOUND', 'Journal introuvable pour cette entreprise.', 404);
        }
        $query = DB::table('journals')->where('tenant_id', $tenantId)->where('company_id', $companyId)->where('id', $id);
        $row = ($lock ? $query->lockForUpdate() : $query)->first();
        if ($row === null) {
            throw new AccountingException('JOURNAL_NOT_FOUND', 'Journal introuvable pour cette entreprise.', 404);
        }

        return $row;
    }

    private function entry(string $id, string $tenantId, bool $lock = false): object
    {
        if (! Str::isUuid($id)) {
            throw new AccountingException('ENTRY_NOT_FOUND', 'Écriture introuvable.', 404);
        }
        $query = DB::table('entries')->where('tenant_id', $tenantId)->where('id', $id);
        $row = ($lock ? $query->lockForUpdate() : $query)->first();
        if ($row === null) {
            throw new AccountingException('ENTRY_NOT_FOUND', 'Écriture introuvable.', 404);
        }

        return $row;
    }

    private function lines(string $entryId, string $tenantId, bool $lock = false): array
    {
        $query = DB::table('entry_lines')->where('tenant_id', $tenantId)->where('entry_id', $entryId)->orderBy('sort_order');

        return ($lock ? $query->lockForUpdate() : $query)->get()->all();
    }

    private function validateAccounts(array $lines, string $companyId, string $tenantId, bool $allowInactive): array
    {
        $ids = array_values(array_unique(array_column($lines, 'account_id')));
        foreach ($ids as $id) {
            if (! is_string($id) || ! Str::isUuid($id)) {
                throw new AccountingException('ACCOUNT_SCOPE', 'Compte introuvable pour cette entreprise.');
            }
        }
        $accounts = DB::table('accounts')->where('tenant_id', $tenantId)->where('company_id', $companyId)
            ->whereIn('id', $ids)->orderBy('id')->get()->keyBy('id')->all();
        if (count($accounts) !== count($ids)) {
            throw new AccountingException('ACCOUNT_SCOPE', 'Un compte appartient à une autre entreprise ou est introuvable.');
        }
        foreach ($accounts as $account) {
            if (! $allowInactive && ! $this->truth($account->active)) {
                throw new AccountingException('ACCOUNT_INACTIVE', 'Un compte sélectionné est désactivé.');
            }
        }

        return $accounts;
    }

    private function validateGuided(array $data, array $accounts, object $journal): void
    {
        $type = $data['guided_type'];
        $cash = $accounts[$data['cash_account_id'] ?? ''] ?? null;
        $other = $accounts[$data['other_account_id'] ?? ''] ?? null;
        if (! in_array($type, GuidedEntryService::TYPES, true) || $cash === null || $other === null || ! $this->truth($cash->is_cash)
            || ! str_starts_with($cash->code, '5')
            || ! in_array($journal->kind, ['CASH', 'BANK', 'GENERAL'], true)) {
            throw new AccountingException('GUIDED_ACCOUNTS', 'Sélectionnez un compte de trésorerie et un journal compatibles.');
        }
        $valid = match ($type) {
            'CASH_SALE' => str_starts_with($other->code, '7'),
            'CASH_EXPENSE' => str_starts_with($other->code, '6') || str_starts_with($other->code, '8'),
            'CUSTOMER_RECEIPT' => str_starts_with($other->code, '41'),
            'SUPPLIER_PAYMENT' => str_starts_with($other->code, '40'),
            'OWNER_CONTRIBUTION' => str_starts_with($other->code, '10') || str_starts_with($other->code, '46'),
            'BANK_TRANSFER' => $this->truth($other->is_cash) && str_starts_with($other->code, '5'),
        };
        if (! $valid || ($type !== 'BANK_TRANSFER' && $this->truth($other->is_cash))) {
            throw new AccountingException('GUIDED_COUNTERPART', 'La contrepartie doit correspondre à la nature de l’opération.');
        }
    }

    private function requireExactCorrection(object $entry, array $lines, string $tenantId): void
    {
        $parent = $this->entry($entry->reversal_of, $tenantId, true);
        $original = $this->lines($parent->id, $tenantId);
        if ($parent->status !== 'POSTED' || $parent->reversal_of !== null || $parent->company_id !== $entry->company_id
            || $parent->fiscal_year_id !== $entry->fiscal_year_id || $parent->journal_id !== $entry->journal_id || count($original) !== count($lines)) {
            throw new AccountingException('CORRECTION_MISMATCH', 'Correction incompatible avec l’écriture initiale.');
        }
        foreach ($lines as $index => $line) {
            $initial = $original[$index];
            if ($line->account_id !== $initial->account_id || $line->sort_order !== $initial->sort_order
                || Decimal::compare((string) $line->debit, Decimal::negate((string) $initial->debit)) !== 0
                || Decimal::compare((string) $line->credit, Decimal::negate((string) $initial->credit)) !== 0) {
                throw new AccountingException('CORRECTION_MISMATCH', 'La correction doit reprendre les montants négatifs exacts de l’écriture initiale.');
            }
        }
    }

    private function requireOpenDate(object $year, string $date): void
    {
        if ($year->status !== 'OPEN') {
            throw new AccountingException('YEAR_CLOSED', 'L’exercice est clôturé. Aucune mutation comptable n’est autorisée.', 409);
        }
        if ($date < $year->starts_on || $date > $year->ends_on) {
            throw new AccountingException('DATE_OUTSIDE_YEAR', 'La date comptable est hors de l’exercice.');
        }
    }

    private function requireDate(string $date): void
    {
        $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
        if ($parsed === false || $parsed->format('Y-m-d') !== $date) {
            throw new AccountingException('DATE_INVALID', 'Date comptable invalide.');
        }
    }

    private function requireEnabled(object $company): void
    {
        if (! $this->truth($company->virtual_accounting_enabled)) {
            throw new AccountingException('MODULE_DISABLED', 'Activez l’option comptabilité virtuelle pour cette entreprise.', 403);
        }
    }

    private function requireOneSide(string $debit, string $credit): void
    {
        if ((Decimal::compare($debit) === 0) === (Decimal::compare($credit) === 0)) {
            throw new AccountingException('ONE_SIDE_REQUIRED', 'Chaque ligne porte un seul montant non nul : débit ou crédit.');
        }
    }

    private function text(mixed $value, int $max, bool $required): ?string
    {
        if ($value === null && ! $required) {
            return null;
        }
        if (! is_string($value) || mb_strlen(trim($value)) > $max || ($required && trim($value) === '')) {
            throw new AccountingException('TEXT_INVALID', 'Libellé ou référence invalide.');
        }

        return trim($value) === '' ? null : trim($value);
    }

    private function truth(mixed $value): bool
    {
        return in_array($value, [true, 1, '1', 't', 'true'], true);
    }

    private function readRoles(): array
    {
        return ['TENANT_ADMIN', 'ACCOUNTANT', 'REVIEWER', 'READ_ONLY'];
    }

    private function reportQuery(string $companyId, string $yearId, string $tenantId): Builder
    {
        return DB::table('entry_lines')
            ->join('entries', function ($join): void {
                $join->on('entries.id', '=', 'entry_lines.entry_id')->on('entries.tenant_id', '=', 'entry_lines.tenant_id')->on('entries.company_id', '=', 'entry_lines.company_id');
            })
            ->join('accounts', function ($join): void {
                $join->on('accounts.id', '=', 'entry_lines.account_id')->on('accounts.tenant_id', '=', 'entry_lines.tenant_id')->on('accounts.company_id', '=', 'entry_lines.company_id');
            })
            ->where('entry_lines.tenant_id', $tenantId)->where('entry_lines.company_id', $companyId)
            ->where('entries.fiscal_year_id', $yearId)->where('entries.status', 'POSTED');
    }

    private function postingResult(object $entry, array $lines): array
    {
        $debit = Decimal::ZERO;
        $credit = Decimal::ZERO;
        foreach ($lines as $line) {
            $debit = Decimal::add($debit, (string) $line->debit);
            $credit = Decimal::add($credit, (string) $line->credit);
        }

        return ['id' => $entry->id, 'status' => $entry->status, 'number' => $entry->number,
            'posted_by' => $entry->posted_by, 'total_debit' => $debit, 'total_credit' => $credit];
    }

    private function audit(string $table, string $action, string $id, ?array $old, ?array $new, string $tenantId, string $actorId): void
    {
        if (DB::getDriverName() === 'pgsql') {
            return; // Protected PostgreSQL triggers are the single source of audit writes.
        }
        DB::table('audit_events')->insert([
            'id' => (string) Str::uuid(), 'tenant_id' => $tenantId, 'actor_id' => $actorId,
            'table_name' => $table, 'action' => $action, 'record_id' => $id,
            'old_values' => $old === null ? null : json_encode($old, JSON_THROW_ON_ERROR),
            'new_values' => $new === null ? null : json_encode($new, JSON_THROW_ON_ERROR),
            'request_id' => $this->auditRequestId, 'created_at' => now(),
        ]);
    }
}
