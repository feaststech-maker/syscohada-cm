<?php
declare(strict_types=1);

namespace App\Domain\Import;

use Brick\Math\BigDecimal;

final class AmountParser
{
    public static function parse(string $input, string $style = 'FR'): BigDecimal
    {
        $text = self::trim($input);
        if ($text === '') return BigDecimal::zero()->toScale(2);
        $pattern = match ($style) {
            'FR' => '/^(?:\d+|\d{1,3}(?:[ \x{00a0}\x{202f}]\d{3})+)(?:,\d{1,6})?$/uD',
            'EN' => '/^(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d{1,6})?$/D',
            default => throw new \InvalidArgumentException('Format numérique FR ou EN requis.'),
        };
        if (!preg_match($pattern, $text)) throw new \InvalidArgumentException('Montant positif invalide pour le format sélectionné.');
        $canonical = $style === 'FR' ? str_replace([' ', "\u{00a0}", "\u{202f}", ','], ['', '', '', '.'], $text) : str_replace(',', '', $text);
        return self::validate(BigDecimal::of($canonical));
    }

    public static function excel(string $raw): BigDecimal
    {
        if (!preg_match('/^\d+(?:\.\d+)?(?:[Ee][+-]?\d{1,3})?$/D', $raw)) throw new \InvalidArgumentException('Nombre Excel invalide.');
        $value = BigDecimal::of($raw)->strippedOfTrailingZeros();
        $digits = strlen(ltrim((string) $value->getUnscaledValue(), '-'));
        if ($digits > 15 || $digits - $value->getScale() > 15) throw new \InvalidArgumentException('Plus de 15 chiffres dans une cellule numérique Excel : utilisez du texte.');
        return self::validate($value);
    }

    private static function validate(BigDecimal $value): BigDecimal
    {
        $canonical = $value->strippedOfTrailingZeros();
        $digits = strlen(ltrim((string) $canonical->getUnscaledValue(), '-'));
        if ($value->isNegative() || $canonical->getScale() > 6 || $digits - $canonical->getScale() > 22)
            throw new \InvalidArgumentException('Montant hors limites : positif, 22 chiffres entiers et 6 décimales maximum.');
        return $value->toScale(max(2, $canonical->getScale()));
    }

    public static function trim(string $text): string
    {
        return preg_replace('/^\s+|\s+$/u', '', $text) ?? '';
    }

    public static function safeCsvText(string $text): string
    {
        return preg_match('/^[=+\-@\t\r]/u', ltrim($text)) ? "'".$text : $text;
    }
}
