<?php
declare(strict_types=1);
namespace App\Domain\Import;

final class ColumnMapper
{
    public const ALIASES = [
        'ACCOUNT' => ['compte','numero compte','numero de compte','n compte','n de compte','code compte','account','account number'],
        'LABEL' => ['libelle','intitule','intitule du compte','libelle compte','libelle du compte','description','label','account name'],
        'DEBIT' => ['debit','solde debiteur','solde debit','montant debit','debit amount','debits'],
        'CREDIT' => ['credit','solde crediteur','solde credit','montant credit','credit amount','credits'],
    ];
    public static function suggest(array $headers): array
    {
        $result=[];
        foreach(self::ALIASES as $field=>$aliases) {
            $candidates=[];
            foreach($headers as $i=>$header) if(in_array(self::normalize((string)$header),$aliases,true))$candidates[]=$i;
            $result[$field]=['column'=>count($candidates)===1?$candidates[0]:null,'confidence'=>count($candidates)===1?100:0,'candidates'=>$candidates];
        }
        return $result;
    }
    private static function normalize(string $text): string
    {
        $text=mb_strtolower($text,'UTF-8');
        $text=strtr($text,['é'=>'e','è'=>'e','ê'=>'e','ë'=>'e','à'=>'a','â'=>'a','ä'=>'a','î'=>'i','ï'=>'i','ô'=>'o','ö'=>'o','ù'=>'u','û'=>'u','ü'=>'u','ç'=>'c','œ'=>'oe']);
        return trim(preg_replace('/[^a-z0-9]+/',' ',$text)??'');
    }
}
