<?php
declare(strict_types=1);
namespace App\Domain\Import;

/** Bounded OOXML inspection. Never extracts, evaluates formulas, or resolves external entities. */
final class SafeXlsx
{
    public static function inspect(string $bytes, bool $rejectFormulas = true): array
    {
        if(strlen($bytes)>8*1024*1024 || !str_starts_with($bytes,"PK")) throw new \InvalidArgumentException('Fichier XLSX invalide ou trop volumineux.');
        $tmp=tempnam(sys_get_temp_dir(),'dsf-xlsx-');
        if($tmp===false)throw new \RuntimeException('Répertoire temporaire indisponible.');
        chmod($tmp,0600);file_put_contents($tmp,$bytes);
        $zip=new \ZipArchive();$opened=false;
        try {
            if(($opened=$zip->open($tmp)===true)!==true || $zip->numFiles>512) throw new \InvalidArgumentException('Archive Excel refusée.');
            $parts=[];$total=0;
            for($i=0;$i<$zip->numFiles;$i++) {
                $stat=$zip->statIndex($i);$name=$stat['name'];$size=(int)$stat['size'];$compressed=max(1,(int)$stat['comp_size']);
                if(isset($parts[$name]) || str_contains($name,'..') || str_contains($name,'\\') || str_starts_with($name,'/') || str_contains($name,"\0"))throw new \InvalidArgumentException('Chemin OOXML invalide.');
                if(preg_match('~(?:vbaProject|externalLinks|embeddings|connections|oleObject)~i',$name))throw new \InvalidArgumentException('Macros, objets intégrés et connexions externes interdits.');
                if($size>16*1024*1024 || ($size>1024*1024 && $size/$compressed>100) || ($total+=$size)>64*1024*1024)throw new \InvalidArgumentException('Archive Excel décompressée excessive.');
                if(str_ends_with($name,'/'))continue;
                $content=$zip->getFromIndex($i,16*1024*1024+1);
                if($content===false || strlen($content)!==$size)throw new \InvalidArgumentException('Archive Excel incomplète.');
                if(str_ends_with($name,'.xml') || str_ends_with($name,'.rels')) {
                    $xml=self::xml($content);
                    if(str_ends_with($name,'.rels')) foreach($xml->getElementsByTagNameNS('*','Relationship') as $relation)
                        if(strcasecmp($relation->getAttribute('TargetMode'),'External')===0)throw new \InvalidArgumentException('Relation externe interdite.');
                    if($rejectFormulas && preg_match('~^xl/worksheets/[^/]+\.xml$~',$name) && $xml->getElementsByTagNameNS('*','f')->length>0)throw new \InvalidArgumentException('Formules Excel interdites dans une balance importée.');
                    if($name==='[Content_Types].xml' && preg_match('/macroEnabled|vbaProject/i',$content))throw new \InvalidArgumentException('Classeur avec macros interdit.');
                }
                $parts[$name]=$content;
            }
            foreach(['[Content_Types].xml','xl/workbook.xml','xl/_rels/workbook.xml.rels'] as $required)
                if(!isset($parts[$required]))throw new \InvalidArgumentException('Structure XLSX incomplète.');
            return $parts;
        } finally { if($opened)$zip->close();@unlink($tmp); }
    }
    public static function xml(string $content): \DOMDocument
    {
        if(preg_match('/<!DOCTYPE|<!ENTITY/i',$content))throw new \InvalidArgumentException('Entités XML interdites.');
        $doc=new \DOMDocument();$previous=libxml_use_internal_errors(true);
        try {if(!$doc->loadXML($content,LIBXML_NONET|LIBXML_COMPACT))throw new \InvalidArgumentException('XML Excel invalide.');}
        finally{libxml_clear_errors();libxml_use_internal_errors($previous);}
        return $doc;
    }
}
