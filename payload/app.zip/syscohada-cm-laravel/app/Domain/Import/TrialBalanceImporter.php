<?php
declare(strict_types=1);
namespace App\Domain\Import;

use Brick\Math\BigDecimal;

final class TrialBalanceImporter
{
    private const FIELDS=['ACCOUNT','LABEL','DEBIT','CREDIT'];
    public function preview(string $bytes,string $filename,array $options): array
    {
        if($bytes==='' || strlen($bytes)>8*1024*1024)throw new \InvalidArgumentException('Fichier vide ou supérieur à 8 Mio.');
        $headerRow=$options['headerRow']??1;
        if(!is_int($headerRow) || $headerRow<1 || $headerRow>20)throw new \InvalidArgumentException('En-tête de 1 à 20 requis.');
        $style=$options['numberStyle']??'FR';
        if(!in_array($style,['FR','EN'],true))throw new \InvalidArgumentException('Format numérique invalide.');
        $extension=strtolower(pathinfo($filename,PATHINFO_EXTENSION));
        $table=match($extension){'csv'=>$this->csv($bytes,$headerRow,$options['delimiter']??null),'xlsx'=>$this->xlsx($bytes,$headerRow,$options['sheetName']??null),default=>throw new \InvalidArgumentException('Formats acceptés : CSV UTF-8 et XLSX.')};
        $suggestions=ColumnMapper::suggest($table['headers']);$selected=[];$issues=[];
        foreach(self::FIELDS as $field) {
            $column=$options['columns'][$field]??$suggestions[$field]['column'];
            if(!is_int($column) || $column<0 || $column>=count($table['headers']))$issues[]=$this->issue('ERROR','MAPPING_REQUIRED',$headerRow,$field,'Choisissez une colonne unique.');
            else $selected[$field]=$column;
        }
        if(count(array_unique($selected))!==count($selected))$issues[]=$this->issue('ERROR','MAPPING_DUPLICATE',$headerRow,'mapping','Une colonne ne peut représenter plusieurs champs.');
        $convention=$options['convention']??null;
        if(!in_array($convention,['CLOSING_BALANCE','PERIOD_MOVEMENTS'],true))$issues[]=$this->issue('ERROR','CONVENTION_REQUIRED',0,'convention','Précisez soldes de clôture ou mouvements de période.');
        $allowed=$options['allowedClasses']??['1','2','3','4','5','6','7','8'];
        if(!is_array($allowed) || $allowed===[] || count(array_filter($allowed,fn($v)=>is_string($v)&&preg_match('/^[0-9]$/D',$v)))!==count($allowed))throw new \InvalidArgumentException('Classes de compte invalides.');
        $rows=[];$seen=[];$debit=BigDecimal::zero()->toScale(2);$credit=$debit;
        if(count($selected)===4 && count(array_unique($selected))===4)foreach($table['data'] as $source) {
            $values=$source['cells'];$row=$source['row'];
            if(count(array_filter($values,fn($v)=>AmountParser::trim($v['text'])!==''))===0)continue;
            $get=fn(string $f)=>$values[$selected[$f]]??['text'=>'','numeric'=>false];
            $account=AmountParser::trim($get('ACCOUNT')['text']);$label=AmountParser::trim($get('LABEL')['text']);$valid=true;
            if(!preg_match('/^[0-9]{2,20}$/D',$account) || !in_array($account[0]??'',$allowed,true)){$valid=false;$issues[]=$this->issue('ERROR','ACCOUNT_INVALID',$row,'ACCOUNT','Compte numérique de 2 à 20 caractères dans une classe autorisée requis.');}
            if($label==='' || mb_strlen($label)>500 || preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f]/',$label)){$valid=false;$issues[]=$this->issue('ERROR','LABEL_INVALID',$row,'LABEL','Libellé requis, 500 caractères maximum.');}
            if($get('ACCOUNT')['numeric'])$issues[]=$this->issue('WARNING','NUMERIC_ACCOUNT',$row,'ACCOUNT','Compte numérique Excel : vérifiez les zéros initiaux.');
            $amounts=[];
            foreach(['DEBIT','CREDIT'] as $field)try{$cell=$get($field);$amounts[$field]=$cell['numeric']?AmountParser::excel($cell['text']):AmountParser::parse($cell['text'],$style);}catch(\InvalidArgumentException $e){$valid=false;$issues[]=$this->issue('ERROR','AMOUNT_INVALID',$row,$field,$e->getMessage());}
            if(!$valid)continue;
            if(isset($seen[$account]))$issues[]=$this->issue('ERROR','DUPLICATE_ACCOUNT',$row,'ACCOUNT','Compte déjà présent : consolidation explicite requise.');
            $seen[$account]=$row;
            if($convention==='CLOSING_BALANCE' && $amounts['DEBIT']->isPositive() && $amounts['CREDIT']->isPositive())$issues[]=$this->issue('ERROR','DOUBLE_CLOSING_BALANCE',$row,'amount','Un solde ne peut être débiteur et créditeur simultanément.');
            $rows[]=['sourceRow'=>$row,'account'=>$account,'label'=>$label,'debit'=>(string)$amounts['DEBIT'],'credit'=>(string)$amounts['CREDIT']];
            $debit=$debit->plus($amounts['DEBIT']);$credit=$credit->plus($amounts['CREDIT']);
        }
        if($rows===[])$issues[]=$this->issue('ERROR','EMPTY_BALANCE',0,'file','Aucune ligne de balance valide.');
        if(!$debit->isEqualTo($credit))$issues[]=$this->issue('ERROR','UNBALANCED',0,'totals','Débit et crédit divergent de '.(string)$debit->minus($credit).'.');
        if($convention==='PERIOD_MOVEMENTS')$issues[]=$this->issue('WARNING','OPENING_REQUIRED',0,'convention','Une balance d’ouverture est nécessaire pour obtenir les soldes de clôture.');
        return ['sha256'=>hash('sha256',$bytes),'headers'=>$table['headers'],'sampleRows'=>array_map(fn($r)=>array_column($r['cells'],'text'),array_slice($table['data'],0,5)),'suggestions'=>$suggestions,'selectedColumns'=>$selected,'convention'=>$convention,'rows'=>$rows,'totalDebit'=>(string)$debit,'totalCredit'=>(string)$credit,'issues'=>$issues,'validForImport'=>$rows!==[] && !array_filter($issues,fn($i)=>$i['severity']==='ERROR')];
    }
    private function issue(string $severity,string $code,int $row,string $field,string $message): array{return compact('severity','code','row','field','message');}
    private function csv(string $bytes,int $headerRow,?string $delimiter): array
    {
        if(!mb_check_encoding($bytes,'UTF-8') || str_starts_with($bytes,'PK'))throw new \InvalidArgumentException('CSV UTF-8 requis.');
        $bytes=preg_replace('/^\xEF\xBB\xBF/','',$bytes)??$bytes;
        if($delimiter===null){$counts=[];foreach([';',',',"\t"] as $d){$s=fopen('php://temp','w+');fwrite($s,$bytes);rewind($s);$r=false;for($n=1;$n<=$headerRow;$n++)$r=fgetcsv($s,null,$d,'"','');$counts[$d]=is_array($r)?count($r):0;fclose($s);}arsort($counts);$max=reset($counts);if($max<2 || count(array_filter($counts,fn($c)=>$c===$max))!==1)throw new \InvalidArgumentException('Séparateur ambigu : choisissez-le explicitement.');$delimiter=array_key_first($counts);}
        if(!in_array($delimiter,[';',',',"\t"],true))throw new \InvalidArgumentException('Séparateur CSV invalide.');
        $s=fopen('php://temp','w+');fwrite($s,$bytes);rewind($s);$headers=null;$data=[];$index=0;
        try {while(($r=fgetcsv($s,null,$delimiter,'"',''))!==false){$index++;if(count($r)>128 || $index>25000+$headerRow)throw new \InvalidArgumentException('Limite : 25 000 lignes, 128 colonnes.');$r=array_map(fn($v)=>(string)($v??''),$r);foreach($r as $v)if(strlen($v)>10000)throw new \InvalidArgumentException('Cellule trop longue.');if($index===$headerRow)$headers=$r;elseif($index>$headerRow)$data[]=['row'=>$index,'cells'=>array_map(fn($v)=>['text'=>$v,'numeric'=>false],$r)];}}finally{fclose($s);}
        if($headers===null)throw new \InvalidArgumentException('En-tête introuvable.');return compact('headers','data');
    }
    private function xlsx(string $bytes,int $headerRow,?string $sheetName): array
    {
        $parts=SafeXlsx::inspect($bytes);$rels=[];
        foreach(SafeXlsx::xml($parts['xl/_rels/workbook.xml.rels'])->getElementsByTagNameNS('*','Relationship') as $r)$rels[$r->getAttribute('Id')]=$r->getAttribute('Target');
        $sheetPath=null;
        foreach(SafeXlsx::xml($parts['xl/workbook.xml'])->getElementsByTagNameNS('*','sheet') as $sheet){if($sheetName===null || $sheet->getAttribute('name')===$sheetName){$rid=$sheet->getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id');$target=$rels[$rid]??'';$sheetPath=str_starts_with($target,'/')?ltrim($target,'/'):'xl/'.$target;break;}}
        if($sheetPath===null || !isset($parts[$sheetPath]))throw new \InvalidArgumentException('Feuille Excel introuvable.');
        $strings=[];if(isset($parts['xl/sharedStrings.xml']))foreach(SafeXlsx::xml($parts['xl/sharedStrings.xml'])->getElementsByTagNameNS('*','si') as $si){$t='';foreach($si->getElementsByTagNameNS('*','t') as $node)$t.=$node->textContent;$strings[]=$t;}
        $headers=null;$data=[];$count=0;
        foreach(SafeXlsx::xml($parts[$sheetPath])->getElementsByTagNameNS('*','row') as $r){$rn=(int)$r->getAttribute('r');if($rn<1 || $rn>25000+$headerRow || ++$count>25000+$headerRow)throw new \InvalidArgumentException('Limite de lignes Excel dépassée.');$cells=[];
            foreach($r->getElementsByTagNameNS('*','c') as $c){if(!preg_match('/^([A-Z]+)[1-9][0-9]*$/D',$c->getAttribute('r'),$m))throw new \InvalidArgumentException('Coordonnée Excel invalide.');$col=0;foreach(str_split($m[1]) as $letter)$col=$col*26+ord($letter)-64;$col--;if($col>127)throw new \InvalidArgumentException('128 colonnes maximum.');$type=$c->getAttribute('t');$v=$c->getElementsByTagNameNS('*','v')->item(0)?->textContent??'';$numeric=false;
                if($type==='s'){$index=filter_var($v,FILTER_VALIDATE_INT);if($index===false || !array_key_exists($index,$strings))throw new \InvalidArgumentException('Chaîne Excel invalide.');$v=$strings[$index];}
                elseif($type==='inlineStr'){$v='';foreach($c->getElementsByTagNameNS('*','t') as $t)$v.=$t->textContent;}
                elseif($type==='b')$v=$v==='1'?'TRUE':'FALSE';elseif($type==='e')throw new \InvalidArgumentException('Cellule Excel en erreur.');elseif($type==='' || $type==='n')$numeric=$v!=='';
                elseif($type!=='str')throw new \InvalidArgumentException('Type de cellule Excel non supporté.');
                if(strlen($v)>10000)throw new \InvalidArgumentException('Cellule trop longue.');$cells[$col]=['text'=>$v,'numeric'=>$numeric];
            }
            if($cells!==[]){$max=max(array_keys($cells));for($i=0;$i<=$max;$i++)$cells[$i]??=['text'=>'','numeric'=>false];ksort($cells);$cells=array_values($cells);}
            if($rn===$headerRow)$headers=array_column($cells,'text');elseif($rn>$headerRow)$data[]=['row'=>$rn,'cells'=>$cells];
        }
        if($headers===null || $headers===[])throw new \InvalidArgumentException('En-tête Excel introuvable.');return compact('headers','data');
    }
}
