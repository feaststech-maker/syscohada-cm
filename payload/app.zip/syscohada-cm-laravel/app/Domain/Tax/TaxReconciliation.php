<?php
declare(strict_types=1);
namespace App\Domain\Tax;

use Brick\Math\BigDecimal;
use Brick\Math\RoundingMode;

/** Generic approved-rule kernel. Eligibility, prior-year MP base, sector exceptions and credits require fiscal review. */
final class TaxReconciliation
{
    public function compute(string $profitBeforeTax,string $approvedMinimumBase,array $adjustments,array $rules,string $periodEnd): array
    {
        if(($rules['approved']??false)!==true||empty($rules['version'])||$periodEnd<($rules['from']??'9999')||$periodEnd>($rules['to']??'0000'))throw new \InvalidArgumentException('Aucune règle approuvée pour cet exercice.');
        foreach(['corporateRate','minimumRate','cacRate'] as $key){if(!is_string($rules[$key]??null))throw new \InvalidArgumentException('Taux décimal sous forme de chaîne requis.');$rate=BigDecimal::of($rules[$key]);if($rate->isNegative()||$rate->isGreaterThan('1'))throw new \InvalidArgumentException('Taux hors limites.');}
        $profit=BigDecimal::of($profitBeforeTax);$base=BigDecimal::of($approvedMinimumBase);if($base->isNegative())throw new \InvalidArgumentException('Base du minimum négative.');$credits=BigDecimal::zero();
        foreach($adjustments as $adjustment){if(!is_string($adjustment['amount']??null)||empty($adjustment['justification']))throw new \InvalidArgumentException('Ajustement incomplet.');$amount=BigDecimal::of($adjustment['amount']);if($amount->isNegative())throw new \InvalidArgumentException('Ajustement négatif.');switch($adjustment['kind']??null){case 'ADD_BACK':$profit=$profit->plus($amount);break;case 'DEDUCTION':$profit=$profit->minus($amount);break;case 'TAX_CREDIT':$credits=$credits->plus($amount);break;default:throw new \InvalidArgumentException('Type d’ajustement invalide.');}}
        $unit=BigDecimal::of($rules['profitRoundingUnit']??'1000');if(!$unit->isPositive())throw new \InvalidArgumentException('Arrondi invalide.');
        $taxable=BigDecimal::max($profit,'0')->dividedBy($unit,0,RoundingMode::DOWN)->multipliedBy($unit);
        $corporate=$taxable->multipliedBy($rules['corporateRate'])->toScale(0,RoundingMode::HALF_UP);
        $minimum=$base->multipliedBy($rules['minimumRate'])->toScale(0,RoundingMode::HALF_UP);$principal=BigDecimal::max($corporate,$minimum);$cac=$principal->multipliedBy($rules['cacRate'])->toScale(0,RoundingMode::HALF_UP);$liability=$principal->plus($cac);
        return ['ruleVersion'=>$rules['version'],'adjustedProfit'=>(string)$profit,'taxableProfit'=>(string)$taxable,'corporatePrincipal'=>(string)$corporate,'minimumPrincipal'=>(string)$minimum,'principalPayable'=>(string)$principal,'cac'=>(string)$cac,'liability'=>(string)$liability,'approvedCredits'=>(string)$credits,'netPayable'=>(string)BigDecimal::max($liability->minus($credits),'0'),'unappliedCredits'=>(string)BigDecimal::max($credits->minus($liability),'0')];
    }
}
