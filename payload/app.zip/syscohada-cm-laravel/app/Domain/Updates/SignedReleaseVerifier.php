<?php

declare(strict_types=1);

namespace App\Domain\Updates;

use JsonException;
use RuntimeException;
use ZipArchive;

/**
 * Verifies publisher provenance and payload integrity, never extracts or executes an upload.
 * The pinned raw Ed25519 public key must come from trusted server configuration.
 * sys_get_temp_dir()/TMPDIR must point to a private tmpfs in production.
 */
final readonly class SignedReleaseVerifier
{
    private const MAX_ARCHIVE_BYTES = 20 * 1024 * 1024;
    private const MAX_EXPANDED_BYTES = 64 * 1024 * 1024;
    private const MAX_ENTRY_BYTES = 16 * 1024 * 1024;
    private const MAX_ENTRIES = 500;

    public function __construct(private string $pinnedPublicKey)
    {
        if (strlen($pinnedPublicKey) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) {
            throw new RuntimeException('RELEASE_PUBLIC_KEY_INVALID');
        }
    }

    /** @return array{version: string, archiveSha256: string, databaseBackwardCompatible: bool} */
    public function verify(string $zipBytes, string $manifestBytes, string $signatureBytes, string $runningVersion): array
    {
        $compressedSize = strlen($zipBytes);
        if ($compressedSize === 0 || $compressedSize > self::MAX_ARCHIVE_BYTES
            || strlen($manifestBytes) === 0 || strlen($manifestBytes) > 64 * 1024
            || strlen($signatureBytes) !== SODIUM_CRYPTO_SIGN_BYTES) {
            throw new RuntimeException('RELEASE_SIZE_REJECTED');
        }
        if (!sodium_crypto_sign_verify_detached($signatureBytes, $manifestBytes, $this->pinnedPublicKey)) {
            throw new RuntimeException('RELEASE_SIGNATURE_REJECTED');
        }
        try {
            $manifest = json_decode($manifestBytes, true, 16, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            throw new RuntimeException('RELEASE_MANIFEST_INVALID');
        }
        if (!is_array($manifest) || array_is_list($manifest)
            || !is_string($manifest['version'] ?? null)
            || !is_string($manifest['parentVersion'] ?? null)
            || !is_bool($manifest['databaseBackwardCompatible'] ?? null)
            || !is_array($manifest['files'] ?? null)
            || $manifest['files'] === [] || count($manifest['files']) > self::MAX_ENTRIES
            || array_is_list($manifest['files'])) {
            throw new RuntimeException('RELEASE_MANIFEST_INVALID');
        }
        if (!$this->isVersion($manifest['version']) || !$this->isVersion($runningVersion)
            || $manifest['parentVersion'] !== $runningVersion
            || version_compare($manifest['version'], $runningVersion, '<=')) {
            throw new RuntimeException('RELEASE_LINEAGE_REJECTED');
        }
        foreach ($manifest['files'] as $path => $sha256) {
            $this->validatePath($path);
            if (!is_string($sha256) || !preg_match('/\A[a-f0-9]{64}\z/', $sha256)) {
                throw new RuntimeException('RELEASE_HASH_INVALID');
            }
        }
        $temporary = tempnam(sys_get_temp_dir(), 'syscohada-release-');
        if ($temporary === false) {
            throw new RuntimeException('RELEASE_TEMPORARY_STORAGE_FAILED');
        }
        $zip = new ZipArchive();
        $opened = false;
        try {
            if (!chmod($temporary, 0600) || file_put_contents($temporary, $zipBytes, LOCK_EX) !== $compressedSize) {
                throw new RuntimeException('RELEASE_TEMPORARY_STORAGE_FAILED');
            }
            if ($zip->open($temporary, ZipArchive::RDONLY | ZipArchive::CHECKCONS) !== true) {
                throw new RuntimeException('RELEASE_ZIP_INVALID');
            }
            $opened = true;
            if ($zip->numFiles === 0 || $zip->numFiles > self::MAX_ENTRIES) {
                throw new RuntimeException('RELEASE_ENTRY_COUNT_REJECTED');
            }
            $seen = [];
            $expandedTotal = 0;
            for ($index = 0; $index < $zip->numFiles; $index++) {
                $stat = $zip->statIndex($index);
                if ($stat === false || !is_string($stat['name'] ?? null)) {
                    throw new RuntimeException('RELEASE_ENTRY_INVALID');
                }
                $path = $stat['name'];
                $this->validatePath($path);
                if (isset($seen[$path]) || !array_key_exists($path, $manifest['files'])) {
                    throw new RuntimeException('RELEASE_UNEXPECTED_OR_DUPLICATE_ENTRY');
                }
                $seen[$path] = true;
                $opsys = 0;
                $attributes = 0;
                if (!$zip->getExternalAttributesIndex($index, $opsys, $attributes)) {
                    throw new RuntimeException('RELEASE_ATTRIBUTES_INVALID');
                }
                if ($opsys === ZipArchive::OPSYS_UNIX) {
                    $kind = ($attributes >> 16) & 0170000;
                    // Explicitly reject symlinks, directories, devices and named pipes.
                    if ($kind !== 0 && $kind !== 0100000) {
                        throw new RuntimeException('RELEASE_SPECIAL_FILE_REJECTED');
                    }
                }
                if (($stat['encryption_method'] ?? 0) !== 0 || ($stat['size'] ?? -1) < 0
                    || $stat['size'] > self::MAX_ENTRY_BYTES) {
                    throw new RuntimeException('RELEASE_ENTRY_SIZE_OR_ENCRYPTION_REJECTED');
                }
                $stream = $zip->getStreamIndex($index);
                if ($stream === false) {
                    throw new RuntimeException('RELEASE_ENTRY_UNREADABLE');
                }
                $hash = hash_init('sha256');
                $actualSize = 0;
                try {
                    while (!feof($stream)) {
                        $chunk = fread($stream, 8192);
                        if ($chunk === false || ($chunk === '' && !feof($stream))) {
                            throw new RuntimeException('RELEASE_ENTRY_UNREADABLE');
                        }
                        $count = strlen($chunk);
                        $actualSize += $count;
                        $expandedTotal += $count;
                        if ($actualSize > self::MAX_ENTRY_BYTES || $expandedTotal > self::MAX_EXPANDED_BYTES
                            || $expandedTotal > 200 * $compressedSize) {
                            throw new RuntimeException('RELEASE_EXPANSION_REJECTED');
                        }
                        hash_update($hash, $chunk);
                    }
                } finally {
                    fclose($stream);
                }
                if ($actualSize !== $stat['size'] || !hash_equals($manifest['files'][$path], hash_final($hash))) {
                    throw new RuntimeException('RELEASE_CONTENT_HASH_REJECTED');
                }
            }
            if (count($seen) !== count($manifest['files'])) {
                throw new RuntimeException('RELEASE_INCOMPLETE');
            }
            return [
                'version' => $manifest['version'],
                'archiveSha256' => hash('sha256', $zipBytes),
                'databaseBackwardCompatible' => $manifest['databaseBackwardCompatible'],
            ];
        } finally {
            if ($opened) {
                $zip->close();
            }
            @unlink($temporary);
        }
    }

    private function isVersion(string $version): bool
    {
        return strlen($version) <= 80 && preg_match('/\A[0-9]+\.[0-9]+\.[0-9]+\z/', $version) === 1;
    }

    private function validatePath(mixed $path): void
    {
        if (!is_string($path) || strlen($path) > 200
            || !preg_match('/\A[A-Za-z0-9][A-Za-z0-9_.\/-]*\z/', $path)
            || str_contains($path, '..') || str_contains($path, '//')
            || str_ends_with($path, '/') || str_contains($path, '/./')) {
            throw new RuntimeException('RELEASE_PATH_INVALID');
        }
    }
}
