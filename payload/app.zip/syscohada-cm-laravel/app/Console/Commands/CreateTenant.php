<?php
namespace App\Console\Commands;
use App\Models\{User,FiscalYear};
use App\Support\{TenantContext,CompanySetup};
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
class CreateTenant extends Command
{
    protected $signature='syscohada:tenant {name} {email} {--virtual-accounting : Activer la comptabilité virtuelle pour la première entreprise}';
    protected $description='Provisionner un tenant et son administrateur depuis une session de déploiement autorisée.';
    public function handle(TenantContext $context,CompanySetup $setup): int {
        $email=strtolower($this->argument('email'));
        if(!filter_var($email,FILTER_VALIDATE_EMAIL) || DB::table('users')->where('email',$email)->exists()) { $this->error('Adresse invalide ou déjà utilisée.');return 1; }
        $password=$this->secret('Mot de passe (12 à 72 octets, lettres et chiffres)');
        if(!is_string($password) || strlen($password)<12 || strlen($password)>72 || !preg_match('/[A-Za-z]/',$password) || !preg_match('/[0-9]/',$password) || $password!==$this->secret('Confirmer le mot de passe')) { $this->error('Mot de passe non conforme ou confirmation différente.');return 1; }
        $tenant=(string)Str::uuid();$actor=(string)Str::uuid();
        $company=$context->run($tenant,$actor,function()use($tenant,$actor,$email,$password,$setup){
            DB::table('tenants')->insert(['id'=>$tenant,'name'=>$this->argument('name'),'created_at'=>now(),'updated_at'=>now()]);
            $user=new User(['name'=>'Administrateur','email'=>$email,'password'=>$password]);$user->id=$actor;$user->tenant_id=$tenant;$user->role='TENANT_ADMIN';$user->enabled=true;$user->save();
            $company=$setup->create(['name'=>$this->argument('name'),'niu'=>null,'accounting_system'=>'SMT','fiscal_regime'=>null,'virtual_accounting_enabled'=>(bool)$this->option('virtual-accounting')]);
            FiscalYear::create(['company_id'=>$company->id,'starts_on'=>now()->startOfYear()->format('Y-m-d'),'ends_on'=>now()->endOfYear()->format('Y-m-d'),'status'=>'OPEN']);
            return $company;
        });
        $this->info('Tenant créé : '.$tenant);$this->line('Entreprise : '.$company->id);$this->line('Connexion : /login. Système SMT et plan de départ à confirmer avant usage.');return 0;
    }
}
