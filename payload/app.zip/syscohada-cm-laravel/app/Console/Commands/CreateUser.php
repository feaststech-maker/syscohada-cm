<?php
namespace App\Console\Commands;
use App\Models\User;
use App\Support\TenantContext;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
class CreateUser extends Command
{
    protected $signature='syscohada:user {tenant} {email} {--role=ACCOUNTANT}';
    protected $description='Créer un utilisateur habilité, hors inscription publique.';
    public function handle(TenantContext $context): int {
        $tenant=$this->argument('tenant');$role=$this->option('role');$email=strtolower($this->argument('email'));
        if(!Str::isUuid($tenant) || !in_array($role,['TENANT_ADMIN','ACCOUNTANT','REVIEWER','READ_ONLY'],true) || !filter_var($email,FILTER_VALIDATE_EMAIL) || DB::table('users')->where('email',$email)->exists()) { $this->error('Paramètres invalides.');return 1; }
        $password=$this->secret('Mot de passe (12 à 72 octets, lettres et chiffres)');
        if(!is_string($password) || strlen($password)<12 || strlen($password)>72 || !preg_match('/[A-Za-z]/',$password) || !preg_match('/[0-9]/',$password) || $password!==$this->secret('Confirmer')) { $this->error('Mot de passe non conforme.');return 1; }
        $actor=(string)Str::uuid();
        $context->run($tenant,$actor,function()use($tenant,$actor,$email,$role,$password){
            abort_unless(DB::table('tenants')->where('id',$tenant)->exists(),404);
            $user=new User(['name'=>$email,'email'=>$email,'password'=>$password]);$user->id=$actor;$user->tenant_id=$tenant;$user->role=$role;$user->enabled=true;$user->save();
        });
        $this->info('Utilisateur créé.');return 0;
    }
}
