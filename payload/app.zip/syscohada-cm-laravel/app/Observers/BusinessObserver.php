<?php
namespace App\Observers;
use App\Support\Audit;
use Illuminate\Database\Eloquent\Model;
final class BusinessObserver
{
    public function created(Model $model): void { Audit::local($model->getTable(), (string)$model->getKey(), 'INSERT', null, $model->getAttributes()); }
    public function updated(Model $model): void { Audit::local($model->getTable(), (string)$model->getKey(), 'UPDATE', $model->getRawOriginal(), $model->getAttributes()); }
    public function deleted(Model $model): void { Audit::local($model->getTable(), (string)$model->getKey(), 'DELETE', $model->getRawOriginal(), null); }
}
