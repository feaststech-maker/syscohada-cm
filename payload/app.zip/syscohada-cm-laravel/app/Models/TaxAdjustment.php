<?php
namespace App\Models;
class TaxAdjustment extends TenantModel {}
