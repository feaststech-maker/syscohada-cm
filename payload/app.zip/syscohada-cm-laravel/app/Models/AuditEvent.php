<?php
namespace App\Models;
class AuditEvent extends TenantModel { public $timestamps = false; protected function casts(): array { return ['old_values'=>'array','new_values'=>'array','created_at'=>'datetime']; } }
