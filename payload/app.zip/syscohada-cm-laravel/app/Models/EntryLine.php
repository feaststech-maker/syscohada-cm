<?php
namespace App\Models;
class EntryLine extends TenantModel { public function account() { return $this->belongsTo(Account::class); } }
