<?php
namespace App\Models;
class Company extends TenantModel
{
    protected function casts(): array { return ['virtual_accounting_enabled'=>'boolean']; }
    public function years() { return $this->hasMany(FiscalYear::class); }
}
