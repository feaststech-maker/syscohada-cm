<?php
namespace App\Models;
class Account extends TenantModel { protected function casts(): array { return ['is_cash'=>'boolean','active'=>'boolean']; } }
