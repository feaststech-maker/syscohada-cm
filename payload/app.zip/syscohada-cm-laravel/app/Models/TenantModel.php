<?php
namespace App\Models;
use App\Support\TenantContext;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Builder;
abstract class TenantModel extends Model
{
    use HasUuids;
    protected $guarded = ['id', 'tenant_id'];
    protected static function booted(): void
    {
        static::addGlobalScope('tenant', function(Builder $query): void {
            $tenant = app(TenantContext::class)->tenantId;
            $tenant ? $query->where($query->getModel()->qualifyColumn('tenant_id'), $tenant) : $query->whereRaw('1 = 0');
        });
        static::creating(function(Model $model): void {
            $tenant = app(TenantContext::class)->tenantId;
            if (!$tenant || ($model->tenant_id && $model->tenant_id !== $tenant)) abort(403);
            $model->tenant_id = $tenant;
        });
        static::updating(function(Model $model): void {
            if ($model->isDirty('tenant_id')) abort(403);
        });
    }
}
