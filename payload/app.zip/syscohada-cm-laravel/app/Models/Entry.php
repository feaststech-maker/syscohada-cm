<?php
namespace App\Models;
class Entry extends TenantModel
{
    protected function casts(): array { return ['entry_date'=>'date','posted_at'=>'datetime']; }
    public function lines() { return $this->hasMany(EntryLine::class)->orderBy('sort_order'); }
    public function attachments() { return $this->hasMany(Attachment::class); }
    public function journal() { return $this->belongsTo(Journal::class); }
}
