<?php
namespace App\Models;
class AdminSetting extends TenantModel {}
