<?php
namespace App\Models;
class FiscalYear extends TenantModel { protected function casts(): array { return ['starts_on'=>'date','ends_on'=>'date']; } }
